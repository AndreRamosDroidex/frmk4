USE [BPE_Procesamientos]
GO
/****** Objeto: StoredProcedure [dbo].[sp_VariacionTramos] Fecha de script: 26/08/2026 23:07:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ==================================================================================
-- Autor		:	JORGE HUAPAYA COCA
-- Creación		:	14/11/2019
-- Modificación	:	14/04/2021
-- Descripción	:	VARIACIÓN DE TRAMOS
-- 18/02/2021: Se agregaron campos para los días de atraso considerando congelamiento
-- 23/02/2021: Se agregó la lógica de Matrices de Transición Diario al final
-- 14/04/2021: Automatización
-- EXEC dbo.sp_VariacionTramos 1
-- ==================================================================================
ALTER PROCEDURE [dbo].[sp_VariacionTramos](
	@Flag_Reprocesar BIT = 0
)
AS
BEGIN

	SET DATEFIRST 1

	DECLARE

		@FechaSaldos DATE,
		@FechaProceso VARCHAR(8),
		@Cod_TipoVista SMALLINT,

		@Bucle_MesVista NUMERIC(6),
		@Bucle_MesActual NUMERIC(6),
		@Bucle_MesAnterior NUMERIC(6),
		@Bucle_FechaInicio_MesAct DATE,
		@Bucle_FechaCierre_MesAnt DATE,
		@Bucle_Query VARCHAR(2000),

		@id_Proceso INT,
		@Flag_DiaHabil BIT

	SET @FechaSaldos = ( SELECT DISTINCT AS_OF_DATE FROM BPE.dbo.vw_SaldosDiario )
	SET @FechaProceso = Convert(VARCHAR(8),@FechaSaldos,112)
	SET @id_Proceso = 43
	SET @Flag_DiaHabil = ( SELECT FLAG_DIA_HABIL FROM BPE.dbo.vw_CALENDARIO WHERE FECHA = Convert(DATE,Getdate()) )

	-----------------------
	-- VALIDAMOS PROCESO --
	-----------------------

	IF ( ( SELECT Count(*) FROM BPE.dbo.Reporte_VariacionTramos WHERE FechaVista = @FechaSaldos ) = 0 And @Flag_DiaHabil = 1 ) Or @Flag_Reprocesar = 1
	BEGIN

		-------------------------------
		-- CREAMOS TABLAS TEMPORALES --
		-------------------------------

		IF OBJECT_ID('dbo.VariacionTramos_BaseCobranza') Is Not NULL DROP TABLE dbo.VariacionTramos_BaseCobranza
		IF OBJECT_ID('dbo.VariacionTramos_Dias') Is Not NULL DROP TABLE dbo.VariacionTramos_Dias
		IF OBJECT_ID('dbo.VariacionTramos_SaldosDiario') Is Not NULL DROP TABLE dbo.VariacionTramos_SaldosDiario
		IF OBJECT_ID('dbo.VariacionTramos_Consolidado') Is Not NULL DROP TABLE dbo.VariacionTramos_Consolidado

		CREATE TABLE dbo.VariacionTramos_BaseCobranza ( Cod_Credito VARCHAR(10) )
		CREATE TABLE dbo.VariacionTramos_Dias ( FechaSaldos DATE, Cod_CreditoOrigen VARCHAR(10), DiasAtraso_Calculo SMALLINT )
		CREATE TABLE dbo.VariacionTramos_SaldosDiario ( FechaVista DATE, FechaSaldos DATE, Cod_Unico VARCHAR(10), Cod_Credito VARCHAR(10), Cod_CreditoActual VARCHAR(10), Producto VARCHAR(50), SubProducto VARCHAR(50), Cod_TipoEmpresa SMALLINT, FechaVencimiento DATE, FechaVencimientoSaldos DATE, DiasActual SMALLINT, DiasActualReal SMALLINT, DiasActualSaldos SMALLINT, SaldoActual FLOAT, Flag_CierreAnt BIT )
		CREATE TABLE dbo.VariacionTramos_Consolidado ( MesVista NUMERIC(6), FechaVista DATE, Cod_Unico VARCHAR(10), Cod_Credito VARCHAR(10), Cod_CreditoActual VARCHAR(10), Producto VARCHAR(50), SubProducto VARCHAR(50), Cod_TipoEmpresa SMALLINT, FechaVencimiento DATE, DiasCierre SMALLINT, SaldoCierre FLOAT, DiasActual SMALLINT, DiasActualReal SMALLINT, SaldoActual FLOAT, Flag_RedCobranza BIT, Flag_Cima BIT, Flag_CierreAnt BIT )

		-------------------------------
	
		TRUNCATE TABLE BPE.dbo.Reporte_VariacionTramos

		-------------------------------

		SET @Cod_TipoVista = 1

		WHILE ( @Cod_TipoVista <= 4 )
		BEGIN

			IF @Cod_TipoVista = 1 SET @Bucle_MesVista = BPE.dbo.fn_Fec_Variar_Periodo(Convert(VARCHAR(6),@FechaSaldos,112),-3)
			IF @Cod_TipoVista = 2 SET @Bucle_MesVista = BPE.dbo.fn_Fec_Variar_Periodo(Convert(VARCHAR(6),@FechaSaldos,112),-2)
			IF @Cod_TipoVista = 3 SET @Bucle_MesVista = BPE.dbo.fn_Fec_Variar_Periodo(Convert(VARCHAR(6),@FechaSaldos,112),-1)	
			IF @Cod_TipoVista = 4 SET @Bucle_MesVista = Convert(VARCHAR(6),@FechaSaldos,112)

			SET @Bucle_MesActual = @Bucle_MesVista
			SET @Bucle_MesAnterior = BPE.dbo.fn_Fec_Variar_Periodo(@Bucle_MesActual,-1)
			SET @Bucle_FechaInicio_MesAct = ( SELECT FECHA FROM BPE.dbo.vw_CALENDARIO WHERE CODMES_BPE = @Bucle_MesActual And FLAG_INICIO = 1 )
			SET @Bucle_FechaCierre_MesAnt = ( SELECT FECHA FROM BPE.dbo.vw_CALENDARIO WHERE CODMES_BPE = @Bucle_MesAnterior And FLAG_CIERRE = 1 )

			--------------------------------------------------

			TRUNCATE TABLE dbo.VariacionTramos_BaseCobranza
			TRUNCATE TABLE dbo.VariacionTramos_SaldosDiario
			TRUNCATE TABLE dbo.VariacionTramos_Consolidado
		
			--------------------------------------------------
			-- EXTRAEMOS SALDOS DEL CIERRE DEL MES ANTERIOR --
			--------------------------------------------------

			TRUNCATE TABLE dbo.VariacionTramos_Dias

			INSERT INTO dbo.VariacionTramos_Dias ( FechaSaldos, Cod_CreditoOrigen, DiasAtraso_Calculo )
			SELECT FechaSaldos, Cod_CreditoOrigen, MAX(DiasAtraso_Calculo) DiasAtraso_Calculo
			FROM  BPE.dbo.vw_Base_DiasAtraso
			WHERE FechaSaldos = @Bucle_FechaCierre_MesAnt
			GROUP BY FechaSaldos, Cod_CreditoOrigen

			INSERT INTO dbo.VariacionTramos_SaldosDiario ( FechaSaldos, Cod_Unico, Cod_Credito, Cod_CreditoActual, Producto, SubProducto, Cod_TipoEmpresa, FechaVencimiento, DiasActual, DiasActualReal, SaldoActual, Flag_CierreAnt )
			SELECT
				---Sc.AS_OF_DATE As FechaVista,
				Sc.AS_OF_DATE As FechaReal,
				Sc.CIF_KEY As Cod_Unico,
				Sc.NROPROD_X As Cod_Credito,
				Sc.NROPROD As Cod_CreditoActual,
				lTrim(rTrim(Sc.PROD)) As Producto,
				lTrim(rTrim(Sc.SUBPROD)) As SubProducto,
				Sc.TIP_CRED As Cod_TipoEmpresa,
				Sc.FECHA_PROX_VENCIMIENTO As FechaVencimiento,
				Sc.DM As DiasCierre,
				DA.DiasAtraso_Calculo As DiasCierreReal,
				( Sc.VIG*Tc.TipoCambio )+( Sc.VEN*Tc.TipoCambio )+( Sc.JUD*Tc.TipoCambio ) As Saldo,
				1 As Flag_CierreAnt
			FROM BPE.dbo.vw_SaldosCierre Sc
			INNER JOIN BPE.dbo.vw_DatosCierre Tc On Sc.MES = Tc.Mes
			--INNER JOIN dbo.VariacionTramos_Dias DA ON Sc.MES = DA.Mes AND Sc.NROPROD_X = DA.Cod_CreditoOrigen AND DA.FechaSaldos = Tc.FechaCierre_BPE
			INNER JOIN dbo.VariacionTramos_Dias DA ON Sc.NROPROD_X = DA.Cod_CreditoOrigen
			WHERE YEAR(FECHA_PROX_VENCIMIENTO) >= '1900' AND 
				Sc.MES = @Bucle_MesAnterior
				And Sc.TRAMO <> 'Cast'
				And Sc.VIG+Sc.VEN+Sc.JUD > 0

			-------------------------------------------
			-- EXTRAEMOS LOS CRÉDITOS DEL MES ACTUAL --
			-------------------------------------------

			--INSERT INTO dbo.VariacionTramos_BaseCobranza ( Cod_Credito )
			--SELECT COD_CREDITO
			--FROM BPE.cob.BASE_COBRANZAS
			--WHERE CODMES = @Bucle_MesActual

			-------------------------------
			-- EXTRAEMOS SALDOS ACTUALES --
			-------------------------------

			DECLARE @Cursor_FechaVista VARCHAR(8), @Cursor_DiaBPE SMALLINT, @Cursor_FlagCierre BIT, @Cursor_FechaSaldos VARCHAR(8), @Cursor_MesTc NUMERIC(6)
		
			DECLARE CurSaldos CURSOR SCROLL FOR
				SELECT Convert(VARCHAR(8),FECHA,112) As FechaVista, DIA_BPE As DiaBPE, FLAG_CIERRE As FlagCierre
				FROM BPE.dbo.vw_CALENDARIO
				WHERE
					CODMES_BPE = @Bucle_MesActual
					And FECHA <= @FechaSaldos
					And FECHA Between
						( SELECT TOP (1) FECHA FROM BPE.dbo.vw_CALENDARIO WHERE CODMES_BPE = @Bucle_MesActual And DIA_BPE <> -1 ORDER BY FECHA )
						And
						( SELECT TOP (1) FECHA FROM BPE.dbo.vw_CALENDARIO WHERE CODMES_BPE = @Bucle_MesActual And DIA_BPE <> -1 ORDER BY FECHA DESC )
				ORDER BY FECHA
			OPEN CurSaldos
			FETCH FIRST FROM CurSaldos INTO @Cursor_FechaVista, @Cursor_DiaBPE, @Cursor_FlagCierre
			WHILE(@@fetch_status = 0)
			BEGIN
			
				SET @Cursor_FechaSaldos = @Cursor_FechaVista

				IF @Cursor_DiaBPE = -1
				BEGIN
					SET @Cursor_FechaSaldos = (
						SELECT TOP (1) Convert(VARCHAR(8),FECHA,112) FROM BPE.dbo.vw_CALENDARIO
						WHERE CODMES_BPE = @Bucle_MesActual And DIA_BPE <> -1 And FECHA < @Cursor_FechaVista ORDER BY FECHA DESC )
				END

				IF @Cursor_FlagCierre = 1
					SET @Cursor_MesTc = @Bucle_MesActual
					ELSE
					SET @Cursor_MesTc = @Bucle_MesAnterior

				TRUNCATE TABLE dbo.VariacionTramos_Dias

				INSERT INTO dbo.VariacionTramos_Dias ( FechaSaldos, Cod_CreditoOrigen, DiasAtraso_Calculo )
				SELECT FechaSaldos, Cod_CreditoOrigen, MAX(DiasAtraso_Calculo) DiasAtraso_Calculo
				FROM BPE.dbo.vw_Base_DiasAtraso
				WHERE FechaSaldos = @Cursor_FechaSaldos
				GROUP BY FechaSaldos, Cod_CreditoOrigen
			
				SET @Bucle_Query = '
					INSERT INTO dbo.VariacionTramos_SaldosDiario ( FechaVista, FechaSaldos, Cod_Unico, Cod_Credito, Cod_CreditoActual, Producto, SubProducto, Cod_TipoEmpresa, FechaVencimiento, FechaVencimientoSaldos, DiasActual, DiasActualReal, DiasActualSaldos, SaldoActual, Flag_CierreAnt )
					SELECT
						'+CHAR(39)+@Cursor_FechaVista+CHAR(39)+' As FechaVista,
						Sd.AS_OF_DATE As FechaReal,
						Sd.CIF_KEY As Cod_Unico,
						Sd.NROPROD_X As Cod_Credito,
						Sd.NROPROD As Cod_CreditoActual,
						lTrim(rTrim(Sd.PROD)) As Producto,
						lTrim(rTrim(Sd.SUBPROD)) As SubProducto,
						Sd.TIP_CRED As Cod_TipoEmpresa,
						Sd.FECHA_PROX_VENCIMIENTO As FechaVencimiento,
						Sd.FECHA_PROX_VENCIMIENTO As FechaVencimientoSaldos,
						IsNull(Sd.DM,0) As DiasActual,
						IsNull(DA.DiasAtraso_Calculo,0) As DiasActualReal,
						IsNull(Sd.DM,0) As DiasActualSaldos,
						( Sd.VIG*Tc.TipoCambio )+( Sd.VEN*Tc.TipoCambio )+( Sd.JUD*Tc.TipoCambio ) As SaldoActual,
						0 As Flag_CierreAnt
					FROM BPE.dbo.SaldosDiario_'+Left(@Cursor_FechaSaldos,6)+' Sd
					INNER JOIN BPE.dbo.vw_DatosCierre Tc On Tc.Mes = '+CHAR(39)+Convert(VARCHAR(6),@Cursor_MesTc)+CHAR(39)+'
					INNER JOIN dbo.VariacionTramos_Dias DA ON Sd.NROPROD_X = DA.Cod_CreditoOrigen
					WHERE YEAR(FECHA_PROX_VENCIMIENTO) >= ''1900'' AND 
						Sd.AS_OF_DATE = '+CHAR(39)+@Cursor_FechaSaldos+CHAR(39) +'
						And Sd.TRAMO <> '+CHAR(39)+'Cast'+CHAR(39)+'
						And Sd.VIG+Sd.VEN+Sd.JUD > 0'
		
				--INNER JOIN dbo.VariacionTramos_Dias DA ON Sd.AS_OF_DATE = DA.FechaSaldos And Sd.NROPROD_X = DA.Cod_CreditoOrigen
				--PRINT @Bucle_Query

				EXEC ( @Bucle_Query )

				IF @Cursor_DiaBPE = -1
				BEGIN

					UPDATE Sd
					SET
						Sd.FechaVencimiento = Pag.NuevoVencimiento,
						Sd.SaldoActual = IsNull(Sd.SaldoActual,0)-IsNull(Pag.CapitalAmortizado,0)
					FROM dbo.VariacionTramos_SaldosDiario Sd
					INNER JOIN (
						SELECT Cod_Credito, CapitalAmortizado, UltFechaPago, NuevoVencimiento
						FROM (
							SELECT Cr1.Cod_Credito, Cr1.CapitalAmortizado, Cr1.UltFechaPago, Cr2.FechaVencimiento As NuevoVencimiento, Row_Number() OVER( PARTITION BY Cr1.Cod_Credito ORDER BY Cr2.NumCuota ) As Item
							FROM (
								SELECT Cod_Credito, Sum(MontoPrincipal) As CapitalAmortizado, Max(NumCuota) As UltimaCuota, Max(FechaPago) As UltFechaPago
								FROM BPE.dbo.vw_Cronogramas
								WHERE FechaPago > @Cursor_FechaSaldos And FechaPago <= @Cursor_FechaVista
								GROUP BY Cod_Credito
							) Cr1
							LEFT JOIN BPE.dbo.vw_Cronogramas Cr2 On Cr1.Cod_Credito = Cr2.Cod_Credito And Cr1.UltimaCuota < Cr2.NumCuota
						) Pag
						WHERE Item = 1
					) Pag On Sd.Cod_Credito = Pag.Cod_Credito
					WHERE
						FechaVista = @Cursor_FechaVista

					UPDATE dbo.VariacionTramos_SaldosDiario
					SET DiasActual = IsNull( ( CASE WHEN DateDiff(Day,FechaVencimiento,FechaVista) <= 0 THEN 0 ELSE DateDiff(Day,FechaVencimiento,FechaVista) END ), 0 )
					WHERE FechaVista = @Cursor_FechaVista
				
					UPDATE A
					SET A.DiasActualReal = IsNull( ( CASE WHEN DateDiff(Day,A.FechaVencimiento,A.FechaVista) <= 0 THEN 0 ELSE B.DiasActualReal+1 END ),0 )
					FROM dbo.VariacionTramos_SaldosDiario A
					LEFT JOIN dbo.VariacionTramos_SaldosDiario B ON A.Cod_Credito = B.Cod_Credito AND DATEADD(DAY,-1,A.FechaVista) = B.FechaVista
					WHERE A.FechaVista = @Cursor_FechaVista
			
				END

			FETCH NEXT FROM CurSaldos INTO @Cursor_FechaVista, @Cursor_DiaBPE, @Cursor_FlagCierre
			END
			CLOSE CurSaldos
			DEALLOCATE CurSaldos

			-------------------------
			-- ARMAMOS CONSOLIDADO --
			-------------------------

			INSERT INTO dbo.VariacionTramos_Consolidado ( MesVista, FechaVista, Cod_Unico, Cod_Credito, Cod_CreditoActual, Producto, SubProducto, Cod_TipoEmpresa, FechaVencimiento, DiasActual, DiasActualReal, SaldoActual, Flag_RedCobranza, Flag_CierreAnt )
			SELECT
				@Bucle_MesActual As MesVista,
				Sd.FechaVista,
				Sd.Cod_Unico,
				Sd.Cod_Credito,
				Sd.Cod_CreditoActual,
				Sd.Producto,
				Sd.SubProducto,
				Sd.Cod_TipoEmpresa,
				Sd.FechaVencimiento,
			
				/*( CASE
					WHEN DateDiff(Day,Sc.FechaVencimiento,@Bucle_FechaInicio_MesAct) <= 0 THEN 0
					ELSE DateDiff(Day,Sc.FechaVencimiento,@Bucle_FechaInicio_MesAct)
				END ) As DiasInicio,*/

				Sd.DiasActual,
				Sd.DiasActualReal,
				Sd.SaldoActual,

				NULL Flag_RedCobranza,

				--( CASE WHEN Bc.Cod_Credito Is Not NULL THEN 1 ELSE 0 END ) As Flag_RedCobranza,

				Sd.Flag_CierreAnt

			FROM dbo.VariacionTramos_SaldosDiario Sd
			--LEFT JOIN dbo.VariacionTramos_BaseCobranza Bc On Sd.Cod_Credito = Bc.Cod_Credito

			----------------------------
			-- MARCAMOS CRÉDITOS CIMA --
			----------------------------

			UPDATE Cs
			SET Cs.Flag_Cima = ( CASE WHEN Cima.COD_CREDITO Is Not NULL THEN 1 ELSE 0 END )
			FROM dbo.VariacionTramos_Consolidado Cs
			LEFT JOIN BPE.dbo.vw_CREDITOS_CIMA Cima On Cs.Cod_Credito = Cima.COD_CREDITO

			----------------------------
			-- EXPORTAMOS CONSOLIDADO --
			----------------------------

			INSERT INTO BPE.dbo.Reporte_VariacionTramos ( FechaActual, Cod_TipoVista, MesVista, FechaVista, Cod_Unico, Cod_Credito, Cod_CreditoActual, Producto, SubProducto, Cod_TipoEmpresa, FechaVencimiento, DiasActual, DiasActualReal, SaldoActual, Flag_RedCobranza, Flag_Cima, Flag_CierreAnt )
			SELECT
				@FechaSaldos, @Cod_TipoVista, MesVista, FechaVista, Cod_Unico, Cod_Credito, Cod_CreditoActual, Producto, SubProducto, Cod_TipoEmpresa, FechaVencimiento, DiasActual, DiasActualReal, SaldoActual, Flag_RedCobranza, Flag_Cima, Flag_CierreAnt
			FROM dbo.VariacionTramos_Consolidado
		
			SET @Cod_TipoVista = @Cod_TipoVista + 1

		END

		----------------------------------
		-- ELIMINAMOS TABLAS TEMPORALES --
		----------------------------------

		IF OBJECT_ID('dbo.VariacionTramos_BaseCobranza') Is Not NULL DROP TABLE dbo.VariacionTramos_BaseCobranza
		IF OBJECT_ID('dbo.VariacionTramos_Dias') Is Not NULL DROP TABLE dbo.VariacionTramos_Dias
		IF OBJECT_ID('dbo.VariacionTramos_SaldosDiario') Is Not NULL DROP TABLE dbo.VariacionTramos_SaldosDiario
		IF OBJECT_ID('dbo.VariacionTramos_Consolidado') Is Not NULL DROP TABLE dbo.VariacionTramos_Consolidado

		-----------------------
		-- FLAG REPROGRAMADO --
		-----------------------

		UPDATE A
		SET A.Flag_Reprogramado = ( CASE WHEN Rep.Cod_CreditoOrigen Is Not NULL THEN 1 ELSE 0 END )
		FROM BPE.dbo.Reporte_VariacionTramos A
		LEFT JOIN BPE.dbo.Base_Reprogramaciones Rep ON A.Cod_Credito = Rep.Cod_CreditoOrigen

		-----------------------------------
		-- MATRICES DE TRANSICION DIARIO --
		-----------------------------------
	

	--SELECT TOP 10 * FROM BPE.dbo.Reporte_MatricesTransicionDiario where fechavista = '2026-05-29' and cod_credito = '3000348890' ORDER BY MESVISTA DESC 
		TRUNCATE TABLE BPE.dbo.Reporte_MatricesTransicionDiario

		INSERT INTO BPE.dbo.Reporte_MatricesTransicionDiario (
			FechaActual, Cod_TipoVista, MesVista, Cod_Unico, Cod_Credito, Cod_CreditoActual, Flag_Reprogramado, Flag_Reactiva, Cod_TipoEmpresaIni, DiasActualRealIni, SaldoActualIni, FechaVista, Cod_TipoEmpresaFin, DiasActualRealFin, SaldoActualFin)
		SELECT C.FechaActual, C.Cod_TipoVista, C.MesVista, 
			   C.Cod_Unico, C.Cod_Credito, C.Cod_CreditoActual, C.Flag_Reprogramado,
			   CASE WHEN E.NROPROD_X IS NOT NULL THEN 1 ELSE 0 END AS Flag_Reactiva,
			   C.Cod_TipoEmpresa AS Cod_TipoEmpresaIni, C.DiasActualReal AS DiasActualRealIni, C.SaldoActual AS SaldoActualIni,
			   C.Fecha AS FechaVista,
			   D.Cod_TipoEmpresa AS Cod_TipoEmpresaFin, D.DiasActualReal AS DiasActualRealFin, D.SaldoActual AS SaldoActualFin 
		FROM (
			SELECT A.*, B.FechaVista As Fecha
			FROM (
				SELECT * FROM BPE.dbo.Reporte_VariacionTramos
				WHERE Flag_CierreAnt = 1
			) A
			CROSS JOIN (
				SELECT DISTINCT
					MesVista, FechaVista
				FROM BPE.dbo.Reporte_VariacionTramos
				WHERE Flag_CierreAnt = 0
			) B
			WHERE
				A.MesVista = B.MesVista
		) C
		LEFT JOIN BPE.dbo.Reporte_VariacionTramos D ON C.Fecha = D.FechaVista AND C.Cod_Credito = D.Cod_Credito AND D.Flag_CierreAnt = 0
		LEFT JOIN (
			SELECT DISTINCT NROPROD_X
			FROM BPE.dbo.vw_DESEMBOLSOS
			WHERE PRODUCTO_Recod LIKE '%REAC%' OR CAMPANA LIKE '%REAC%'
		) E ON C.Cod_Credito = E.NROPROD_X

		-------------------
		-- GUARDAMOS LOG --
		-------------------

		EXEC dbo.sp_Sistema_Actualizar_Proceso @id_Proceso, @FechaProceso
		EXEC dbo.sp_Sistema_Registrar_Log @id_Proceso, 0, '', @FechaProceso

	END

END
