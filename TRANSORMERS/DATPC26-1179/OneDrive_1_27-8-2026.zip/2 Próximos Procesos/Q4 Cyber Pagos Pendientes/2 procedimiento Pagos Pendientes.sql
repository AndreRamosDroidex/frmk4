-- Sandbox Usuario
USE BPE_Procesamientos 
ALTER PROCEDURE [dbo].[sp_Cargar_CyberCuotasPendientes_ProcesarDatos]
AS
BEGIN

	DECLARE
		@Flag_Continuar INT,
		@id_Proceso smallint,
		@FechaActual date,
		@FechaProceso VARCHAR(8)

	SET @id_Proceso = 81 
	SET @FechaActual = GETDATE()
	SET @FechaProceso = Convert(VARCHAR(8),@FechaActual,112) 
	SET @Flag_Continuar = 0

	
	-- ==============================
	-- Cod Credito
	-- ============================== 
	UPDATE	BPE_Procesamientos..Cyber_Pagos_Pendientes
	SET		COD_CREDITO = BPE.[dbo].[fn_Cad_FormatoCodigo](SUBSTRING(CUENTA_CYBER, 1,8)), 
			FECHA_INFORMACION = SUBSTRING(FECINFORMACION,1,4) +'-'+ SUBSTRING(FECINFORMACION,5,2) +'-'+ SUBSTRING(FECINFORMACION,7,2) 


	-- ==============================
	-- Fuente Cyber 
	-- ============================== 
	TRUNCATE TABLE BPE.DBO.Cyber_Pagos_Pendientes

	INSERT INTO BPE.DBO.Cyber_Pagos_Pendientes (COD_CREDITO,CU, CUENTA_CYBER, MONEDA, NUMERO_CUOTA, IMPORTE_TOTAL_CUOTA, CAPITAL, INTERES, INTERES_COMPENSATORIO, INTERES_MORATORIO, FECHA_INFORMACION, FECHA_CARGA)
	SELECT	COD_CREDITO,CU, CUENTA_CYBER, MONEDA, NUMERO_CUOTA, IMPORTE_TOTAL_CUOTA, CAPITAL, INTERES, INTERES_COMPENSATORIO, INTERES_MORATORIO, FECHA_INFORMACION, FECHA_CARGA 
	FROM	BPE_Procesamientos..Cyber_Pagos_Pendientes


	-- =======================================
	-- GUARDAMOS HISTORICO --
	-- =======================================

	DECLARE @FechaActual_x DATE;
	SELECT DISTINCT @FechaActual_x = FECHA_CARGA FROM BPE.dbo.Cyber_Pagos_Pendientes;

	IF EXISTS (SELECT 1 FROM BPE.dbo.Cyber_Pagos_Pendientes_Hist WHERE FECHA_CARGA = @FechaActual_x)
	BEGIN
		DELETE FROM BPE.dbo.Cyber_Pagos_Pendientes_Hist 
		WHERE FECHA_CARGA = @FechaActual_x;
	END


	INSERT INTO BPE.dbo.Cyber_Pagos_Pendientes_Hist 
		(CODMES, COD_CREDITO, CU, CUENTA_CYBER, MONEDA, NUMERO_CUOTA, 
		 IMPORTE_TOTAL_CUOTA, CAPITAL, INTERES, INTERES_COMPENSATORIO, 
		 INTERES_MORATORIO, FECHA_INFORMACION, FECHA_CARGA)
	SELECT 
		SUBSTRING(CONVERT(VARCHAR, FECHA_CARGA, 112), 1, 6), -- Genera '202605'
		COD_CREDITO, 
		CU, 
		CUENTA_CYBER, 
		MONEDA, 
		NUMERO_CUOTA, 
		IMPORTE_TOTAL_CUOTA, 
		CAPITAL, 
		INTERES, 
		INTERES_COMPENSATORIO, 
		INTERES_MORATORIO, 
		FECHA_INFORMACION, 
		FECHA_CARGA
	FROM BPE.dbo.Cyber_Pagos_Pendientes;


	-- =======================================
	-- GUARDAMOS LOG --
	-- =======================================
	-- Proceso General
	-- Está en el ETL
	---IF ( SELECT Count(*) FROM BPE.DBO.Cyber_Pagos_Pendientes WHERE FECHA_CARGA = @FechaActual) > 0
	---BEGIN
	---	EXEC dbo.sp_Sistema_Actualizar_Proceso @id_Proceso, @FechaProceso
	---	EXEC dbo.sp_Sistema_Registrar_Log @id_Proceso, 0, '', @FechaProceso
	---END


END
