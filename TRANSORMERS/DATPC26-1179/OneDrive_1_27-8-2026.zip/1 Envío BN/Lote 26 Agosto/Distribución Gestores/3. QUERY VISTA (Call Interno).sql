USE [BPE]
GO

/****** Object:  View [cob].[vw_Excel_Asignacion_Interbank]    Script Date: 25/08/2026 12:16:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER VIEW [cob].[vw_Excel_Asignacion_Interbank] AS
SELECT
    A.Codmes,
    A.Fecha_envio,
    A.Fecha,
    A.DM_Actual,
    A.Zonal,
    A.Departamento_negocio,
    A.Provincia_negocio,
    A.Centro,
    A.Cliente,
    A.Codunicocli,
    A.Cod_credito,
    A.Fecha_vencimiento,
    A.Monto_cuotas_vencidas,
    A.Saldo_actual,
    A.Producto,
    A.Fecha_ultimo_pago,
    A.Cuenta_cyber,
    A.Grupo_cyber,
    A.Nr_cobranza,
    A.Moneda,
    A.Cuotas,
    A.Tipo_base,
    ISNULL(A.Ejecutivo_asignado, '') AS Ejecutivo_asignado,
    A.Segmento,
    ISNULL(A.Status_Reactiva, '') AS Status_Reactiva,
    A.Flag_ClienteBPI,
    A.Telefono1,
    A.Telefono2,
    A.Telefono3,
    A.Telefono4,
    A.Telefono5,
    A.Telefono6,
    A.Telefono7,
    A.Telefono8,
    A.Telefono9,
    A.Telefono10,
    ISNULL(A.RRLL1, '') AS RRLL1,
    ISNULL(A.RRLL2, '') AS RRLL2,
    A.MontoCuota_1 AS [Valor cuota],
    A.Cuotas_Pagadas,
    A.Cuotas_Atrasadas,
    A.Distrito_negocio,
    A.DIRECCION_NEGOCIO,
    ISNULL(A.AsignMes_Base, '') AS AsignMes_Base,
    ISNULL(
        A.AsignMes_Potencial_Recuperaciones,
        ''
    ) AS AsignMes_Potencial_Recuperaciones,
    A.Prox_FechaVen_Pago,
    A.Plazo_1,
    A.Cuota_flat_1,
    A.Plazo_2,
    A.Cuota_flat_2,
    A.Plazo_3,
    A.Cuota_flat_3,
    A.Plazo_4,
    A.Cuota_flat_4,
    CASE
        WHEN A.Flag_Cliente_Reactiva = 1 THEN 'SI'
        ELSE 'NO'
    END AS Cliente_Reactiva,
    A.Cant_Cred_Reactiva,
    A.Cant_Cred_Reactiva_Reprogr,
    A.Cant_Cred_Reactiva_Recup,
    A.Universo,
    A.Tramo_asignacion,
    A.Gestor_asignado,
    A.RRLL1_TipoDocumento,
    A.RRLL1_NumeroDocumento,
    A.RRLL2_TipoDocumento,
    A.RRLL2_NumeroDocumento,
    A.TipoBase_BadBank,
    A.Debito_Cuenta_Cargo,
    A.Flag_impulsa,
    A.Impulso_Tipo,
    A.Impulso_Mes_venc_cuota_comp,
    A.Impulso_Monto_cuota_compl,
    A.Impulso_Tipo_cuota_mes,
    CASE
        WHEN A.PdP_Estado = 'PENDIENTE' THEN 0
        WHEN A.PdP_Estado IS NULL
             OR A.PdP_Estado = 'ROTA' THEN 1
        ELSE 1
    END AS Flag_Gestionable,
    A.PdP_Fecha_Gestion AS PdP_Fecha_inicio,
    A.PdP_Fecha_Fin,
    A.PdP_Estado,
    A.Email,
    A.Ultima_Gestion,
    A.Prioridad_Gestion,
    A.NumeroDocumentoCliente AS [DNI/RUC],
    A.TelefonoPlin,
    A.Clasificacion_SSFF,
    A.Cant_Deudas_Otras_Entidades,
    A.Pdp_Rotas,
    A.Flag_ClienteNuevo,
    A.Fecha_Primera_Asignacion,
    A.Arquetipo_IBK,
    A.Arquetipo_SIF,
    A.Endeudamiento_SIF,
    A.Giro,
    A.FechaDesembolso,
    A.Afectacion_FEN AS ZonaAfectada_FEN,
    C.GASTO_CLIENTE,
    CASE
        WHEN D.PERIODO_GRACIA IS NULL
            THEN 'Producto Estado - No aplica SDP'
        ELSE CAST(D.PERIODO_GRACIA AS VARCHAR(100))
    END AS PERIODO_GRACIA,
    CASE
        WHEN D.CALIFICA_REPROGRAMACION IS NULL
            THEN 'Producto Estado - No aplica SDP'
        ELSE CAST(D.CALIFICA_REPROGRAMACION AS VARCHAR(100))
    END AS CALIFICA_REPROGRAMACION,
    CASE
        WHEN D.CALIFICA_REFINANCIAMIENTO IS NULL
            THEN 'Producto Estado - No aplica SDP'
        ELSE CAST(D.CALIFICA_REFINANCIAMIENTO AS VARCHAR(100))
    END AS CALIFICA_REFINANCIAMIENTO,
    CASE
        WHEN D.CALIFICA_REPROGRAMACION IN (
            'Aprobado - Con Excepción',
            'Preaprobado - Condicionado a revisión',
            'Aprobado - Campaña'
        ) THEN 'SI'
        WHEN D.CALIFICA_REPROGRAMACION =
             'Pagar 1 cuota(s) para acceder a reprogramación'
            THEN 'SI - 1C'
        WHEN D.CALIFICA_REPROGRAMACION =
             'Pagar 2 cuota(s) para acceder a reprogramación'
            THEN 'SI - 2C'
        WHEN D.CALIFICA_REPROGRAMACION =
             'Pagar 3 cuota(s) para acceder a reprogramación'
            THEN 'SI - 3C'
        ELSE 'NO'
    END AS CLOUD_REPRO,
    CASE
        WHEN D.CALIFICA_REFINANCIAMIENTO IN (
            'Preaprobado - Condicionado a revisión',
            'Preaprobado - Campaña'
        ) THEN 'Refi'
        WHEN D.CALIFICA_REFINANCIAMIENTO IN (
            'Preparobado - 1 cuota par acceder'
        ) THEN 'Refi pago 1 c'
        ELSE ''
    END AS CLOUD_REFI,
    A.Grupo_Intensidad,
    A.Resultado,
    ISNULL(
        STUFF(
            CASE
                WHEN ISNULL(Foc.Focalizacion_Base, '') <> ''
                    THEN ' - ' + Foc.Focalizacion_Base
                ELSE ''
            END
            + CASE
                WHEN ISNULL(Mark.FPD_SPD_Mark, '') <> ''
                    THEN ' - ' + Mark.FPD_SPD_Mark
                ELSE ''
            END
            + CASE
                WHEN NP.COD_CREDITO IS NOT NULL
                    THEN ' - ' + NP.PERFIL
                ELSE ''
            END,
            1,
            3,
            ''
        ),
        ''
    ) AS Focalizacion,
    CASE
        WHEN CS.Cod_Credito IS NULL THEN 'NO'
        ELSE 'SI'
    END AS Flag_COBIS
FROM cob.AsignacionCall_Diario AS A
LEFT JOIN BPE.COB.BASE_EFECTIVIDAD_DIARIA AS C
    ON A.Cod_credito = C.COD_CREDITO
    AND C.FECHA = CAST(GETDATE() - 2 AS DATE)
LEFT JOIN (
    SELECT
        *,
        ROW_NUMBER() OVER (
            PARTITION BY COD_CREDITO
            ORDER BY Codmes DESC
        ) AS rn
    FROM bpe.cob.base_final_sdps_evaluadas
) AS D
    ON A.Cod_credito = D.COD_CREDITO
    AND A.Codmes = D.CODMES
    AND D.rn = 1
LEFT JOIN BPE_CRUCES.B44825.BASE_TOPS_GASTO AS G
    ON A.Codunicocli = G.CODUNICOCLI
    AND G.CODMES = YEAR(GETDATE() - 1) * 100
                   + MONTH(GETDATE() - 1)
LEFT JOIN BPE_CRUCES.B44825.BASE_EW AS EW
    ON A.Cod_credito = EW.COD_CREDITO
    AND EW.CODMES = YEAR(GETDATE() - 1) * 100
                    + MONTH(GETDATE() - 1)
CROSS APPLY (
    SELECT
        ISNULL(
            CASE
                WHEN G.CODUNICOCLI IS NOT NULL
                     AND EW.COD_CREDITO IS NOT NULL
                     AND (
                         ISNULL(EW.FLG_VENDORS, 0) = 1
                         OR ISNULL(EW.FLG_BBP, 0) = 1
                         OR ISNULL(EW.Endeudamiento_SIF, '') =
                            'Incremento deuda en el SIF'
                         OR ISNULL(EW.Cod_Clasificacion_Act, 0) IN (3, 4)
                     )
                THEN
                    G.TOP_PROV
                    + ' - EW: '
                    + LTRIM(
                        CASE
                            WHEN ISNULL(EW.FLG_VENDORS, 0) = 1
                                THEN 'Vendors'
                            ELSE ''
                        END
                        + CASE
                            WHEN ISNULL(EW.FLG_BBP, 0) = 1
                                THEN ' BBP'
                            ELSE ''
                        END
                        + CASE
                            WHEN ISNULL(EW.Endeudamiento_SIF, '') =
                                 'Incremento deuda en el SIF'
                                THEN ' Incremento deuda SIF'
                            ELSE ''
                        END
                        + CASE
                            WHEN ISNULL(EW.Cod_Clasificacion_Act, 0)
                                 IN (3, 4)
                                THEN ' Dudoso-Perdida'
                            ELSE ''
                        END
                    )
                WHEN G.CODUNICOCLI IS NOT NULL
                    THEN G.TOP_PROV
                WHEN EW.COD_CREDITO IS NOT NULL
                     AND (
                         ISNULL(EW.FLG_VENDORS, 0) = 1
                         OR ISNULL(EW.FLG_BBP, 0) = 1
                         OR ISNULL(EW.Endeudamiento_SIF, '') =
                            'Incremento deuda en el SIF'
                         OR ISNULL(EW.Cod_Clasificacion_Act, 0) IN (3, 4)
                     )
                THEN
                    'EW: '
                    + LTRIM(
                        CASE
                            WHEN ISNULL(EW.FLG_VENDORS, 0) = 1
                                THEN 'Vendors'
                            ELSE ''
                        END
                        + CASE
                            WHEN ISNULL(EW.FLG_BBP, 0) = 1
                                THEN ' BBP'
                            ELSE ''
                        END
                        + CASE
                            WHEN ISNULL(EW.Endeudamiento_SIF, '') =
                                 'Incremento deuda en el SIF'
                                THEN ' Incremento deuda SIF'
                            ELSE ''
                        END
                        + CASE
                            WHEN ISNULL(EW.Cod_Clasificacion_Act, 0)
                                 IN (3, 4)
                                THEN ' Dudoso-Perdida'
                            ELSE ''
                        END
                    )
                ELSE NULL
            END,
            ''
        ) AS Focalizacion_Base
) AS Foc
CROSS APPLY (
    SELECT
        CASE
            WHEN A.DM_Actual >= 10
                 AND A.Cuotas_Pagadas = 0
                 AND A.Saldo_actual >= 100000
                THEN 'FPD'
            WHEN A.DM_Actual >= 10
                 AND A.Cuotas_Pagadas = 1
                 AND A.Saldo_actual >= 100000
                THEN 'SPD'
            ELSE ''
        END AS FPD_SPD_Mark
) AS Mark
LEFT JOIN (
    SELECT COD_CREDITO
    FROM BPE..VW_SOLICITUDES
    WHERE EstadoSolicitud LIKE '%COBIS%'
) AS CS
    ON A.Cod_credito = CS.Cod_Credito
LEFT JOIN (
    SELECT DISTINCT
		CODMES,
        COD_CREDITO,
        PERFIL
    FROM BPE_CRUCES.B47407.FOCALIZACION_NUEVOPERFIL
    WHERE COD_CREDITO IS NOT NULL
) AS NP
    ON A.Cod_credito = NP.COD_CREDITO AND A.Codmes = NP.CODMES
WHERE A.Proveedor_BaseCall IN ('Interbank');
GO


