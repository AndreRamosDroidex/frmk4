USE [BPE]
GO

/****** Object:  View [cob].[vw_Excel_Asignacion_Campo]    Script Date: 25/08/2026 11:45:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER VIEW [cob].[vw_Excel_Asignacion_Campo] AS
SELECT        A.Codmes, A.Fecha_envio, A.Fecha, A.DM_Actual, CASE WHEN Departamento_negocio IN ('LIMA', 'CALLAO') THEN 'Lima' ELSE 'Provincia' END AS Zonal_Cobranza, A.Zonal, A.Departamento_negocio, A.Provincia_negocio, 
                         A.Centro, A.Cliente, A.Codunicocli, A.Cod_credito, A.Fecha_vencimiento, A.Monto_cuotas_vencidas, A.Saldo_actual, A.Producto, A.Fecha_ultimo_pago, A.Cuenta_cyber, A.Grupo_cyber, A.Nr_cobranza, A.Moneda, A.Cuotas, 
                         A.Tipo_base, ISNULL(A.Ejecutivo_asignado, '') AS Ejecutivo_asignado, COR.Correo_Ejecutivo, A.Segmento, ISNULL(A.Status_Reactiva, '') AS Status_Reactiva, A.Telefono1, A.Telefono2, A.Telefono3, A.Telefono4, A.Telefono5, 
                         ISNULL(A.RRLL1, '') AS RRLL1, ISNULL(A.RRLL2, '') AS RRLL2, A.MontoCuota_1 AS [Valor cuota], A.Cuotas_pagadas, A.Cuotas_atrasadas, A.Distrito_negocio, A.Direccion_negocio, ISNULL(A.AsignMes_Base, '') 
                         AS AsignMes_Base, ISNULL(A.AsignMes_Potencial_Recuperaciones, '') AS AsignMes_Potencial_Recuperaciones, A.Prox_FechaVen_Pago, A.Plazo_1, A.Cuota_flat_1, A.Plazo_2, A.Cuota_flat_2, A.Plazo_3, A.Cuota_flat_3, 
                         A.Plazo_4, A.Cuota_flat_4, CASE WHEN Flag_Cliente_Reactiva = 1 THEN 'SI' ELSE 'NO' END AS Cliente_Reactiva, A.Universo, A.Proveedor_BaseCall, A.Tramo_asignacion, A.Gestor_asignado, A.TipoGestionGestor, 
                         A.Flag_nuevo_ingreso, A.RRLL1_TipoDocumento, A.RRLL1_NumeroDocumento, A.RRLL2_TipoDocumento, A.RRLL2_NumeroDocumento, A.Debito_Cuenta_Cargo, A.Flag_impulsa, A.Impulso_Tipo, 
                         A.Impulso_Mes_venc_cuota_comp, A.Impulso_Monto_cuota_compl, A.Impulso_Tipo_cuota_mes, A.Fecha_Primera_Asignacion, A.Arquetipo_IBK, A.Arquetipo_SIF, A.Endeudamiento_SIF, A.Afectacion_FEN AS ZonaAfectada_FEN, 
                         A.Email, A.Prioridad_Gestion, B.Q_Creditos, CASE WHEN B.Q_Creditos = 1 THEN A.Saldo_actual ELSE B.SALDO_TOTAL END AS Saldo_Total, C.GASTO_CLIENTE, CASE WHEN D .PERIODO_GRACIA IS NULL 
                         THEN 'Producto Estado - No aplica SDP' ELSE CAST(D .PERIODO_GRACIA AS VARCHAR(100)) END AS PERIODO_GRACIA, CASE WHEN D .CALIFICA_REPROGRAMACION IS NULL 
                         THEN 'Producto Estado - No aplica SDP' ELSE CAST(D .CALIFICA_REPROGRAMACION AS VARCHAR(100)) END AS CALIFICA_REPROGRAMACION, CASE WHEN D .CALIFICA_REFINANCIAMIENTO IS NULL 
                         THEN 'Producto Estado - No aplica SDP' ELSE CAST(D .CALIFICA_REFINANCIAMIENTO AS VARCHAR(100)) END AS CALIFICA_REFINANCIAMIENTO, CASE WHEN D .CAMPAÑA_DSCTO IS NULL 
                         THEN 'SIN DESCUENTO' ELSE CAST(D .CAMPAÑA_DSCTO AS VARCHAR(100)) END AS CAMPAÑA_DSCTO, ISNULL(STUFF(CASE WHEN ISNULL(Foc.Focalizacion_Base, '') 
                         <> '' THEN ' - ' + Foc.Focalizacion_Base ELSE '' END + CASE WHEN ISNULL(Mark.FPD_SPD_Mark, '') <> '' THEN ' - ' + Mark.FPD_SPD_Mark ELSE '' END + CASE WHEN NP.COD_CREDITO IS NOT NULL 
                         THEN ' - ' + NP.PERFIL ELSE '' END, 1, 3, ''), '') AS Focalizacion, CASE WHEN (A.Tramo_asignacion = 'Temprana' OR
                         Arquetipo_SIF = '') AND A.Arquetipo_IBK IN ('7. Buen Habito', '6. Nuevo') THEN '1-2' WHEN (A.Tramo_asignacion = 'Temprana' OR
                         Arquetipo_SIF = '') AND A.Arquetipo_IBK IN ('4. Autocura 1', '5. Autocura 2') THEN '3' WHEN (A.Tramo_asignacion = 'Temprana' OR
                         Arquetipo_SIF = '') AND A.Arquetipo_IBK IN ('3. Pagador inconsistente') THEN '4' WHEN (A.Tramo_asignacion = 'Temprana' OR
                         Arquetipo_SIF = '') AND A.Arquetipo_IBK IN ('2. Mejorando') THEN '6' WHEN (A.Tramo_asignacion = 'Temprana' OR
                         Arquetipo_SIF = '') AND A.Arquetipo_IBK IN ('1. Con dificultad') THEN '7' WHEN A.Tramo_asignacion IN ('Intermedia', 'Tardia') AND Arquetipo_SIF IN ('1. Autocura', '2. Comprometido') 
                         THEN '3' WHEN A.Tramo_asignacion IN ('Intermedia', 'Tardia') AND Arquetipo_SIF = '3. Evasivos_Mejora' THEN '7' WHEN A.Tramo_asignacion IN ('Intermedia', 'Tardia') AND Arquetipo_SIF IN ('4. Evasivos', '5. Complicado') 
                         THEN '9' END AS NRO_VISITAS
FROM            cob.AsignacionGestores_Diario AS A LEFT JOIN
                             (SELECT        B.CIF_KEY, COUNT(DISTINCT B.NROPROD_X) AS Q_Creditos, ROUND(SUM(B.SALDO) * C.TipoCambio, 2) AS SALDO_TOTAL
                               FROM            dbo.SaldosDiario AS B INNER JOIN
                                                         dbo.vw_DatosCierre AS C ON C.Mes = SUBSTRING(CONVERT(VARCHAR, DATEADD(MONTH, - 1, GETDATE()), 112), 1, 6)
                               GROUP BY B.CIF_KEY, C.TipoCambio) AS B ON A.Codunicocli = B.CIF_KEY LEFT JOIN
                         BPE.COB.BASE_EFECTIVIDAD_DIARIA AS C ON A.Cod_credito = C.COD_CREDITO AND C.FECHA = CAST(GETDATE() - 2 AS DATE) LEFT JOIN
                             (SELECT        *, ROW_NUMBER() OVER (PARTITION BY COD_CREDITO
                               ORDER BY Codmes DESC) AS rn
FROM            bpe.cob.base_final_sdps_evaluadas) AS D ON A.Cod_credito = D .COD_CREDITO AND A.Codmes = D .CODMES AND D .rn = 1 LEFT JOIN
BPE_CRUCES.B44825.BASE_TOPS_GASTO AS G ON A.Codunicocli = G.CODUNICOCLI AND G.CODMES = YEAR(GETDATE() - 1) * 100 + MONTH(GETDATE() - 1) LEFT JOIN
BPE_CRUCES.B44825.BASE_EW AS EW ON A.Cod_credito = EW.COD_CREDITO AND EW.CODMES = YEAR(GETDATE() - 1) * 100 + MONTH(GETDATE() - 1) CROSS APPLY
    (SELECT        ISNULL(CASE WHEN G.CODUNICOCLI IS NOT NULL AND EW.COD_CREDITO IS NOT NULL AND (ISNULL(EW.FLG_VENDORS, 0) = 1 OR
                                ISNULL(EW.FLG_BBP, 0) = 1 OR
                                ISNULL(EW.Endeudamiento_SIF, '') = 'Incremento deuda en el SIF' OR
                                ISNULL(EW.Cod_Clasificacion_Act, 0) IN (3, 4)) THEN G.TOP_PROV + ' - EW: ' + LTRIM(CASE WHEN ISNULL(EW.FLG_VENDORS, 0) = 1 THEN 'Vendors' ELSE '' END + CASE WHEN ISNULL(EW.FLG_BBP, 0) 
                                = 1 THEN ' BBP' ELSE '' END + CASE WHEN ISNULL(EW.Endeudamiento_SIF, '') = 'Incremento deuda en el SIF' THEN ' Incremento deuda SIF' ELSE '' END + CASE WHEN ISNULL(EW.Cod_Clasificacion_Act, 0) IN (3, 4) 
                                THEN ' Dudoso-Perdida' ELSE '' END) WHEN G.CODUNICOCLI IS NOT NULL THEN G.TOP_PROV WHEN EW.COD_CREDITO IS NOT NULL AND (ISNULL(EW.FLG_VENDORS, 0) = 1 OR
                                ISNULL(EW.FLG_BBP, 0) = 1 OR
                                ISNULL(EW.Endeudamiento_SIF, '') = 'Incremento deuda en el SIF' OR
                                ISNULL(EW.Cod_Clasificacion_Act, 0) IN (3, 4)) THEN 'EW: ' + LTRIM(CASE WHEN ISNULL(EW.FLG_VENDORS, 0) = 1 THEN 'Vendors' ELSE '' END + CASE WHEN ISNULL(EW.FLG_BBP, 0) 
                                = 1 THEN ' BBP' ELSE '' END + CASE WHEN ISNULL(EW.Endeudamiento_SIF, '') = 'Incremento deuda en el SIF' THEN ' Incremento deuda SIF' ELSE '' END + CASE WHEN ISNULL(EW.Cod_Clasificacion_Act, 0) IN (3, 4) 
                                THEN ' Dudoso-Perdida' ELSE '' END) ELSE NULL END, '') AS Focalizacion_Base) AS Foc CROSS APPLY
    (SELECT        CASE WHEN A.DM_Actual >= 10 AND A.Cuotas_Pagadas = 0 AND A.Saldo_actual >= 100000 THEN 'FPD' WHEN A.DM_Actual >= 10 AND A.Cuotas_Pagadas = 1 AND 
                                A.Saldo_actual >= 100000 THEN 'SPD' ELSE '' END AS FPD_SPD_Mark) AS Mark LEFT JOIN
    (SELECT DISTINCT CODMES, COD_CREDITO, PERFIL
      FROM            BPE_CRUCES.B47407.FOCALIZACION_NUEVOPERFIL
      WHERE        COD_CREDITO IS NOT NULL) NP ON A.Cod_credito = NP.COD_CREDITO AND A.Codmes = NP.CODMES
	  LEFT JOIN
    (SELECT        X.EJECUTIVO, MAX(Y.CORREO) AS Correo_Ejecutivo
      FROM            BPE_Cruces.B45235.Cartera_asignada X LEFT JOIN
                                BPE_Cruces.B45235.Input_PlantaActiva Y ON X.COD_EJECUTIVO = Y.REGISTRO
      WHERE        X.PERIODO =
                                    (SELECT        MAX(PERIODO)
                                      FROM            BPE_Cruces.B45235.Cartera_asignada)
      GROUP BY X.EJECUTIVO) COR ON A.Ejecutivo_asignado = COR.EJECUTIVO
WHERE        A.Gestor_asignado IN ('CARDENAS URQUIZO ERNESTO MARTI', 'MENDOZA VARGAS JOSE SALOME', 'ASCOY CAPRISTAN EUSEBIO PABLO', 'JUAN RAMOS', 'JIBAJA HERRERA JOSUE JAVIER', 
                         'PICON MATTA JULIAN MACEDONIO', 'CASTILLO PAREDES CESAR EMILIO', 'ACOSTA GARCIA ANGEL ENRIQUE', 'SALDAÑA YARLAQUE MARKO DANILO', 'SIN_GESTOR_BPE');
GO