
/*
TABLAS FUENTES:

BPE.cob.AsignacionDiaria		--> BASE PRINCIPAL
BPE.cob.vw_BASE_COBRANZAS		--> BASE COMPLEMENTARIA
BPE.dbo.SaldosDiario	--> DM, VENCIMIENTO, TRAMO, ETC
BPE.dbo.Cyber_Pagos_Pendientes		--> CUOTAS PENDIENTES, TRAMO, CAPITAL, ETC.
BPE.dbo.vw_Cronogramas		--> CUOTAS VENCIDAS, PAGOS, PLAZOS, ETC.
BPE.dbo.vw_Solicitudes		--> NEGOCIO, GIRO, ETC.
BPE.dbo.vw_PersonasRelacionadas		--> REPRESENTANTES LEGALES
BPE.dbo.vw_PersonasRelacionadas_CU		--> REPRESENTANTES LEGALES COMPLEMENTARIO
BPE.cob.Prioridades_2025		--> NR COBRANZA, PRIORIDAD DE GESTION
BPE.dbo.vw_Base_Reactiva		--> CREDITOS REACTIVA
BPE.dbo.vw_CREDITOS_CIMA		--> CREDITOS CIMA
BPE.cob.vw_BASE_EXCEPCIONES		--> EXCLUSION DE CREDITOS DE LA ASIGNACION
BPE.cob.Gestores_Localizacion		--> GESTOR DE CAMPO SEGUN DEPARTAMENTO, PROVINCIA, ETC.
BPE.cob.MAESTRA_TELEFONOS		--> MAESTRA DE TELEFONOS
BPE.dbo.Clientes		--> CORREOS ELECTRONICOS
BPE.cob.TELEFONOS_GOBIERNO_ADICIONALES		--> COMPLEMENTO PARA TELEFONOS
BPE.cob.vw_Relacionados_Telf_complemento		--> COMPLEMENTO PARA TELEFONOS
BPE.cob.Base_Inhibicion_Telefonos		--> EXCLUSION PARA TELEFONOS
BPE.cob.Base_Inhibicion_Telefonos_Periodica	* (SE PUEDE PRESCINDIR)	--> EXCLUSION PARA TELEFONOS (NO ACTUALIZADO)
BPE.cob.Planta_Activa		--> CODIGOS EJECUTIVOS ACTIVOS DEL MES
BPE.dbo.Catalogo_Usuarios		--> NOMBRES EJECUTIVOS ACTIVOS DEL MES
BPE.cob.BASE_REFINANCIADOS_COBRANZA	* (SE PUEDE PRESCINDIR)	--> ALTERNATIVAS DE FINANCIAMIENTO (NO ACTUALIZADO)
BPE.cob.Base_Potencial_Landing		--> POTENCIAL REPROGRAMADO
BPE.cob.Base_Potencial_Refinanciado		--> POTENCIAL REFINANCIADO
BPE.dbo.Base_Funnel_ReproReactivaFase2		--> ESTADO DE REPROGRAMACION REATIVA
BPE.cob.Clientes_BPI_Historico		--> CLIENTES BPI (?)
BPE.dbo.Base_Impulso		--> CREDITOS IMPULSA
BPE.cob.Base_Debito_Automatico		--> CREDITOS ASOCIADOS A DEBITO AUTOMATICO
BPE.cob.Asignacion_Gestores_Mensual		--> POTENCIAL RECUPERACIONES
BPE.dbo.Base_BadBank_Buro_FEN	* (SE PUEDE PRESCINDIR)		--> FLAG BADBANK BASADO EN FEN (NO ACTUALIZADO)
BPE.cob.vw_Base_Recuperaciones		--> CREDITOS EN RECUPERACIONES
BPE.cob.Base_PromesasDePago		--> PROMESAS DE PAGO DEL CLIENTE
BPE.cob.BASE_CYBER_GESTION_MENSUAL		--> ULTIMA ACCION Y RESULTADO DE LA GESTION DE COBRANZA
BPE.cob.Cobranza_Plin		--> NUMEROS PLIN
BPE.cob.Arquetipos_Cobranzas		--> ARQUETIPOS
BPE.dbo.Reporte_Senhami		--> AFECTACION FEN POR SENHAMI
BPE.cob.vw_EFECTIVIDAD_DIARIA		--> RESULTADO DE LA ULTIMA GESTION DE COBRANZA
BPE.cob.Base_Inhibiciones_honramientos		--> CREDITOS EN HONRAMIENTO


*/

ALTER PROCEDURE [dbo].[sp_AsignacionDiaria_DistribucionGestores] (@Flag_Reproceso BIT = 0)
AS
BEGIN
	DECLARE
		@Flag_Continuar INT = 0,
		@FechaAnterior	DATE,
		@FechaActual DATE,
		@FechaSaldos DATE,
		@FechaSaldos_1 DATE,
		@FechaIniProxMes DATE,
		@FechaProceso VARCHAR(8),
		@MesActual NUMERIC(6),
		@MesAnterior NUMERIC(6),
		@MesSiguiente NUMERIC(6),
		@Flag_DiaHabil BIT,
		@FLG_Validador SMALLINT = 0
		
		--SET @Flag_Reproceso = 1
		SET @FechaActual	= Getdate()
		SET	@FechaAnterior	= (SELECT TOP 1 FECHA FROM BPE.dbo.vw_Calendario WHERE FECHA < @FechaActual ORDER BY FECHA DESC)
		--select @FechaAnterior

		SET @FechaSaldos	= (SELECT TOP 1 FECHA FROM BPE.dbo.vw_Calendario WHERE FLAG_DIA_HABIL = 1 AND FECHA < @FechaActual ORDER BY FECHA DESC)

		select @FechaSaldos

		SET	@FechaSaldos_1	= (SELECT TOP 1 FECHA FROM BPE.dbo.vw_Calendario WHERE FLAG_DIA_HABIL = 1 AND FECHA < @FechaSaldos ORDER BY FECHA DESC)
		SET @FechaProceso	= Convert(VARCHAR(8),@FechaSaldos,112)
		SET @MesActual		= ( SELECT CODMES_BPE FROM BPE.dbo.vw_CALENDARIO WHERE FECHA = @FechaActual )
		SET @MesAnterior	= BPE.dbo.fn_Fec_Variar_Periodo(@MesActual,-1)
		SET @MesSiguiente	= BPE.dbo.fn_Fec_Variar_Periodo(@MesActual,1)
		SET	@FechaIniProxMes= (SELECT FECHA FROM BPE.dbo.vw_CALENDARIO WHERE flag_inicio = 1 and CODMES_BPE = @MesSiguiente) 
		SET @Flag_DiaHabil	= ( SELECT FLAG_DIA_HABIL FROM BPE.dbo.vw_CALENDARIO WHERE FECHA = Convert(DATE,@FechaActual) )

	-- Captura resultado del validador de cronogramas
	CREATE TABLE #Validador (FLG_CONTINUAR SMALLINT, ULTIMA_ACTUALIZACION_CRONOGRAMAS DATE)
	INSERT INTO #Validador EXEC [dbo].[SP_VALIDADOR_CRONOGRAMAS_MYP] 
	SELECT @FLG_Validador = FLG_CONTINUAR FROM #Validador
	DROP TABLE #Validador
		
	-- ===========================================
	-- Inputs: select max(FECHA_INFORMACION) from BPE.DBO.Cyber_Pagos_Pendientes
	-- SELECT TOP 3 * FROM BPE.cob.Base_Potencial_Refinanciado order by 1 desc			--mes					|| Responsable: JC
	-- ===========================================
	-- Validación para ejecutar el proceso: 
	IF ( @Flag_DiaHabil = 1 AND					--> El proceso solo se ejecuta en días hábiles
		(SELECT COUNT(*) FROM BPE.cob.AsignacionDiaria WHERE Fecha = @FechaSaldos ) > 0 AND 
		(SELECT COUNT(*) FROM BPE.cob.AsignacionCall_Diario WHERE Fecha = @FechaSaldos) = 0 AND
		@FLG_Validador = 1 AND					--> Cronogramas cargados hoy
		EXISTS (SELECT 1 FROM BPE.DBO.Cyber_Pagos_Pendientes WHERE CAST(FECHA_INFORMACION AS DATE) = @FechaAnterior)	--> Cyber_Pagos_Pendientes con data al D-1
			) OR @Flag_Reproceso = 1
	
	BEGIN 
	 SELECT 1
	 
		--=======================================
		-- Bases Temporales
		--=======================================
		--DistribucionAsignacion_BaseGestores
		/* 1  */ IF OBJECT_ID('BPE_Procesamientos.cob.DistribucionAsignacion_BasePrincipal') Is Not NULL DROP TABLE BPE_Procesamientos.cob.DistribucionAsignacion_BasePrincipal
		/* 2 */  IF OBJECT_ID('BPE_Procesamientos.cob.DistribucionAsignacion_BaseCall') Is Not NULL DROP TABLE BPE_Procesamientos.cob.DistribucionAsignacion_BaseCall
		/* 3 */  IF OBJECT_ID('BPE_Procesamientos.cob.DistribucionAsignacion_BaseGestores') Is Not NULL DROP TABLE BPE_Procesamientos.cob.DistribucionAsignacion_BaseGestores
		/* 4 */  IF OBJECT_ID('BPE_Procesamientos.cob.DistribucionAsignacion_UltimaGestion') Is Not NULL DROP TABLE BPE_Procesamientos.cob.DistribucionAsignacion_UltimaGestion 
		

		/* 1 */ CREATE TABLE BPE_Procesamientos.cob.DistribucionAsignacion_BasePrincipal 
				( Codmes numeric, 
				  Fecha_Envio date,
				  Fecha date, 
				  ---------------------------------
				  Accion_fin		 varchar(25),
				  Proveedor_BaseCall varchar(15),
				  ---------------------------------
				  Dm_actual			int, 
				  Codunicocli		varchar(10), 
				  Cod_credito		varchar(10), 
				  Fecha_vencimiento date, 
				  Monto_cuotas_vencidas float, 
				  Saldo_actual		float, 
				  Universo			varchar(25),
				  Tramo_asignacion	varchar(15), 
				  Producto			varchar(50), 
				  Zonal	varchar(15), Departamento_negocio varchar(30), Provincia_negocio varchar(30), Distrito_negocio	varchar(40), Direccion_negocio varchar(150), 
				  Centro		varchar(30), 
				  Cliente		varchar(100), 
				  Regejecutivo	varchar(8),
				  Moneda		varchar(7), 
				  Fecha_Ultimo_Pago date, 
				  Cuenta_Cyber	varchar(14), Grupo_Cyber smallint, NR_Cobranza	varchar(25), 
				  Tipo_base		varchar(11),
				  ---------------------------------
				  Tipo_Gestion_1 varchar(25), Tipo_Gestion_2 varchar(25), Tipo_Gestion_3 varchar(25), Tipo_Gestion_4 varchar(25), Tipo_Gestion_5 varchar(25), 
				  Ejecutivo_Asignado varchar(30), Segmento varchar(3), Gestor_Asignado varchar(40), TipoGestionGestor varchar(10),
				  Telefono1  varchar(9), Telefono2 varchar(9), Telefono3 varchar(9), Telefono4 varchar(9), Telefono5 varchar(9), Telefono6 varchar(9), Telefono7 varchar(9), Telefono8 varchar(9), Telefono9 varchar(9), Telefono10 varchar(9),
				  RRLL1 varchar(200), RRLL1_TipoDocumento varchar(3),RRLL1_NumeroDocumento varchar(11), RRLL2 varchar(200),RRLL2_TipoDocumento varchar(3), RRLL2_NumeroDocumento varchar(11),
				  Prox_FechaVen_Pago date, Plazo_1 int,Cuota_flat_1 float, Plazo_2 int, Cuota_flat_2 float, Plazo_3 int, Cuota_flat_3 float, Plazo_4 int, Cuota_flat_4 float, 
				  Cuotas VARCHAR(6), Cuotas_pagadas VARCHAR(2), Cuotas_Atrasadas smallint, MontoCuota_1 float,
				  ---------------------------------
				  Flag_Reprogramacion	smallint /*[TIENE REPROGRAMACIÓN (SI/NO)]*/,
				  Flag_Refinanciamiento smallint/*[TIENE REFINANCIAMIENTO (SI/NO)]*/,
				  Flag_Cliente_Reactiva smallint, Cant_Cred_Reactiva smallint, Cant_Cred_Reactiva_Reprogr smallint, Cant_Cred_Reactiva_Recup smallint, Status_Reactiva varchar(50),
				  Flag_ClienteBPI smallint, 
				  Flag_Impulsa smallint, Impulso_Tipo varchar(20), Impulso_Mes_venc_cuota_comp int, Impulso_Monto_cuota_compl float, Impulso_Tipo_cuota_mes varchar(20),
				  ---------------------------------
				  Debito_Cuenta_Cargo varchar(15), 
				  AsignMes_Base varchar(50), AsignMes_Potencial_Recuperaciones varchar(2), TipoBase_BadBank varchar(15),
				  Flag_Excepcion smallint, Flag_Recuperaciones smallint, Flag_Cima smallint, Flag_Retiro_Call_Reactiva smallint,
				  Score_Intermedia varchar(20), 
				  Flag_PDP SMALLINT,
				  PdP_Estado VARCHAR(20),
				  PdP_Fecha_Gestion DATE, -- Fecha Inicio de Promesa
				  PdP_Monto FLOAT,
				  PdP_CodigoGestor VARCHAR(8),
				  PdP_Fecha_Fin DATE, -- Fecha Fin de Promesa
				  Email VARCHAR(50), 
				  Ultima_Gestion VARCHAR(50),
				  Prioridad_Gestion VARCHAR(20),
				  NumeroDocumentoCliente VARCHAR(11),
				  TelefonoPlin VARCHAR(20),
				  Clasificacion_SSFF VARCHAR(20),
				  Cant_Deudas_Otras_Entidades SMALLINT,
				  Pdp_Rotas SMALLINT,
				  Flag_ClienteNuevo SMALLINT,
				  Fecha_Primera_Asignacion date,
				  Arquetipo_IBK VARCHAR(100) , 
				  Arquetipo_SIF VARCHAR(100), 
				  Endeudamiento_SIF VARCHAR(100),
				  Afectacion_FEN varchar(2),
				  Grupo_Intensidad Varchar (2), 
				  Resultado Varchar (50)
				  )
				  
		/* 2 */ CREATE TABLE BPE_Procesamientos.cob.DistribucionAsignacion_BaseCall
				( Codmes		numeric(6),
				  Fecha_Envio	date, 
				  Fecha			date, 
				  ---------------------------------
				  Accion_fin varchar(25),
				  Proveedor_BaseCall varchar(15),
				  ---------------------------------
				  Dm_actual		int, 
				  Codunicocli	varchar(10), 
				  Cod_credito	varchar(10), 
				  Fecha_vencimiento date, 
				  Monto_cuotas_vencidas float, 
				  Saldo_actual float, 
				  Universo		varchar(25),
				  Tramo_Asignacion varchar(10), 
				  Producto		varchar(50),
				  Zonal varchar(15), Departamento_negocio varchar(30), Provincia_negocio varchar(30), Distrito_negocio	varchar(40), Direccion_negocio varchar(150), 
				  Centro		varchar(30), 
				  Cliente		varchar(100), 
				  Moneda		varchar(7),
				  Fecha_ultimo_pago date, 
				  Cuenta_cyber	varchar(14), Grupo_cyber smallint, NR_Cobranza varchar(25), 
				  Tipo_base		varchar(11),
				  ---------------------------------
				  Ejecutivo_asignado varchar(30), Segmento varchar(3), Gestor_asignado varchar(40), TipoGestionGestor varchar(10), 
				  Telefono1 varchar(9), Telefono2 varchar(9), Telefono3 varchar(9), Telefono4 varchar(9), Telefono5 varchar(9), Telefono6 varchar(9), Telefono7 varchar(9), Telefono8 varchar(9), Telefono9 varchar(9), Telefono10 varchar(9),
				  RRLL1 varchar(200), RRLL1_TipoDocumento varchar(3),RRLL1_NumeroDocumento varchar(11), RRLL2 varchar(200),RRLL2_TipoDocumento varchar(3), RRLL2_NumeroDocumento varchar(11),
				  Prox_FechaVen_Pago date, Plazo_1 int, Cuota_flat_1 float, Plazo_2 int, Cuota_flat_2 float, Plazo_3 int, Cuota_flat_3 float, Plazo_4 int, Cuota_flat_4 float, 
				  Cuotas varchar(6), Cuotas_Pagadas char(2),Cuotas_Atrasadas int, MontoCuota_1 float, 
				  ---------------------------------
				  Flag_Reprogramacion	smallint /*[TIENE REPROGRAMACIÓN (SI/NO)]*/,
				  Flag_Refinanciamiento smallint/*[TIENE REFINANCIAMIENTO (SI/NO)]*/, 
				  Flag_Cliente_Reactiva smallint, Cant_Cred_Reactiva smallint, Cant_Cred_Reactiva_Reprogr smallint, Cant_Cred_Reactiva_Recup smallint, Status_Reactiva varchar(50), 
				  Flag_ClienteBPI smallint, 
				  Flag_Impulsa smallint, Impulso_Tipo varchar(20), Impulso_Mes_venc_cuota_comp int, Impulso_Monto_cuota_compl float, Impulso_Tipo_cuota_mes varchar(20),
				  ---------------------------------
				  Debito_Cuenta_Cargo varchar(15), 
				  AsignMes_Base varchar(50), AsignMes_Potencial_Recuperaciones varchar(2), TipoBase_BadBank varchar(15), 
				  Flag_Excepcion smallint, Flag_Recuperaciones smallint, Flag_Cima smallint, Flag_RetiroImpulso smallint, Flag_Retiro_Call_Reactiva smallint, 
				  Flag_RetiroPiloto smallint,
				  Score_Intermedia varchar(20),
				  Flag_PDP SMALLINT,
				  PdP_Estado VARCHAR(20),
				  PdP_Fecha_Gestion DATE, -- Fecha Inicio de Promesa
				  PdP_Monto FLOAT,
				  PdP_CodigoGestor VARCHAR(8),
				  PdP_Fecha_Fin DATE, -- Fecha Fin de Promesa
				  Email VARCHAR(50),
				  Ultima_Gestion VARCHAR(50),
				  Prioridad_Gestion VARCHAR(20),
				  NumeroDocumentoCliente VARCHAR(11),
				  TelefonoPlin VARCHAR(20),
				  Clasificacion_SSFF VARCHAR(20),
				  Cant_Deudas_Otras_Entidades SMALLINT,
				  Pdp_Rotas SMALLINT,
				  Flag_ClienteNuevo SMALLINT,
				  Fecha_Primera_Asignacion date,
				  Arquetipo_IBK VARCHAR(100) , 
				  Arquetipo_SIF VARCHAR(100), 
				  Endeudamiento_SIF VARCHAR(100),
				  Giro Varchar (100), 
				  FechaDesembolso DATE,
				  Afectacion_FEN varchar(2),
				  Grupo_Intensidad Varchar (2), 
				  Resultado Varchar (50)


				)

		
		/* 3 */ CREATE TABLE BPE_Procesamientos.cob.DistribucionAsignacion_BaseGestores
				( Codmes		numeric(6), 
				  Fecha_envio	date, 
				  Fecha			date, 
				  ---------------------------------
				  Accion_Fin			varchar(25), 
				  Proveedor_BaseCall	varchar(15), 
				  ---------------------------------
				  Dm_actual		int, 
				  Codunicocli varchar(10), 
				  Cod_credito varchar(10), 
				  Fecha_vencimiento date, 
				  Monto_cuotas_vencidas float, 
				  Saldo_actual float, 
				  Universo varchar(25), 
				  Tramo_asignacion	varchar(10), 
				  Producto varchar(50),
				  Zonal	varchar(15), Departamento_negocio varchar(30), Provincia_negocio varchar(30), Distrito_negocio	varchar(40), Direccion_negocio varchar(150), 
				  Centro	varchar(30),
				  Cliente	varchar(100), 
				  Moneda	varchar(7), 
				  Fecha_ultimo_pago date,
				  Cuenta_cyber varchar(14), Grupo_cyber smallint, NR_cobranza varchar(25), 
				  Tipo_base varchar(11),
				  ---------------------------------
				  Ejecutivo_asignado varchar(30), Segmento varchar(3), Gestor_asignado varchar(40), TipoGestionGestor varchar(10), 
				  Telefono1  varchar(9), Telefono2 varchar(9), Telefono3 varchar(9), Telefono4 varchar(9), Telefono5 varchar(9), Telefono6 varchar(9), Telefono7 varchar(9), Telefono8 varchar(9), Telefono9 varchar(9), Telefono10 varchar(9),
				  RRLL1 varchar(200), RRLL1_TipoDocumento varchar(3),RRLL1_NumeroDocumento varchar(11), RRLL2 varchar(200),RRLL2_TipoDocumento varchar(3), RRLL2_NumeroDocumento varchar(11),
				  Prox_FechaVen_Pago date, Plazo_1 int, Cuota_flat_1 float, Plazo_2 int, Cuota_flat_2 float, Plazo_3 int, Cuota_flat_3 float, Plazo_4 int, Cuota_flat_4 float,
				  Cuotas varchar(6), Cuotas_pagadas varchar(2), Cuotas_atrasadas int, MontoCuota_1 float, 
				  ---------------------------------
				  Flag_Reprogramacion	smallint /*[TIENE REPROGRAMACIÓN (SI/NO)]*/,
				  Flag_Refinanciamiento smallint/*[TIENE REFINANCIAMIENTO (SI/NO)]*/,
				  Flag_Cliente_Reactiva smallint, Cant_Cred_Reactiva smallint, Cant_Cred_Reactiva_Reprogr smallint, Cant_Cred_Reactiva_Recup smallint, Status_Reactiva varchar(50),
				  Flag_ClienteBPI		smallint, 
				  Flag_Impulsa smallint, Impulso_Tipo varchar(20), Impulso_Mes_venc_cuota_comp int, Impulso_Monto_cuota_compl float, Impulso_Tipo_cuota_mes varchar(20),
				  ---------------------------------
				  Debito_Cuenta_Cargo	varchar(15), 
				  AsignMes_Base varchar(50), AsignMes_Potencial_Recuperaciones varchar(2), TipoBase_BadBank varchar(15), TEA_Reducida float, Flag_nuevo_ingreso varchar(2), 
				  Flag_cima	smallint,
				  Flag_PDP SMALLINT,
				  PdP_Estado VARCHAR(20),
				  PdP_Fecha_Gestion DATE, -- Fecha Inicio de Promesa
				  PdP_Monto FLOAT,
				  PdP_CodigoGestor VARCHAR(8),
				  PdP_Fecha_Fin DATE, -- Fecha Fin de Promesa
				  Email VARCHAR(50),
				  Ultima_Gestion VARCHAR(50),
				  Prioridad_Gestion VARCHAR(20),
				  NumeroDocumentoCliente VARCHAR(11),
				  TelefonoPlin VARCHAR(20),
				  Clasificacion_SSFF VARCHAR(20),
				  Cant_Deudas_Otras_Entidades SMALLINT,
				  Pdp_Rotas SMALLINT,
				  Flag_ClienteNuevo SMALLINT,
				  Fecha_Primera_Asignacion date, 
				  Arquetipo_IBK VARCHAR(100) , 
				  Arquetipo_SIF VARCHAR(100), 
				  Endeudamiento_SIF VARCHAR(100),
				  Afectacion_FEN varchar(2)

				  )
		
		/* 4 */	CREATE TABLE cob.DistribucionAsignacion_UltimaGestion (Cod_Credito varchar(10), Codigo_Accion varchar(10), Codigo_Resultado varchar(10), Ultima_Gestion varchar(50))
		 

		-- =======================================
		-- BASE PRINCIPAL: Asignacion Diaria + Datos Base Cobranzas
		-- =======================================
		-- #asignacion
		INSERT INTO cob.DistribucionAsignacion_BasePrincipal (CODMES, FECHA_ENVIO, FECHA, DM_ACTUAL, CODUNICOCLI, COD_CREDITO, FECHA_VENCIMIENTO, MONTO_CUOTAS_VENCIDAS, SALDO_ACTUAL, 
		UNIVERSO, TRAMO_ASIGNACION, PRODUCTO, ZONAL, DEPARTAMENTO_NEGOCIO, PROVINCIA_NEGOCIO, DISTRITO_NEGOCIO, DIRECCION_NEGOCIO, CENTRO, CLIENTE, REGEJECUTIVO, MONEDA, 
		Fecha_Ultimo_Pago, Cuenta_Cyber, Grupo_Cyber, NR_Cobranza, TIPO_BASE, Prioridad_Gestion)
		SELECT	A.Codmes, 
				A.Fecha_envio, 
				A.Fecha, 
				A.Dm_actual, 
				A.Codunicocli, A.Cod_credito, 
				A.Fecha_vencimiento, A.Monto_cuotas_vencidas, A.Saldo_actual, A.Universo,
				CASE WHEN B.Producto like ('%reactiva%') THEN B.TRAMO_ASIGNACION ELSE B.TRAMO_ASIGNACION_SR END Tramo_asignacion,
				B.Producto,
				B.Zonal,
				B.Departamento_negocio,
				B.Provincia_negocio,
				B.Distrito_negocio,
				B.Direccion_negocio,
				B.Centro, 
				B.Cliente,
				B.Regejecutivo,
				CASE WHEN B.TIPO_MONEDA IN('001','SOLES') THEN 'Soles' WHEN B.TIPO_MONEDA in('010','DOLARES') THEN 'Dolares' ELSE NULL END Moneda,
				A.Fecha_Ultimo_Pago, 
				A.Cuenta_Cyber,
				A.Grupo_Cyber,
				A.NR_Cobranza,
				CASE WHEN B.PRODUCTO LIKE '%REACT%' THEN 'REACTIVA' ELSE 'NO REACTIVA' END Tipo_base,
				B.Prioridad_Gestion
		FROM	BPE.COB.AsignacionDiaria A
		LEFT JOIN BPE.cob.vw_Base_Cobranzas B ON B.COD_CREDITO = A.Cod_credito AND B.CODMES = @MesActual
		WHERE	A.Fecha = @FechaSaldos 


		-- =======================================
		-- RETIRO POR VALIDACION DE CUOTA PENDIENTE CRONOGRAMAS VS CYBER
		-- =======================================

		IF OBJECT_ID('tempdb..#RetirosPagoCorr') IS NOT NULL
			DROP TABLE #RetirosPagoCorr;

		CREATE TABLE #RetirosPagoCorr (
			Cod_Credito VARCHAR(10) NOT NULL,
			Fecha_Vencimiento_Base DATE NULL,
			Primera_Fecha_Vencimiento_Pendiente DATE NULL
		);

		;WITH CRO_PAG AS (
			SELECT Cod_Credito, MIN(FechaVencimiento) AS Fecha_Venc
			FROM BPE.dbo.vw_Cronogramas
			WHERE FechaPago IS NULL
			GROUP BY Cod_Credito
		)
		INSERT INTO #RetirosPagoCorr (
			Cod_Credito,
			Fecha_Vencimiento_Base,
			Primera_Fecha_Vencimiento_Pendiente
		)
		SELECT DISTINCT
			A.Cod_Credito,
			A.Fecha_Vencimiento,
			CP.Fecha_Venc
		FROM cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN CRO_PAG CP ON A.Cod_Credito = CP.Cod_Credito
		WHERE CP.Cod_Credito IS NULL
		   OR A.Fecha_Vencimiento IS NULL
		   OR A.Fecha_Vencimiento < CP.Fecha_Venc;

		-- Registro de los creditos retirados.

		INSERT INTO BPE.cob.Seguimiento_Retiros_Procesos (
			Proceso,
			Cod_Credito,
			Fecha_Envio,
			Motivo
		)
		SELECT
			'Asignacion Diaria Call y Campo',
			R.Cod_Credito,
			@FechaActual,
			'Retiro por fecha vencimiento vs cuota pendiente'
		FROM #RetirosPagoCorr R
		WHERE NOT EXISTS (
			SELECT 1
			FROM BPE.cob.Seguimiento_Retiros_Procesos S
			WHERE S.Proceso = 'Asignacion Diaria Call y Campo'
			AND S.Cod_Credito = R.Cod_Credito
			AND S.Fecha_Envio = @FechaActual
			AND S.Motivo = 'Retiro por fecha vencimiento vs cuota pendiente'
		);

		-- Retiro desde la tabla principal

		DELETE A
		FROM cob.DistribucionAsignacion_BasePrincipal A
		INNER JOIN #RetirosPagoCorr R
			ON R.Cod_Credito = A.Cod_Credito;

		DROP TABLE #RetirosPagoCorr;


		-- =======================================
		-- Tipos de Gestión
		-- Se desactiva Score Cobranza|| NR_Cobranza || Tipo_Gestion 2026.01.02
		-- =======================================
		-- Tramo Asignación Temprana + Universo Regular
		--UPDATE	A
		--SET		A.Tipo_Gestion_1 = CASE	WHEN A.NR_Cobranza IN ('1.Bajo Top')		AND A.DM_ACTUAL IN (1,2) THEN 'Voicebot'
		--								WHEN A.NR_Cobranza IN ('2.Bajo', '3.Medio') AND A.DM_ACTUAL IN (1)	 THEN 'Voicebot'
		--								ELSE NULL END , 
		--		A.Tipo_Gestion_2 = CASE WHEN A.NR_Cobranza IN ('1.Bajo Top')		 AND A.DM_ACTUAL BETWEEN 3 AND 30 THEN 'Call'
		--								 WHEN A.NR_Cobranza IN ('2.Bajo', '3.Medio') AND A.DM_ACTUAL BETWEEN 2 AND 30 THEN 'Call'
		--								 WHEN A.NR_Cobranza IN ('4.Alto')			 AND A.DM_ACTUAL BETWEEN 1 AND 30 THEN 'Call'
		--								 ELSE NULL END ,
		--		A.Tipo_Gestion_3 = CASE WHEN A.NR_Cobranza IN ('1.Bajo Top','2.Bajo') AND A.DM_ACTUAL BETWEEN 9 AND 30 THEN 'Ejecutivo'
		--								 WHEN A.NR_Cobranza IN ('3.Medio') AND A.DM_ACTUAL BETWEEN 4 AND 30 THEN 'Ejecutivo'
		--								 WHEN A.NR_Cobranza IN ('4.Alto') AND A.DM_ACTUAL BETWEEN 1 AND 30 THEN 'Ejecutivo'
		--								 ELSE NULL END ,
		--		A.Tipo_Gestion_4 = CASE WHEN A.NR_Cobranza IN ('1.Bajo Top','2.Bajo') AND A.DM_ACTUAL BETWEEN 16 AND 30 THEN 'Gestor de Cobranza'
		--								 WHEN A.NR_Cobranza IN ('3.Medio')			  AND A.DM_ACTUAL BETWEEN 12 AND 30 THEN 'Gestor de Cobranza'
		--								 WHEN A.NR_Cobranza IN ('4.Alto')			  AND A.DM_ACTUAL BETWEEN  9 AND 30 THEN 'Gestor de Cobranza'
		--								 ELSE NULL END  
		--FROM	cob.DistribucionAsignacion_BasePrincipal A
		--WHERE	Tramo_asignacion ='Temprana' AND Universo = 'Regular'


		-- Tramo Asignación Temprana + Universo Regular_Reactiva, Solo_Reactiva 
		--UPDATE	A
		--SET		A.Tipo_Gestion_1 = CASE WHEN A.NR_Cobranza IN ('1.Bajo')  AND A.DM_ACTUAL = 1 THEN 'Voicebot' ELSE NULL END,
		--		A.Tipo_Gestion_2 = CASE WHEN A.NR_Cobranza IN ('1.Bajo')		   AND A.DM_ACTUAL BETWEEN 2 AND 30 THEN 'Call'
		--								WHEN A.NR_Cobranza IN ('2.Medio','3.Alto') AND A.DM_ACTUAL BETWEEN 1 AND 30 THEN 'Call'
		--								ELSE NULL END,
		--		A.Tipo_Gestion_3 = CASE WHEN A.NR_Cobranza IN ('1.Bajo')  AND A.DM_ACTUAL BETWEEN 4 AND 30 THEN 'Ejecutivo'
		--								WHEN A.NR_Cobranza IN ('2.Medio', '3.Alto') AND A.DM_ACTUAL BETWEEN 1 AND 30 THEN 'Ejecutivo'
		--								ELSE NULL END,
		--		A.Tipo_Gestion_4 = CASE WHEN a.Universo = 'Regular_Reactiva' and A.NR_Cobranza IN ('1.Bajo')  AND A.DM_ACTUAL BETWEEN 12 AND 30 THEN 'Gestor de Cobranza'
		--								WHEN a.Universo = 'Regular_Reactiva' and A.NR_Cobranza IN ('2.Medio') AND A.DM_ACTUAL BETWEEN  9 AND 30 THEN 'Gestor de Cobranza'
		--								WHEN a.Universo = 'Regular_Reactiva' and A.NR_Cobranza IN ('3.Alto')  AND A.DM_ACTUAL BETWEEN  1 AND 30 THEN 'Gestor de Cobranza'
		--								ELSE NULL END 
		--FROM	cob.DistribucionAsignacion_BasePrincipal A
		--WHERE	Tramo_asignacion = 'Temprana' and Universo in ('Regular_Reactiva','Solo_Reactiva')


		-- Tramo Asignación Temprana + Universo Cima
		--UPDATE	A
		--SET		A.Tipo_Gestion_4 = CASE WHEN A.Saldo_Actual >10000  and A.Dm_Actual >8 THEN 'Call' ELSE NULL END , 
		--		A.Tipo_Gestion_2 = CASE WHEN A.Saldo_Actual <=10000 and A.Dm_Actual >8 THEN 'Call' 
		--								WHEN A.Saldo_Actual > 10000 and A.Dm_Actual between 4 and 8 THEN 'Call' 
		--								ELSE NULL END, 
		--		A.Tipo_Gestion_5 = CASE WHEN A.Dm_actual BETWEEN 1 AND 3  THEN 'SMS'
		--								WHEN A.Saldo_actual <=10000 and a.dm_actual BETWEEN 4 and 8  THEN 'SMS'
		--								ELSE NULL END  
		--FROM	cob.DistribucionAsignacion_BasePrincipal A
		--WHERE	Tramo_asignacion='Temprana' AND Universo in ('CIMA')

		
		-- =======================================
		-- Acción Fin
		-- Se desactiva Score Cobranza|| NR_Cobranza || Tipo_Gestion 2026.01.02
		-- =======================================
		--UPDATE	A
		--SET		A.Accion_fin = CASE WHEN Tipo_Gestion_1 = 'Voicebot' THEN '1.Voicebot'
		--						    WHEN Tipo_Gestion_2 = 'Call' and Tipo_Gestion_3 IS NULL		and Tipo_Gestion_4 IS NULL and Tipo_Gestion_5 IS NULL then '2.Call Center'
		--						    WHEN Tipo_Gestion_2 = 'Call' and Tipo_Gestion_3 ='Ejecutivo' and Tipo_Gestion_4 IS NULL and Tipo_Gestion_5 IS NULL then '3.Dual-(Call/EN)'
		--						    WHEN Tipo_Gestion_2 = 'Call' and Tipo_Gestion_3 IS NULL		and Tipo_Gestion_4='Gestor de Cobranza' and Tipo_Gestion_5 is null then '4.Dual-(Call/GC)'
		--						    WHEN Tipo_Gestion_2 = 'Call' and Tipo_Gestion_3 ='Ejecutivo' and Tipo_Gestion_4='Gestor de Cobranza' and Tipo_Gestion_5 is null then '5.Trial-(Call/EN/GC)'
		--						    WHEN Tipo_Gestion_2 IS NULL  and Tipo_Gestion_3 IS NULL		and Tipo_Gestion_4='Gestor de Cobranza' and Tipo_Gestion_5 is null then '6.Gestor de Cobranza'
		--						    WHEN Tipo_Gestion_5 = 'SMS' then '7.SMS' ELSE NULL END 
		--FROM cob.DistribucionAsignacion_BasePrincipal A
		--WHERE A.Tramo_Asignacion = 'Temprana'


		-- =======================================
		-- Proveedor
		-- =======================================
		UPDATE	A 
		SET		A.Proveedor_BaseCall = X.Proveedor
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN ( SELECT  *
					FROM    BPE.cob.vw_Base_Call 
					WHERE Mes = @MesActual 
					) X on A.CODUNICOCLI = x.COD_Unico


		-- =======================================
		-- Ejecutivo, Segmento
		-- =======================================
		UPDATE	A 
		SET		A.Ejecutivo_Asignado = 	CASE WHEN PA.Regejecutivo IS not null THEN U.Usuario ELSE NULL END,
				A.Segmento = CASE WHEN PA.Regejecutivo IS not null then 'A' else 'B/C' END
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN BPE.dbo.Catalogo_Usuarios U On A.Regejecutivo = U.Cod_Usuario
		LEFT JOIN BPE.cob.Planta_Activa PA on A.Regejecutivo = PA.Regejecutivo and PA.Codmes = @MesActual

		UPDATE	cob.DistribucionAsignacion_BasePrincipal 
		SET		Ejecutivo_Asignado = NULL
		WHERE	Tramo_Asignacion = 'Temprana' and universo='CIMA' 


	-----------------
	-- BASE EJECUTIVOS INICIALES - KRAMER 07/08 --
	-----------------

		UPDATE A
		SET A.Ejecutivo_Asignado = LEFT(B.EJECUTIVO, 30)
		FROM cob.DistribucionAsignacion_BasePrincipal A
		INNER JOIN BPE_Cruces.B45235.Cartera_asignada B --Base carterizacion (MES)--
		ON @MesActual = B.PERIODO AND A.Regejecutivo = B.COD_EJECUTIVO


		-- =======================================
		-- Gestor Asignado || Tipo de Gestion 
		-- =======================================
		UPDATE	A
		SET		A.Gestor_Asignado	= B.Gestor,
				A.TipoGestionGestor = B.TipoGestionGestor
		FROM cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN BPE.cob.Gestores_Localizacion B on A.Departamento_negocio = B.Departamento_negocio AND 
													 A.Provincia_negocio = B.PROVINCIA_NEGOCIO AND 
													 A.Distrito_negocio = B.DISTRITO_NEGOCIO 
		WHERE	B.CODMES = @MesActual 
		

		-- =======================================
		-- Telefonos
		-- =======================================
		UPDATE	A 
		SET		A.TELEFONO1  = TL.TELEFONO1 ,
				A.TELEFONO2  = TL.TELEFONO2 ,
				A.TELEFONO3  = TL.TELEFONO3 ,
				A.TELEFONO4  = TL.TELEFONO4 ,
				A.TELEFONO5  = TL.TELEFONO5 ,
				A.TELEFONO6  = TL.TELEFONO6 ,
				A.TELEFONO7  = TL.TELEFONO7 ,
				A.TELEFONO8  = TL.TELEFONO8 ,
				A.TELEFONO9  = TL.TELEFONO9 ,
				A.TELEFONO10 = TL.TELEFONO10
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN BPE.cob.MAESTRA_TELEFONOS TL on TL.CODUNICOCLI = A.CODUNICOCLI 

		-- =======================================
		-- Datos Representantes - PARTE 1
		-- Solo créditos NO COBIS, validando que el crédito pertenece al cliente correcto
		-- =======================================
		UPDATE A 
		SET    A.RRLL1                = r1.ApellidoPaterno + ' ' + r1.ApellidoMaterno + ', ' + r1.Nombre1,
			   A.RRLL1_TipoDocumento  = r1.TipoDocumento,
			   A.RRLL1_NumeroDocumento = r1.NumeroDocumento,
			   A.RRLL2                = r2.ApellidoPaterno + ' ' + r2.ApellidoMaterno + ', ' + r2.Nombre1,
			   A.RRLL2_TipoDocumento  = r2.TipoDocumento,
			   A.RRLL2_NumeroDocumento = r2.NumeroDocumento
		FROM cob.DistribucionAsignacion_BasePrincipal A
		INNER JOIN (
			-- Valida que el crédito no sea COBIS
			SELECT DISTINCT Cod_Credito, Cod_Unico
			FROM bpe..vw_Solicitudes
			WHERE EstadoSolicitud <> 'Vigente COBIS'
		) S ON A.cod_CREDITO = S.Cod_Credito AND S.Cod_Unico = A.Codunicocli
		LEFT JOIN BPE.dbo.vw_PersonasRelacionadas r1 
			ON  A.cod_CREDITO = r1.Cod_Credito 
			AND r1.Relacion   = 'Representante Legal' 
			AND r1.Item       = 1
		LEFT JOIN BPE.dbo.vw_PersonasRelacionadas r2 
			ON  A.cod_CREDITO = r2.Cod_Credito 
			AND r2.Relacion   = 'Representante Legal' 
			AND r2.Item       = 2

		-- =======================================
		-- Datos Representantes - PARTE 2 (Fallback)
		-- Cubre los COBIS y cualquier otro que quedó sin RRLL1
		-- =======================================
		UPDATE A 
		SET    A.RRLL1                = fb.ApellidoPaterno + ' ' + fb.ApellidoMaterno + ', ' + fb.Nombre1,
			   A.RRLL1_TipoDocumento  = fb.TipoDocumento,
			   A.RRLL1_NumeroDocumento = fb.NumeroDocumento
		FROM cob.DistribucionAsignacion_BasePrincipal A
		INNER JOIN (
			SELECT 
				Cod_Unico,
				ApellidoPaterno,
				ApellidoMaterno,
				Nombre1,
				TipoDocumento,
				NumeroDocumento,
				ROW_NUMBER() OVER (PARTITION BY Cod_Unico ORDER BY NumeroDocumento) AS rn
			FROM bpe..vw_PersonasRelacionadas_CU
			WHERE Relacion = 'Representante Legal'
		) fb ON A.Codunicocli = fb.Cod_Unico AND fb.rn = 1
		WHERE A.RRLL1 IS NULL

		
		-- =======================================
		-- Datos Refinanciados Cobranza
		-- =======================================
		UPDATE	A 
		SET		A.Prox_FechaVen_Pago = z.prox_fechvenc_ref,
				A.Plazo_1		= z.PLAZO_1,
				A.Cuota_flat_1	= z.CUOTA_FLAT_1,
				A.Plazo_2		= z.PLAZO_2,
				A.Cuota_flat_2  = z.CUOTA_FLAT_2,
				A.Plazo_3		= z.PLAZO_3,
				A.Cuota_flat_3  = z.CUOTA_FLAT_3,
				A.Plazo_4		= z.PLAZO_4,
				A.Cuota_flat_4	= z.CUOTA_FLAT_4
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN BPE.cob.BASE_REFINANCIADOS_COBRANZA Z on Z.COD_CREDITO = A.COD_CREDITO 

		-- =======================================
		-- Cuotas
		-- =======================================
		-- Cuotas Pagadas y Cuotas (Pagadas/Total)
		UPDATE	A
		SET		A.Cuotas		 = ''+CONVERT(CHAR(2),ISNULL(X.Cuotas_pagadas,0))+'/'+CONVERT(CHAR(2),X.Total_Cuotas),
				A.Cuotas_pagadas = CONVERT(CHAR(2),ISNULL(X.Cuotas_pagadas,0)) ,
				A.Cuotas_atrasadas = X.Cuotas_atrasadas
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		INNER JOIN (
			SELECT	Cod_Credito, 
					MAX(NumCuota) Total_Cuotas, 
					MAX(CASE WHEN FechaPago is not null THEN NumCuota END) Cuotas_Pagadas, 
					SUM(CASE WHEN DiasAtraso > 0 and FechaPago is null THEN 1 ELSE 0 END) Cuotas_Atrasadas
			FROM BPE..VW_CRONOGRAMAS GROUP BY Cod_Credito ) X ON X.COD_CREDITO = A.COD_CREDITO

		
		UPDATE	A
		SET		A.MontoCuota_1 = C.CAPITAL + C.INTERES
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		INNER JOIN (
					SELECT
							COD_CREDITO,
							CAPITAL,
							INTERES,
							numero_cuota,
							ROW_NUMBER() OVER (PARTITION BY COD_CREDITO ORDER BY numero_cuota ASC) AS rn
						FROM BPE.DBO.Cyber_Pagos_Pendientes ) C
			ON C.COD_CREDITO = A.Cod_credito
			AND C.rn = 1;  

		
		UPDATE	A
		SET		A.MontoCuota_1 = C.MontoCuota
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		INNER JOIN (SELECT Cod_Credito, MIN(NumCuota) Cuota_1 FROM BPE..VW_CRONOGRAMAS WHERE FechaPago is null and DiasAtraso > 0 GROUP BY Cod_Credito ) MinCuota on MinCuota.Cod_Credito = A.Cod_credito
		INNER JOIN BPE..vw_Cronogramas C ON C.Cod_Credito = MinCuota.Cod_Credito AND C.NumCuota = MinCuota.Cuota_1 
		WHERE A.MontoCuota_1 IS NULL 


		-- =======================================
		-- Potencial Reprogramación y Refinanciamiento
		-- TIENE REPROGRAMACIÓN (SI/NO) , TIENE REFINANCIAMIENTO (SI/NO)
		-- =======================================
		UPDATE	A 
		SET		A.Flag_Reprogramacion = CASE WHEN RL.Cod_Credito IS NOT NULL THEN 1 ELSE 0 END
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN BPE.cob.Base_Potencial_Landing RL ON A.Cod_credito = RL.Cod_credito and RL.Mes = @MesActual

		UPDATE	A 
		SET		A.Flag_Refinanciamiento = CASE WHEN REF.Cod_Credito IS NOT NULL THEN 1 ELSE 0 END
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN BPE.cob.Base_Potencial_Refinanciado REF ON A.Cod_credito = REF.Cod_credito and REF.Mes = @MesActual
		
		-- =======================================
		-- Reactiva
		-- =======================================
		UPDATE	A 
		SET		A.Flag_Cliente_Reactiva		 = CASE WHEN R.CODUNICOCLI IS NOT NULL THEN 1 ELSE 0 END,
				A.Cant_Cred_Reactiva		 = R.Nro_Reactivas, 
				A.Cant_Cred_Reactiva_Reprogr = R.Nro_Repros, 
				A.Cant_Cred_Reactiva_Recup	 = R.Nro_Recuperaciones
		FROM	cob.DistribucionAsignacion_BasePrincipal A 
		LEFT JOIN (
			SELECT A.Cod_Unico AS CODUNICOCLI, 
				   COUNT(DISTINCT SD.NROPROD_X) AS Nro_Reactivas,
				   COUNT(DISTINCT B.Cod_Credito) Nro_Repros, 
				   COUNT(DISTINCT R.Cod_CreditoOrigen) Nro_Recuperaciones 
			FROM BPE..vw_Base_Reactiva A
			INNER JOIN BPE.dbo.SALDOSDIARIO SD ON SD.NROPROD_X = A.Cod_CreditoOrigen AND SD.SALDO>0
			LEFT JOIN BPE.dbo.vw_Base_ReprogramacionesReactiva B on A.Cod_CreditoOrigen = B.Cod_Credito 
			LEFT JOIN BPE.cob.vw_Base_Recuperaciones R on A.Cod_CreditoOrigen = R.Cod_CreditoOrigen and R.Flag_RegistroActivo = 1 
			--where a.COD_UNICO ='0002907061'
			GROUP BY A.Cod_Unico 
		)R on R.CODUNICOCLI = A.CODUNICOCLI

		
		UPDATE	A 
		SET		A.Status_Reactiva = Isnull(b.[Status],'No aplica nueva Reprogramación Reactiva') 
		FROM	cob.DistribucionAsignacion_BasePrincipal A 
		LEFT JOIN BPE..Base_Funnel_ReproReactivaFase2 B ON A.COD_CREDITO = B.Nro_Credito
		WHERE	A.Flag_Cliente_Reactiva = 1 AND A.Producto like ('%reactiva%') 


		-- =======================================
		-- BPI
		-- =======================================
		UPDATE  A
		SET		A.Flag_ClienteBPI = CASE WHEN BPI.Credito IS NOT NULL THEN 1 ELSE 0 END
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN (SELECT '00'+cod_credito credito from BPE.cob.Clientes_BPI_Historico WHERE CODMES = @MesActual) BPI on A.COD_CREDITO = BPI.Credito 

		-- =======================================
		-- Impulsa 
		-- TIPO_IMPULSO, MES_VENC_CUOTA_COMP, MONTO_CUOTA_COMPL, TIPO_CUOTA_MES || 2024.10.28
		-- =======================================
		UPDATE	A
		SET		A.Flag_Impulsa = CASE WHEN I.Cod_CreditoOrigen IS NOT NULL THEN 1 ELSE 0 END 
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN BPE..Base_Impulso I ON I.Cod_CreditoOrigen = A.Cod_credito

		UPDATE  A 
		SET		A.Impulso_Tipo = I.Tipo_Base_Impulso 
		FROM cob.DistribucionAsignacion_BasePrincipal A
		INNER JOIN BPE.DBO.Base_Impulso I on I. Cod_CreditoOrigen = A.COD_CREDITO

		-- =======================================
		-- Débito Automático: Cuenta Cargo
		-- =======================================
		UPDATE	A 
		SET		A.Debito_Cuenta_Cargo = DA.Cuenta_Cargo
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN BPE.COB.Base_Debito_Automatico DA on DA.COD_CREDITO = a.COD_CREDITO

		-- =======================================
		-- Base Asignacion MENSUAL
		-- =======================================
		UPDATE	A 
		SET		A.AsignMes_Base = P.Base,
				A.AsignMes_Potencial_Recuperaciones = P.potencial_recuperaciones
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN BPE.cob.Asignacion_Gestores_Mensual  P on a.cod_credito = P.COD_CREDITO

		-- =======================================
		-- Tipo Base BadBank
		-- =======================================
		UPDATE	A 
		SET		A.TipoBase_BadBank = BB.Tipo_Base 
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		INNER JOIN BPE.DBO.Base_BadBank_Buro_FEN BB on bb.Cod_Credito = a.COD_CREDITO

		-- =======================================
		-- Excepciones y Retiros 
		-- =======================================
		UPDATE	A 
		SET		A.Flag_Excepcion = CASE WHEN E.Cod_Credito is null then 0 else 1 end 
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN BPE.cob.BASE_EXCEPCIONES E ON E.COD_CREDITO = A.COD_CREDITO and A.Fecha_Envio BETWEEN E.FECHA_INGRESO AND E.FECHA_RETIRO ---E.CODMES = @MesActual 
		
		UPDATE	A 
		SET		A.Flag_Recuperaciones = case when R.Cod_CreditoOrigen is not null then 1 else 0 end 
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN BPE.cob.vw_Base_Recuperaciones R ON R.Cod_CreditoOrigen = A.COD_CREDITO and R.Flag_RegistroActivo =1 AND R.Mes < @MesActual

		UPDATE	A 
		SET		A.Flag_Cima = case when c.Cod_credito is not null then 1 else 0 end 
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		LEFT JOIN  BPE.dbo.vw_CREDITOS_CIMA C ON C.COD_CREDITO = A.COD_CREDITO 

		UPDATE	A 
		SET		A.Flag_Retiro_Call_Reactiva = 1 
		FROM	cob.DistribucionAsignacion_BasePrincipal A
		WHERE	Producto LIKE ('%REACTIVA%') AND Tramo_Asignacion IN ('Tardia') AND Cod_credito IN (SELECT NRO_CREDITO FROM BPE.cob.HonramientoReactiva_Funnel)

		UPDATE	cob.DistribucionAsignacion_BasePrincipal SET Flag_Retiro_Call_Reactiva = 0 WHERE Flag_Retiro_Call_Reactiva IS NULL 
				

		-- =======================================
		-- Score Intermedia (Piloto) || 2025.02.03
		-- =======================================
		UPDATE  A
		SET		Score_Intermedia  = C.Score_interm
		FROM	cob.DistribucionAsignacion_BasePrincipal A 
		INNER JOIN BPE_Cruces.B45235.cartera_int_piloto C ON C.codunicocli = A.CODUNICOCLI
		WHERE	C.CODMES = @MesActual and 
				C.Estrategia = 'Est.Nueva' and 
				C.Tramo_asignacion_sr = 'Intermedia' 


		-- =======================================
		-- INHIBICION TEMPRANA
		-- Durante DIA_BPE 20, 21 y 22:
		--   Inhibe SCORE 1.R.BAJO o Arquetipo 7. Buen Habito.
		-- Otros dias:
		--   Mantiene SCORE 1.R.BAJO y 2.R.MEDIO BAJO.
		-- =======================================

		IF OBJECT_ID('tempdb..#InhibicionTemprana') IS NOT NULL
			DROP TABLE #InhibicionTemprana;

		CREATE TABLE #InhibicionTemprana (
			CODMES NUMERIC(6),
			FECHA DATE,
			CODUNICOCLI VARCHAR(10),
			COD_CREDITO VARCHAR(10),
			FECHA_VENCIMIENTO DATE
		);

		INSERT INTO #InhibicionTemprana
		SELECT DISTINCT
			A.CODMES, A.FECHA, A.CODUNICOCLI, A.COD_CREDITO, A.FECHA_VENCIMIENTO
		FROM cob.DistribucionAsignacion_BasePrincipal A
		INNER JOIN BPE.dbo.vw_Calendario C ON C.FECHA = A.FECHA
		WHERE A.FECHA_VENCIMIENTO BETWEEN DATEADD(DAY,-3,@FechaActual) AND DATEADD(DAY,-1,@FechaActual)
		AND (
			(
				C.DIA_BPE IN (20,21,22)
				AND (
					EXISTS (
						SELECT 1
						FROM BPE.cob.SCORE_PREV S
						WHERE S.CODUNICOCLI = A.CODUNICOCLI
						AND S.CODMES_2 = C.CODMES_BPE
						AND S.SCORE_NR = '1.R.BAJO'
					)
					OR EXISTS (
						SELECT 1
						FROM BPE.cob.Arquetipos_Cobranzas_HIST H
						WHERE H.CIF_KEY = A.CODUNICOCLI
						AND H.MES_GEST = C.CODMES_BPE
						AND H.Arquetipo_IBK = '7. Buen Habito'
					)
				)
			)
			OR
			(
				ISNULL(C.DIA_BPE,-1) NOT IN (20,21,22)
				AND EXISTS (
					SELECT 1
					FROM BPE.cob.SCORE_PREV S
					WHERE S.CODUNICOCLI = A.CODUNICOCLI
					AND S.CODMES_2 = C.CODMES_BPE
					AND S.SCORE_NR IN ('1.R.BAJO','2.R.MEDIO BAJO')
				)
			)
		);

		INSERT INTO BPE.cob.InhibicionPilotoTemprana
			(Fecha_Envio, Cod_Credito, Fecha_Vencimiento)
		SELECT DISTINCT @FechaActual, I.COD_CREDITO, I.FECHA_VENCIMIENTO
		FROM #InhibicionTemprana I
		WHERE NOT EXISTS (
			SELECT 1
			FROM BPE.cob.InhibicionPilotoTemprana H
			WHERE H.Fecha_Envio = @FechaActual
			AND H.Cod_Credito = I.COD_CREDITO
			AND ISNULL(H.Fecha_Vencimiento,'19000101') = ISNULL(I.FECHA_VENCIMIENTO,'19000101')
		);

		DELETE A
		FROM cob.DistribucionAsignacion_BasePrincipal A
		INNER JOIN #InhibicionTemprana I
			ON I.CODMES = A.CODMES
			AND I.FECHA = A.FECHA
			AND I.CODUNICOCLI = A.CODUNICOCLI
			AND I.COD_CREDITO = A.COD_CREDITO;

		DROP TABLE #InhibicionTemprana;


		-- =======================================
		-- Piloto Intermedia (Nuevo Score)
		-- =======================================
		UPDATE BPE.cob.Prioridades_2025 SET FLG_PILOTO = CASE WHEN FLG_PILOTO = 'PILOTO' THEN 1 WHEN FLG_PILOTO ='CONTROL' THEN 0 ELSE FLG_PILOTO END 

		UPDATE BPE.cob.Prioridades_2025 SET PRIORIDAD = CASE WHEN PRIORIDAD = '3.P3' THEN 'PRIORIDAD 3' 
															 WHEN PRIORIDAD = '2.P2' THEN 'PRIORIDAD 2' 
															 WHEN PRIORIDAD = '1.P1' THEN 'PRIORIDAD 1' 
															 ELSE PRIORIDAD END 

		UPDATE	A 
		SET		A.Prioridad_Gestion = CASE WHEN I.FLG_PILOTO = 1 THEN I.PRIORIDAD WHEN I.FLG_PILOTO  = 0 THEN NULL END
		FROM cob.DistribucionAsignacion_BasePrincipal A 
		INNER JOIN BPE.cob.Prioridades_2025 I ON I.CodUnicoCli = A.Codunicocli and I.CODMES = (select max(codmes) from BPE.cob.Prioridades_2025)
		WHERE A.Tramo_asignacion IN ('Temprana', 'Intermedia')
		
	
		-- =======================================
		-- Promesas de Pago
		-- =======================================
		IF (SELECT DISTINCT Fecha_Carga FROM BPE.cob.Base_PromesasDePago) = @FechaActual
		BEGIN 
			UPDATE  A
			SET		A.Flag_PDP  = 1,
					A.PdP_Estado = CASE WHEN P.PdP_Estado = 'CUMPLIDA' THEN 'CUMPLIDA PARCIAL' ELSE P.PdP_Estado  END,
					A.PdP_Fecha_Gestion = P.PdP_Fecha_Gestion ,
					A.PdP_Monto = P.PdP_Monto,
					A.PdP_CodigoGestor = P.PdP_CodigoGestor,
					A.PdP_Fecha_Fin = P.PdP_Fecha_Fin
			FROM	cob.DistribucionAsignacion_BasePrincipal A 
			INNER JOIN BPE.cob.Base_PromesasDePago P ON P.Cod_Credito = A.Cod_Credito and P.Fecha_Carga = @FechaActual
			WHERE P.Flag_UltimaGestion = 1
		END
		
		ELSE 
			UPDATE  A
			SET		A.Flag_PDP  = 1,
					A.PdP_Estado = CASE WHEN P.PdP_Estado = 'CUMPLIDA' THEN 'CUMPLIDA PARCIAL' ELSE P.PdP_Estado  END,
					A.PdP_Fecha_Gestion = P.PdP_Fecha_Gestion ,
					A.PdP_Monto = P.PdP_Monto,
					A.PdP_CodigoGestor = P.PdP_CodigoGestor,
					A.PdP_Fecha_Fin = P.PdP_Fecha_Fin
			FROM	cob.DistribucionAsignacion_BasePrincipal A 
			INNER JOIN BPE.cob.Base_PromesasDePago P ON P.Cod_Credito = A.Cod_Credito and P.Flag_UltimaGestion = 1
			AND P.PdP_Fecha_Fin > @FechaActual	
		
		-- =======================================
		-- Email
		-- =======================================
		UPDATE	A
		SET		A.Email = C.Email
		FROM cob.DistribucionAsignacion_BasePrincipal A 
 		INNER JOIN BPE.dbo.vw_Clientes C ON C.Cod_Unico = A.Codunicocli AND C.Flag_RegistroActivo=1
		WHERE LEN(C.EMAIL)>4 AND  --Textos cortos no válidos 
			  CHARINDEX('@', C.Email) > 1 AND --Debe contener @ y este no debe ser el primer carácter 
			  CHARINDEX('.', C.Email, CHARINDEX('@', C.Email)) > CHARINDEX('@', C.Email) AND --Debe haber un punto "." después del "@"
			  C.Email NOT LIKE '% %' --No deben haber emails con espacios


		-- =======================================
		-- Ultima_Gestion 
		-- =======================================			
		INSERT INTO cob.DistribucionAsignacion_UltimaGestion (Cod_Credito, Codigo_Accion, Codigo_Resultado, Ultima_Gestion)
		SELECT Cod_Credito, Codigo_Accion, Codigo_Resultado, 
			case
					when PdP_Fecha_Fin is not null then '4. Contacto Directo c/ Promesa' 
					when NROPROD is null then '1. Sin Gestión'
					when Mejor_gestion_num=2 then '2. Sin Exito en el contacto'
					when Mejor_gestion_num=3 then '3. Contacto Directo'
					when Mejor_gestion_num=4 then '4. Contacto Directo c/ Promesa'
					when Mejor_gestion_num=-1 then '5. Por Catalogar'
					else ''
					end Ultima_Gestion
		FROM (
			SELECT 
				A.Cod_credito, 
				B.NROPROD,
				B.CODIGO_ACCION, 
				B.CODIGO_RESULTADO, 
				A.PdP_Fecha_Fin,
				ISNULL(C.Mejor_gestion_num,-1)Mejor_gestion_num,
				ROW_NUMBER() OVER (
					PARTITION BY A.Cod_credito 
					ORDER BY C.Mejor_gestion_num DESC, B.FECHA_GESTION DESC
				) AS rn
			FROM cob.DistribucionAsignacion_BasePrincipal A
			LEFT JOIN BPE.COB.BASE_CYBER_GESTION_MENSUAL B ON B.NROPROD = A.Cod_credito and MES_GESTION = @MesActual 
			LEFT JOIN BPE_Cruces.[B38632].Tipologia_BP C ON C.CODIGO_ACCION = B.CODIGO_ACCION AND C.CODIGO_RESULTADO = B.CODIGO_RESULTADO
		) X
		WHERE X.rn = 1

		UPDATE  A
		SET		A.Ultima_Gestion = X.Ultima_Gestion
		FROM cob.DistribucionAsignacion_BasePrincipal A 
		INNER JOIN cob.DistribucionAsignacion_UltimaGestion X ON X.Cod_Credito = A.Cod_credito

		INSERT INTO BPE_Procesamientos.DBO.Gestion_Sin_Catalogar (Codigo_Accion, Codigo_Resultado)
		SELECT DISTINCT Codigo_Accion, Codigo_Resultado FROM cob.DistribucionAsignacion_UltimaGestion WHERE Ultima_Gestion = '5. Por Catalogar'


		-- =======================================
		-- Nuevos Campos 2025.08.19
		-- 1) DNI/RUC
		-- 2) Teléfono Plin del cliente
		-- 3) Clasificación SBS
		-- 4) Cantidad de deudas con otras entidades
		-- 5) Cantidad de pdps rotas por cliente
		-- 6) Identificar a los clientes nuevos
		-- =======================================

		-- 1) NumeroDocumentoCliente 
			UPDATE	A 
			SET		A.NumeroDocumentoCliente = P.NumeroDocumento
			FROM	cob.DistribucionAsignacion_BasePrincipal  A
			INNER JOIN (SELECT DISTINCT COD_UNICO,TIPODOCUMENTO,NUMERODOCUMENTO FROM BPE.DBO.vw_PersonasRelacionadas) P ON P.Cod_Unico = A.Codunicocli 
			
		-- 2) TelefonoPlin 
			UPDATE	A 
			SET		A.TelefonoPlin = P.Telefono 
			FROM	cob.DistribucionAsignacion_BasePrincipal A
			INNER JOIN BPE.COB.Cobranza_Plin P on P.COD_UNICO = A.Codunicocli
			
		-- 3) Clasificacion_SSFF 
		-- 4) Cant_Deudas_Otras_Entidades 
			UPDATE	A 
			SET		A.Clasificacion_SSFF  = C.Clas_SSFF,
					A.Cant_Deudas_Otras_Entidades = C.Cant_Deudas_Otras_Entidades
			FROM	cob.DistribucionAsignacion_BasePrincipal A
			INNER JOIN (
				SELECT BPE.DBO.fn_Cad_FormatoCodigo(CODUNICOCLI) AS CODUNICO, 
					CASE
					WHEN PCTNORMAL > 50 then 'Normal'
					WHEN PCTCPP > 50 then 'CPP'
					WHEN PCTDEFICIENTE > 50 then 'Deficiente'
					WHEN PCTDUDOSO > 50 then 'Dudoso'
					WHEN PCTPERDIDA > 50 then 'Perdida' end as Clas_SSFF,
					ctdentidadreportante as Cant_Deudas_Otras_Entidades
				FROM  BPE.COB.Cobranza_RCC_ult6meses
				WHERE CODMES in (SELECT MAX(CODMES) FROM BPE.COB.Cobranza_RCC_ult6meses)
			) C on C.CODUNICO = A.Codunicocli
			
		-- 5) Pdp_Rotas 
			;WITH Resumen_PdP AS (
				SELECT DISTINCT b.CODUNICOCLI, a.Pdp_Fecha_Gestion
				FROM BPE.cob.Base_PromesasDePago a
				INNER JOIN BPE.cob.Asesores_Contact_Interno c ON a.PdP_CodigoGestor = c.COD_GESTOR AND c.ASESOR IS NOT NULL
				INNER JOIN (SELECT COD_CREDITO, CODUNICOCLI FROM bpe.cob.vw_efectividad_diaria WHERE CODMES = @MesActual) b ON a.Cod_Credito = b.COD_CREDITO AND A.Periodo = @MesActual
				WHERE a.Pdp_Estado = 'ROTA' AND 
					  b.CODUNICOCLI IS NOT NULL
			)
			UPDATE	A 
			SET		A.Pdp_Rotas = R.PDP_ROTAS  
			FROM	cob.DistribucionAsignacion_BasePrincipal A
			INNER JOIN (SELECT CODUNICOCLI, COUNT(*)AS PDP_ROTAS FROM Resumen_PdP GROUP BY CODUNICOCLI) R on R.CODUNICOCLI = A.Codunicocli
			

		-- 6) Flag_ClienteNuevo		
			;WITH BaseActual AS (
				SELECT	Mes, Id_Proveedor, Cod_Unico 
				FROM	BPE.COB.vw_Base_Call
				WHERE	Mes = @MesActual AND Id_Proveedor = 3 -- Interbank 
			),
			BaseAnterior AS (
				SELECT	Mes, Id_Proveedor, Cod_Unico
				FROM	BPE.COB.vw_Base_Call
				WHERE	Mes = @MesAnterior and Id_Proveedor = 3 -- Interbank 
			)
			UPDATE	A 
			SET		A.Flag_ClienteNuevo = X.Flag_Nuevo
			FROM	cob.DistribucionAsignacion_BasePrincipal A
			INNER JOIN 
			( SELECT	Act.Cod_Unico, CASE WHEN Ant.Cod_Unico is null THEN 1 ELSE 0 END as Flag_Nuevo
			  FROM	BaseActual Act 
			  LEFT JOIN BaseAnterior Ant ON Ant.Cod_Unico = Act.Cod_Unico)X on X.Cod_Unico = A.Codunicocli


		-- =======================================
		-- Actualización para Clientes sin Teléfono
		-- =======================================
		UPDATE	A
		SET		A.Telefono1 = C.TELEFONOCELULAR
		FROM	cob.DistribucionAsignacion_BasePrincipal AS A
		INNER JOIN BPE.dbo.Clientes AS C ON C.Cod_Unico = A.CODUNICOCLI
		WHERE	A.Telefono1 IS NULL  AND 
				C.TELEFONOCELULAR IS NOT NULL AND LEN(C.TELEFONOCELULAR) = 9 AND C.TELEFONOCELULAR NOT LIKE '%[^0-9]%' AND 
				C.TELEFONOCELULAR NOT IN (SELECT NRO_CELULAR FROM bpe.cob.Base_Inhibicion_Telefonos) AND 
				C.TELEFONOCELULAR NOT IN (SELECT CELULAR FROM bpe.cob.Base_Inhibicion_Telefonos_Periodica)

		UPDATE A
		SET a.telefono1 = b.telefono
		from cob.DistribucionAsignacion_BasePrincipal a
		left join (select * from BPE.COB.TELEFONOS_GOBIERNO_ADICIONALES where orden_telefono = 1)b
		on a.Codunicocli = B.CU
		where a.Telefono1 is null


		-- =================FIX PARA TABLA COMPLEMENTARIA DE TELEFONOS======================

		UPDATE A
		SET a.telefono1 = b.telf_relacionado1 
		FROM	cob.DistribucionAsignacion_BasePrincipal AS A
		left join bpe.cob.vw_Relacionados_Telf_complemento B
		ON A.CODUNICOCLI = b.cod_unico
		where a.Telefono1 is null

		-- =================================================================================

		update a
		set a.telefono2 = b.telefono
		from cob.DistribucionAsignacion_BasePrincipal a
		left join (select * from BPE.COB.TELEFONOS_GOBIERNO_ADICIONALES where orden_telefono = 2)b
		on a.Codunicocli = B.CU
		where a.Telefono2 is null

		update a
		set a.Telefono3 = b.telefono
		from cob.DistribucionAsignacion_BasePrincipal a
		left join (select * from BPE.COB.TELEFONOS_GOBIERNO_ADICIONALES where orden_telefono = 3)b
		on a.Codunicocli = B.CU
		where a.Telefono3 is null

		-- ==========================INSERT A TABLA DE CL SIN TELF===========================

		INSERT INTO BPE.COB.CLIENTES_SIN_TELF
		SELECT DISTINCT Codmes, Fecha_envio, Codunicocli, Cod_credito
		FROM cob.DistribucionAsignacion_BasePrincipal
		WHERE Telefono1 IS NULL AND Telefono2 IS NULL AND Telefono3 IS NULL

		;WITH CTE_Dedup AS
		(
			SELECT *,
				ROW_NUMBER() OVER (
					PARTITION BY Codmes, Fecha_envio, Codunicocli, Cod_credito
					ORDER BY (SELECT NULL)
				) AS RN
			FROM BPE.COB.CLIENTES_SIN_TELF
		)
		DELETE FROM CTE_Dedup WHERE RN > 1



		-- =======================================
		-- Arquetipos
		-- =======================================
		UPDATE	D 
		SET		D.Arquetipo_IBK = A.Arquetipo_IBK,
				D.Arquetipo_SIF = A.Arquetipo_SIF,
				D.Endeudamiento_SIF = A.Endeudamiento_SIF
		FROM	cob.DistribucionAsignacion_BasePrincipal D
		INNER JOIN  BPE.COB.Arquetipos_Cobranzas A ON A.CIF_KEY = D.Codunicocli and A.MES_GEST = D.Codmes 
		--WHERE A.FLG_PILOTO = 1
		

		-- =======================================
		-- Afectación FEN 
		-- 2026.02.26
		-- =======================================
		UPDATE  D 
		SET		D.Afectacion_FEN = 'Si'
		FROM cob.DistribucionAsignacion_BasePrincipal D 
		INNER JOIN BPE.dbo.vw_Solicitudes Sol on Sol.Cod_Credito = D.Cod_credito AND SOL.Cod_Unico = D.Codunicocli
		INNER JOIN (SELECT * FROM BPE.DBO.Reporte_Senhami WHERE FECHA_Reporte = (select max(fecha_reporte) from BPE.DBO.Reporte_Senhami)) RS on RS.Cod_Ubigeo = Sol.Cod_UbigeoNegocio  
		WHERE RS.Afectacion_FEN_Gestion IN ('Rojo' ,'Naranja') 

		UPDATE  cob.DistribucionAsignacion_BasePrincipal SET Afectacion_FEN = 'No' where Afectacion_FEN IS NULL
		UPDATE  cob.DistribucionAsignacion_BasePrincipal SET Afectacion_FEN = 'No' where Cod_credito IN (SELECT Cod_CreditoOrigen FROM BPE.DBO.Base_Impulso)
		UPDATE  cob.DistribucionAsignacion_BasePrincipal SET Afectacion_FEN = 'No' where Cod_credito IN (SELECT Cod_CreditoOrigen FROM BPE.DBO.Base_Reactiva)
		UPDATE  cob.DistribucionAsignacion_BasePrincipal SET Afectacion_FEN = 'No' where Cod_credito LIKE '007%'

		-- Jair 2026.03.03		
		UPDATE  cob.DistribucionAsignacion_BasePrincipal SET Afectacion_FEN = 'No' where Codunicocli in (
			SELECT codunicocli FROM BPE.COB.RESULTADOS_FORMS_SENAMHI2026 WHERE PAGO = 'Si' AND AFECTACION = 'No')


		-- =======================================
		-- Grupo_Intensidad y Resultado
		-- 2026.05.28
		-- =======================================

		UPDATE cob.DistribucionAsignacion_BasePrincipal SET Grupo_Intensidad = 'G2' WHERE Prioridad_Gestion = 'PRIORIDAD 1' AND DM_Actual <= 16
		UPDATE cob.DistribucionAsignacion_BasePrincipal SET Grupo_Intensidad = 'G2' WHERE Prioridad_Gestion = 'PRIORIDAD 1' AND DM_Actual BETWEEN 17 AND 30
		UPDATE cob.DistribucionAsignacion_BasePrincipal SET Grupo_Intensidad = 'G1' WHERE Prioridad_Gestion = 'PRIORIDAD 1' AND DM_Actual >= 31
		UPDATE cob.DistribucionAsignacion_BasePrincipal SET Grupo_Intensidad = 'G3' WHERE Prioridad_Gestion = 'PRIORIDAD 2' AND DM_Actual <= 16
		UPDATE cob.DistribucionAsignacion_BasePrincipal SET Grupo_Intensidad = 'G2' WHERE Prioridad_Gestion = 'PRIORIDAD 2' AND DM_Actual BETWEEN 17 AND 30
		UPDATE cob.DistribucionAsignacion_BasePrincipal SET Grupo_Intensidad = 'G2' WHERE Prioridad_Gestion = 'PRIORIDAD 2' AND DM_Actual >= 31
		UPDATE cob.DistribucionAsignacion_BasePrincipal SET Grupo_Intensidad = 'G3' WHERE Prioridad_Gestion = 'PRIORIDAD 3' AND DM_Actual <= 16
		UPDATE cob.DistribucionAsignacion_BasePrincipal SET Grupo_Intensidad = 'G3' WHERE Prioridad_Gestion = 'PRIORIDAD 3' AND DM_Actual BETWEEN 17 AND 30
		UPDATE cob.DistribucionAsignacion_BasePrincipal SET Grupo_Intensidad = 'G2' WHERE Prioridad_Gestion = 'PRIORIDAD 3' AND DM_Actual >= 31


		UPDATE A SET A.Resultado = B.Resultado
		FROM cob.DistribucionAsignacion_BasePrincipal A
		INNER JOIN BPE.COB.vw_EFECTIVIDAD_DIARIA B
		ON @FechaSaldos_1 = B.FECHA AND A.Cod_credito = B.COD_CREDITO


		-- =======================================
		-- BASE CALL
		-- =======================================
		INSERT INTO cob.DistribucionAsignacion_BaseCall ( Codmes, Fecha_envio, Fecha, Dm_actual, Tramo_asignacion, Zonal, Departamento_negocio, Provincia_negocio, Centro, 
		Cliente, Codunicocli, Cod_credito, Fecha_vencimiento, Monto_cuotas_vencidas, Saldo_actual, Producto, Fecha_ultimo_pago, Cuenta_cyber, Grupo_cyber, NR_Cobranza, 
		Moneda, Cuotas, Tipo_base, Ejecutivo_asignado, Segmento, Status_Reactiva, Flag_Refinanciamiento, Flag_Reprogramacion, Flag_ClienteBPI, Telefono1, Telefono2, Telefono3, 
		Telefono4, Telefono5, Telefono6, Telefono7, Telefono8, Telefono9, Telefono10,RRLL1, RRLL1_TipoDocumento, RRLL1_NumeroDocumento, RRLL2, RRLL2_TipoDocumento, 
		RRLL2_NumeroDocumento,	MontoCuota_1, Cuotas_Pagadas, Cuotas_Atrasadas, Distrito_negocio, Direccion_Negocio, AsignMes_Base, AsignMes_Potencial_Recuperaciones, 
		Prox_FechaVen_Pago, Plazo_1, Cuota_flat_1, Plazo_2, Cuota_flat_2, Plazo_3, Cuota_flat_3, Plazo_4, Cuota_flat_4, Flag_Cliente_Reactiva, Cant_Cred_Reactiva, 
		Cant_Cred_Reactiva_Reprogr, Cant_Cred_Reactiva_Recup, Universo, Proveedor_BaseCall, Gestor_asignado, Tipogestiongestor, Accion_fin, Debito_Cuenta_Cargo, Flag_Impulsa, 
		Flag_Excepcion, Flag_Retiro_Call_Reactiva, Flag_Recuperaciones, Flag_Cima, TipoBase_BadBank, Impulso_Tipo, Impulso_Mes_venc_cuota_comp, Impulso_Monto_cuota_compl, 
		Impulso_Tipo_cuota_mes, Score_Intermedia, Flag_PDP, PdP_Estado,PdP_Fecha_Gestion,PdP_Monto,PdP_CodigoGestor,PdP_Fecha_Fin, Email, Ultima_Gestion, Prioridad_Gestion,
		NumeroDocumentoCliente, TelefonoPlin, Clasificacion_SSFF, Cant_Deudas_Otras_Entidades, Pdp_Rotas, Flag_ClienteNuevo, Arquetipo_IBK, Arquetipo_SIF, Endeudamiento_SIF, 
		Afectacion_FEN, Grupo_Intensidad, Resultado)
		SELECT  Codmes, Fecha_envio, Fecha, Dm_actual, Tramo_asignacion, Zonal, Departamento_negocio, Provincia_negocio, Centro, Cliente, Codunicocli, Cod_credito, Fecha_vencimiento,
		Monto_cuotas_vencidas, Saldo_actual, Producto, Fecha_ultimo_pago, Cuenta_cyber, Grupo_cyber, NR_Cobranza, Moneda, Cuotas, Tipo_base, Ejecutivo_asignado, Segmento, 
		Status_Reactiva, Flag_Refinanciamiento, Flag_Reprogramacion, Flag_ClienteBPI, Telefono1, Telefono2, Telefono3, Telefono4, Telefono5, Telefono6, Telefono7, Telefono8, 
		Telefono9, Telefono10, RRLL1, RRLL1_TipoDocumento, RRLL1_NumeroDocumento, RRLL2, RRLL2_TipoDocumento, RRLL2_NumeroDocumento,MontoCuota_1, Cuotas_Pagadas, Cuotas_atrasadas,
		Distrito_negocio, Direccion_Negocio, AsignMes_Base, AsignMes_Potencial_Recuperaciones, Prox_FechaVen_Pago, Plazo_1, Cuota_flat_1, Plazo_2, Cuota_flat_2, Plazo_3, 
		Cuota_flat_3, Plazo_4, Cuota_flat_4, Flag_Cliente_Reactiva, Cant_Cred_Reactiva, Cant_Cred_Reactiva_Reprogr, Cant_Cred_Reactiva_Recup,  Universo, Proveedor_BaseCall, 
		Gestor_asignado, Tipogestiongestor, Accion_fin, Debito_Cuenta_Cargo, Flag_Impulsa, Flag_Excepcion, Flag_Retiro_Call_Reactiva, Flag_Recuperaciones, Flag_Cima, 
		TipoBase_BadBank, Impulso_Tipo, Impulso_Mes_venc_cuota_comp, Impulso_Monto_cuota_compl, Impulso_Tipo_cuota_mes, Score_Intermedia, Flag_PDP, PdP_Estado,
		PdP_Fecha_Gestion,PdP_Monto,PdP_CodigoGestor,PdP_Fecha_Fin, Email, Ultima_Gestion, Prioridad_Gestion, NumeroDocumentoCliente, TelefonoPlin, Clasificacion_SSFF,
		Cant_Deudas_Otras_Entidades, Pdp_Rotas, Flag_ClienteNuevo, Arquetipo_IBK, Arquetipo_SIF, Endeudamiento_SIF, Afectacion_FEN, Grupo_Intensidad, Resultado
		FROM	cob.DistribucionAsignacion_BasePrincipal
		WHERE	Proveedor_BaseCall IS NOT NULL and
				MontoCuota_1 IS NOT NULL and 
				Tramo_Asignacion IN ('Temprana','Intermedia','Tardia')
				 
		DELETE FROM cob.DistribucionAsignacion_BaseCall WHERE Telefono1 is null and Telefono2 is null and Telefono3 is null 

		-- =======================================
		-- Inhibicion: Créditos Impulso a Retirar
		-- 2024.05.02 Día 1 para cobertura, días 1 y 2 para el resto 
		-- =======================================
		UPDATE	cob.DistribucionAsignacion_BaseCall SET Flag_RetiroImpulso = 0 WHERE Flag_RetiroImpulso IS NULL

	
		-- =======================================
		-- Seguimiento de Primera Asignación CALL 
		-- Fecha_Primera_Asignacion = Fecha_Envio
		-- =======================================
		INSERT INTO BPE.cob.Fecha_Primera_Asignacion (Codmes, Cod_Credito, Fecha_Primera_Asignacion, Tipo_Gestion, Gestor_Call, Gestor_Campo)
		SELECT	Codmes, 
				Cod_Credito, 
				Fecha_Envio as Fecha_Primera_Asignacion, 
				'Call' as Tipo_Gestion,  
				Proveedor_BaseCall as Gestor_Call, 
				NULL as Gestor_Campo
		-- select *
		FROM	cob.DistribucionAsignacion_BaseCall C
		WHERE	Flag_Excepcion		= 0	and 
				Flag_Recuperaciones = 0 and 
				Flag_Cima			= 0	and 
				Flag_Retiro_Call_Reactiva = 0 and 
				-- Pilotos:
				Flag_RetiroImpulso	= 0 
			AND 
			NOT EXISTS (SELECT 1 FROM BPE.cob.Fecha_Primera_Asignacion H 
						WHERE H.Codmes = C.Codmes AND 
							  H.Cod_credito = C.Cod_credito AND 
							  H.Gestor_Call = C.Proveedor_BaseCall) 

		-- Actualización de Fecha_Primera_Asignacion (Call)
		UPDATE	D 
		SET		D.Fecha_Primera_Asignacion = A.Fecha_Primera_Asignacion
		FROM	cob.DistribucionAsignacion_BaseCall D
		INNER JOIN  BPE.cob.Fecha_Primera_Asignacion A ON A.Cod_Credito = D.Cod_credito and A.Codmes = D.Codmes and A.Tipo_Gestion = 'Call' 

		-- =======================================
		-- Giro de Negocio 
		-- Fecha Desembolso
		-- =======================================
		UPDATE  D 
		SET		D.Giro = Sol.Giro,
				D.FechaDesembolso = Sol.FechaDesembolso
		FROM cob.DistribucionAsignacion_BaseCall D 
		INNER JOIN BPE..vw_Solicitudes Sol on Sol.Cod_Credito = D.Cod_credito AND SOL.Cod_Unico = D.Codunicocli


		-- =======================================
		-- (D) BASE CALL 
		-- =======================================
		-- ALTER TABLE BPE.cob.AsignacionCall_Diario  ADD Grupo_Intensidad Varchar (2), Resultado Varchar (50)
		-- ALTER TABLE BPE.cob.AsignacionCall_Historico ADD Grupo_Intensidad Varchar (2), Resultado Varchar (50)
		TRUNCATE TABLE BPE.cob.AsignacionCall_Diario 
		
		INSERT INTO BPE.cob.AsignacionCall_Diario (Codmes, Fecha_envio, Fecha, DM_Actual, Tramo_asignacion, Zonal, Departamento_negocio, 
		Provincia_negocio, Centro, Cliente, Codunicocli, Cod_credito, Fecha_vencimiento, Monto_cuotas_vencidas, Saldo_actual, Producto, 
		Fecha_ultimo_pago, Cuenta_cyber, Grupo_cyber, Nr_cobranza, Moneda, Cuotas, Tipo_base, Ejecutivo_asignado, Segmento, Status_Reactiva, 
		Flag_Refinanciamiento, Flag_Reprogramacion, Flag_ClienteBPI, Telefono1, Telefono2, Telefono3, Telefono4, Telefono5, Telefono6, Telefono7, 
		Telefono8, Telefono9, Telefono10, RRLL1, RRLL2, MontoCuota_1, Cuotas_Pagadas, Cuotas_Atrasadas, Distrito_negocio, DIRECCION_NEGOCIO, 
		AsignMes_Base, AsignMes_Potencial_Recuperaciones, Prox_FechaVen_Pago , Plazo_1, Cuota_flat_1, Plazo_2, Cuota_flat_2, Plazo_3, Cuota_flat_3, 
		Plazo_4, Cuota_flat_4, Flag_Cliente_Reactiva, Cant_Cred_Reactiva, Cant_Cred_Reactiva_Reprogr, Cant_Cred_Reactiva_Recup, Universo, Proveedor_BaseCall, 
		Gestor_asignado, TipoGestionGestor, Accion_fin, RRLL1_TipoDocumento,RRLL1_NumeroDocumento,RRLL2_TipoDocumento,RRLL2_NumeroDocumento, TipoBase_BadBank, 
		Debito_Cuenta_Cargo, Flag_impulsa, Impulso_Tipo, Impulso_Mes_venc_cuota_comp, Impulso_Monto_cuota_compl, Impulso_Tipo_cuota_mes, Score_Intermedia, 
		Flag_PDP, PdP_Estado,PdP_Fecha_Gestion,PdP_Monto,PdP_CodigoGestor,PdP_Fecha_Fin, Email,Ultima_Gestion, Prioridad_Gestion, NumeroDocumentoCliente, 
		TelefonoPlin, Clasificacion_SSFF, Cant_Deudas_Otras_Entidades, Pdp_Rotas, Flag_ClienteNuevo, Fecha_Primera_Asignacion, Arquetipo_IBK, Arquetipo_SIF, 
		Endeudamiento_SIF, Giro, FechaDesembolso, Afectacion_FEN, Grupo_Intensidad, Resultado)
		SELECT	Codmes, Fecha_envio, Fecha, DM_Actual, Tramo_asignacion, Zonal, Departamento_negocio, Provincia_negocio, Centro, Cliente, Codunicocli, 
		Cod_credito, Fecha_vencimiento, Monto_cuotas_vencidas, Saldo_actual, Producto, Fecha_ultimo_pago, Cuenta_cyber, Grupo_cyber, Nr_cobranza, Moneda, 
		Cuotas, Tipo_base, Ejecutivo_asignado, Segmento, Status_Reactiva, Flag_Refinanciamiento, Flag_Reprogramacion, Flag_ClienteBPI, Telefono1, Telefono2, 
		Telefono3, Telefono4, Telefono5, Telefono6, Telefono7, Telefono8, Telefono9, Telefono10, RRLL1, RRLL2, MontoCuota_1, Cuotas_Pagadas, Cuotas_Atrasadas, 
		Distrito_negocio, DIRECCION_NEGOCIO, AsignMes_Base, AsignMes_Potencial_Recuperaciones, Prox_FechaVen_Pago , Plazo_1, Cuota_flat_1, Plazo_2, Cuota_flat_2, 
		Plazo_3, Cuota_flat_3, Plazo_4, Cuota_flat_4, Flag_Cliente_Reactiva, Cant_Cred_Reactiva, Cant_Cred_Reactiva_Reprogr, Cant_Cred_Reactiva_Recup, Universo, 
		Proveedor_BaseCall, Gestor_asignado, TipoGestionGestor, Accion_fin, RRLL1_TipoDocumento,RRLL1_NumeroDocumento,RRLL2_TipoDocumento,RRLL2_NumeroDocumento, 
		TipoBase_BadBank, Debito_Cuenta_Cargo, Flag_impulsa, Impulso_Tipo, Impulso_Mes_venc_cuota_comp, Impulso_Monto_cuota_compl, Impulso_Tipo_cuota_mes, 
		Score_Intermedia, Flag_PDP, PdP_Estado,PdP_Fecha_Gestion,PdP_Monto,PdP_CodigoGestor,PdP_Fecha_Fin, Email,Ultima_Gestion, Prioridad_Gestion, 
		NumeroDocumentoCliente, TelefonoPlin, Clasificacion_SSFF, Cant_Deudas_Otras_Entidades, Pdp_Rotas, Flag_ClienteNuevo, Fecha_Primera_Asignacion, 
		Arquetipo_IBK, Arquetipo_SIF, Endeudamiento_SIF, Giro, FechaDesembolso, Afectacion_FEN, Grupo_Intensidad, Resultado
		FROM	cob.DistribucionAsignacion_BaseCall 
		WHERE	Flag_Excepcion		= 0	and 
				Flag_Recuperaciones = 0 and 
				Flag_Cima			= 0	and 
				Flag_Retiro_Call_Reactiva = 0 and 
				-- Pilotos:
				Flag_RetiroImpulso	= 0 
		

		-- =======================================
		-- (D) BASE VOICEBOT
		-- =======================================
		--TRUNCATE TABLE BPE.cob.AsignacionVoicebot_Diario  

		-- =======================================
		-- BASE GESTORES CAMPO
		-- 2025.07.31 : Consideraciones Campo: 
		-- 2025.08.01 Nueva lógica para Gestión de Campo
		--Solo reactiva no va
		--Tabla aux de prioridades para los DM por cliente; 
		--excluir facturas
		--primer día hábil, enviamos con info del mes -2
		-- 2026.03.04 Se incluyen créditos con saldo <11000, de los departamentos Piura, Arequipa y La Libertad (Kramer Ortiz)
		-- 2026.05.05 Se agrega el campo EMAIL a pedido de Yovanna Isidro

		INSERT INTO cob.DistribucionAsignacion_BaseGestores (Codmes, Fecha_envio, Fecha, DM_Actual, Zonal, Departamento_negocio, Provincia_negocio, Centro, Cliente, 
		Codunicocli, Cod_credito, Fecha_vencimiento, Monto_cuotas_vencidas, Saldo_actual, Producto, Fecha_ultimo_pago, Cuenta_cyber, Grupo_cyber, Nr_cobranza, Moneda, 
		Cuotas, Tipo_base, Ejecutivo_asignado, Segmento, Status_Reactiva, Flag_Refinanciamiento, Flag_Reprogramacion, Flag_ClienteBPI, Telefono1, Telefono2, Telefono3, 
		Telefono4, Telefono5, Telefono6, Telefono7, Telefono8, Telefono9, Telefono10, RRLL1, RRLL2, MontoCuota_1, Cuotas_pagadas, Cuotas_atrasadas, Distrito_negocio, 
		Direccion_negocio, AsignMes_Base, AsignMes_Potencial_Recuperaciones, Prox_FechaVen_Pago, Plazo_1, Cuota_flat_1, Plazo_2, Cuota_flat_2, Plazo_3, Cuota_flat_3, 
		Plazo_4, Cuota_flat_4, Flag_Cliente_Reactiva, Cant_Cred_Reactiva, Cant_Cred_Reactiva_Reprogr, Cant_Cred_Reactiva_Recup, Universo, Tramo_Asignacion, Proveedor_BaseCall, 
		Gestor_asignado, TipoGestionGestor, Accion_Fin, RRLL1_TipoDocumento, RRLL1_NumeroDocumento, RRLL2_TipoDocumento, RRLL2_NumeroDocumento, TipoBase_BadBank, Debito_Cuenta_Cargo, 
		Flag_impulsa, Impulso_Tipo, Impulso_Mes_venc_cuota_comp, Impulso_Monto_cuota_compl, Impulso_Tipo_cuota_mes, Flag_cima, Arquetipo_IBK, Arquetipo_SIF, Endeudamiento_SIF, 
		Afectacion_FEN, Email, Prioridad_Gestion)
		SELECT	A.Codmes, A.Fecha_envio, Fecha, A.DM_Actual, A.Zonal, A.Departamento_negocio, A.Provincia_negocio, A.Centro, A.Cliente, A.Codunicocli, A.Cod_credito, 
		A.Fecha_vencimiento, A.Monto_cuotas_vencidas, A.Saldo_actual, A.Producto, A.Fecha_ultimo_pago, A.Cuenta_cyber, Grupo_cyber, Nr_cobranza, Moneda, Cuotas, 
		Tipo_base, Ejecutivo_asignado, Segmento, Status_Reactiva, Flag_Refinanciamiento, Flag_Reprogramacion, Flag_ClienteBPI, Telefono1, Telefono2, Telefono3, 
		Telefono4, Telefono5, Telefono6, Telefono7, Telefono8, Telefono9, Telefono10, RRLL1, RRLL2, MontoCuota_1, Cuotas_pagadas, Cuotas_atrasadas, Distrito_negocio, 
		Direccion_negocio, AsignMes_Base, AsignMes_Potencial_Recuperaciones, Prox_FechaVen_Pago, Plazo_1, Cuota_flat_1, Plazo_2, Cuota_flat_2, Plazo_3, Cuota_flat_3, Plazo_4, 
		Cuota_flat_4, Flag_Cliente_Reactiva, Cant_Cred_Reactiva, Cant_Cred_Reactiva_Reprogr, Cant_Cred_Reactiva_Recup, Universo, Tramo_Asignacion, Proveedor_BaseCall, 
		Gestor_asignado, TipoGestionGestor, Accion_Fin, RRLL1_TipoDocumento, RRLL1_NumeroDocumento, RRLL2_TipoDocumento, RRLL2_NumeroDocumento, TipoBase_BadBank, Debito_Cuenta_Cargo, 
		Flag_impulsa, Impulso_Tipo, Impulso_Mes_venc_cuota_comp, Impulso_Monto_cuota_compl, Impulso_Tipo_cuota_mes, Flag_cima, Arquetipo_IBK, Arquetipo_SIF, Endeudamiento_SIF, 
		Afectacion_FEN, Email, Prioridad_Gestion
		FROM	cob.DistribucionAsignacion_BasePrincipal A 
		INNER JOIN (
			SELECT	A.CODUNICOCLI, P.PRIORIDAD, MAX(A.DM_ACTUAL)DM_ACTUAL, COUNT(*)Q
			FROM	cob.DistribucionAsignacion_BasePrincipal A
			LEFT JOIN BPE.cob.Prioridades_2025 P ON P.CODUNICOCLI = A.Codunicocli and P.Codmes = (SELECT MAX(CODMES) FROM BPE.cob.Prioridades_2025)
			GROUP BY A.CODUNICOCLI, P.PRIORIDAD) AgrupCli ON AgrupCli.Codunicocli = A.Codunicocli
		INNER JOIN BPE.cob.Prioridades_Campo_2025 P 
			ON  AgrupCli.Prioridad = P.Prioridad_Campo AND 
				AgrupCli.DM_ACTUAL >= P.DIAS AND 
				P.Codmes = (SELECT MAX(CODMES) FROM BPE.cob.Prioridades_Campo_2025)
		WHERE Cod_credito NOT LIKE '007%' AND 
			  Universo <> 'Solo_Reactiva' AND 
			  Saldo_actual >= 11000
		

		INSERT INTO cob.DistribucionAsignacion_BaseGestores (Codmes, Fecha_envio, Fecha, DM_Actual, Zonal, Departamento_negocio, Provincia_negocio, Centro, Cliente, 
		Codunicocli, Cod_credito, Fecha_vencimiento, Monto_cuotas_vencidas, Saldo_actual, Producto, Fecha_ultimo_pago, Cuenta_cyber, Grupo_cyber, Nr_cobranza, Moneda, 
		Cuotas, Tipo_base, Ejecutivo_asignado, Segmento, Status_Reactiva, Flag_Refinanciamiento, Flag_Reprogramacion, Flag_ClienteBPI, Telefono1, Telefono2, Telefono3, 
		Telefono4, Telefono5, Telefono6, Telefono7, Telefono8, Telefono9, Telefono10, RRLL1, RRLL2, MontoCuota_1, Cuotas_pagadas, Cuotas_atrasadas, Distrito_negocio, 
		Direccion_negocio, AsignMes_Base, AsignMes_Potencial_Recuperaciones, Prox_FechaVen_Pago, Plazo_1, Cuota_flat_1, Plazo_2, Cuota_flat_2, Plazo_3, Cuota_flat_3, 
		Plazo_4, Cuota_flat_4, Flag_Cliente_Reactiva, Cant_Cred_Reactiva, Cant_Cred_Reactiva_Reprogr, Cant_Cred_Reactiva_Recup, Universo, Tramo_Asignacion, Proveedor_BaseCall, 
		Gestor_asignado, TipoGestionGestor, Accion_Fin, RRLL1_TipoDocumento, RRLL1_NumeroDocumento, RRLL2_TipoDocumento, RRLL2_NumeroDocumento, TipoBase_BadBank, Debito_Cuenta_Cargo, 
		Flag_impulsa, Impulso_Tipo, Impulso_Mes_venc_cuota_comp, Impulso_Monto_cuota_compl, Impulso_Tipo_cuota_mes, Flag_cima, Arquetipo_IBK, Arquetipo_SIF, Endeudamiento_SIF, 
		Afectacion_FEN, Email, Prioridad_Gestion)
		SELECT	A.Codmes, A.Fecha_envio, Fecha, A.DM_Actual, A.Zonal, A.Departamento_negocio, A.Provincia_negocio, A.Centro, A.Cliente, A.Codunicocli, A.Cod_credito, 
		A.Fecha_vencimiento, A.Monto_cuotas_vencidas, A.Saldo_actual, A.Producto, A.Fecha_ultimo_pago, A.Cuenta_cyber, Grupo_cyber, Nr_cobranza, Moneda, Cuotas, Tipo_base, 
		Ejecutivo_asignado, Segmento, Status_Reactiva, Flag_Refinanciamiento, Flag_Reprogramacion, Flag_ClienteBPI, Telefono1, Telefono2, Telefono3, Telefono4, Telefono5, 
		Telefono6, Telefono7, Telefono8, Telefono9, Telefono10, RRLL1, RRLL2, MontoCuota_1, Cuotas_pagadas, Cuotas_atrasadas, Distrito_negocio, Direccion_negocio, AsignMes_Base, 
		AsignMes_Potencial_Recuperaciones, Prox_FechaVen_Pago, Plazo_1, Cuota_flat_1, Plazo_2, Cuota_flat_2, Plazo_3, Cuota_flat_3, Plazo_4, Cuota_flat_4, Flag_Cliente_Reactiva, 
		Cant_Cred_Reactiva, Cant_Cred_Reactiva_Reprogr, Cant_Cred_Reactiva_Recup, Universo, Tramo_Asignacion, Proveedor_BaseCall, Gestor_asignado, TipoGestionGestor, Accion_Fin, 
		RRLL1_TipoDocumento, RRLL1_NumeroDocumento, RRLL2_TipoDocumento, RRLL2_NumeroDocumento, TipoBase_BadBank, Debito_Cuenta_Cargo, Flag_impulsa, Impulso_Tipo, 
		Impulso_Mes_venc_cuota_comp, Impulso_Monto_cuota_compl, Impulso_Tipo_cuota_mes, Flag_cima, Arquetipo_IBK, Arquetipo_SIF, Endeudamiento_SIF, Afectacion_FEN, Email, 
		Prioridad_Gestion
		FROM	cob.DistribucionAsignacion_BasePrincipal A 
		INNER JOIN (
			SELECT	A.CODUNICOCLI, P.PRIORIDAD, MAX(A.DM_ACTUAL)DM_ACTUAL, COUNT(*)Q
			FROM	cob.DistribucionAsignacion_BasePrincipal A
			LEFT JOIN BPE.cob.Prioridades_2025 P ON P.CODUNICOCLI = A.Codunicocli and P.Codmes = (SELECT MAX(CODMES) FROM BPE.cob.Prioridades_2025)
			GROUP BY A.CODUNICOCLI, P.PRIORIDAD) AgrupCli ON AgrupCli.Codunicocli = A.Codunicocli
		INNER JOIN BPE.cob.Prioridades_Campo_2025 P 
			ON  AgrupCli.Prioridad = P.Prioridad_Campo AND 
				AgrupCli.DM_ACTUAL >= P.DIAS AND 
				P.Codmes = (SELECT MAX(CODMES) FROM BPE.cob.Prioridades_Campo_2025)
		WHERE Cod_credito NOT LIKE '007%' AND 
			  Universo <> 'Solo_Reactiva' AND 
			  Saldo_actual < 11000 and 
			  Departamento_negocio IN ('AREQUIPA','LA LIBERTAD','PIURA')
			  AND NOT EXISTS (
				SELECT 1 
				FROM cob.DistribucionAsignacion_BaseGestores B 
				WHERE B.Cod_credito = A.Cod_credito )

		-- =======================================
		-- Retiro Operaciones Impulso con >90dm 
		-- =======================================
		INSERT INTO BPE.COB.Seguimiento_Retiros_Procesos (Proceso, Cod_Credito, Fecha_Envio, Motivo)
			SELECT 'Asignacion Diaria Campo', 
					D.Cod_credito, 
					@FechaActual, 
					'Retiro Operaciones Impulso con >90dm'
			FROM	cob.DistribucionAsignacion_BaseGestores D
			INNER JOIN BPE.COB.BASE_COBRANZAS C ON C.COD_CREDITO = D.COD_cREDITO 
			WHERE	C.CODMES = @MesActual AND 
					D.Cod_credito IN (SELECT Cod_CreditoOrigen FROM BPE.DBO.Base_Impulso) AND 
					DM_INICIAL > 90

		DELETE	D
		FROM	cob.DistribucionAsignacion_BaseGestores D
		INNER JOIN BPE.COB.BASE_COBRANZAS C ON C.COD_CREDITO = D.COD_cREDITO 
		WHERE	C.CODMES = @MesActual AND 
				D.Cod_credito IN (SELECT Cod_CreditoOrigen FROM BPE.DBO.Base_Impulso) AND 
				DM_INICIAL > 90 

		-- =======================================
		-- Gestor Asignado 
		-- =======================================
		UPDATE	A
		SET		A.Gestor_asignado	= B.Gestor,
				A.TipoGestionGestor = B.TipoGestionGestor
		FROM cob.DistribucionAsignacion_BaseGestores A
		LEFT JOIN BPE.cob.Gestores_Localizacion B on A.Departamento_negocio = B.Departamento_negocio AND 
													 A.Distrito_negocio = B.Distrito_negocio AND 
													 A.Provincia_negocio = B.Provincia_negocio
		WHERE B.CODMES = @MesActual 
		
		-- =======================================
		-- Nuevo Ingreso
		-- =======================================
		UPDATE	A
		SET		A.Flag_nuevo_ingreso = CASE WHEN A.Cod_credito = B.Cod_credito THEN 'NO' ELSE 'SI' END 
		FROM	cob.DistribucionAsignacion_BaseGestores A
		LEFT JOIN ( SELECT	COD_CREDITO FROM BPE.COB.Asignacion_Historico_Gestores 
					WHERE	FECHA = @FechaSaldos_1 ) B ON A.COD_CREDITO = B.COD_CREDITO

		
		-- =======================================
		-- Solo Asignar Nuevos Clientes hasta el día 18
		-- =======================================
		-- 2026.01.29 Se modifica a 19 
		-- 2026.03.24 Se modifica a 18
		IF (SELECT DIA_BPE FROM BPE..vw_CALENDARIO where Fecha = @FechaActual) >= 18
		BEGIN 
			INSERT INTO BPE.COB.Seguimiento_Retiros_Procesos (Proceso, Cod_Credito, Fecha_Envio, Motivo)
			SELECT 'Asignacion Diaria Campo', 
					Cod_credito, 
					@FechaActual, 
					'No se asigna nueva operación después del DIA_BPE 18'
			FROM	cob.DistribucionAsignacion_BaseGestores 
				WHERE	COD_CREDITO NOT IN 
					( SELECT Cod_credito
					  FROM	BPE.cob.Fecha_Primera_Asignacion 
					  WHERE	Codmes = @MesActual  and Tipo_Gestion = 'Campo') 

			DELETE
			FROM	cob.DistribucionAsignacion_BaseGestores 
			WHERE	COD_CREDITO NOT IN 
				( SELECT Cod_credito
				  FROM	BPE.cob.Fecha_Primera_Asignacion 
				  WHERE	Codmes = @MesActual  and Tipo_Gestion = 'Campo') 

		END 



		-- =======================================
		-- Piloto Jair 2026.04.01
		-- =======================================
	/*	INSERT INTO BPE.COB.Seguimiento_Retiros_Procesos (Proceso, Cod_Credito, Fecha_Envio, Motivo)
			SELECT 'Asignacion Diaria Campo', 
					Cod_credito, 
					@FechaActual, 
					'Piloto Call Campo 202606 (Flag=0) - Jair'
			FROM	cob.DistribucionAsignacion_BaseGestores 
				WHERE	COD_CREDITO IN 
					( select COD_CREDITO from bpe_cruces.b44832.piloto_call_campo_202606 where FLAG_PILOTO_CAMPO_CALL = 0) 

		DELETE FROM cob.DistribucionAsignacion_BaseGestores
		WHERE Cod_credito in (select COD_CREDITO from bpe_cruces.b44832.piloto_call_campo_202606 where FLAG_PILOTO_CAMPO_CALL = 0)
		*/

		-- =======================================
		-- Seguimiento de Primera Asignación CAMPO
		-- Fecha_Primera_Asignacion = Fecha_Envio
		-- =======================================
		INSERT INTO BPE.cob.Fecha_Primera_Asignacion (Codmes, Cod_Credito, Fecha_Primera_Asignacion, Tipo_Gestion, Gestor_Call, Gestor_Campo)
		SELECT	Codmes, 
				B.Cod_Credito, 
				Fecha_Envio as Fecha_Primera_Asignacion, 
				'Campo' as Tipo_Gestion, 
				NULL as Gestor_Call,
				Gestor_asignado as Gestor_Campo
		-- select *
		FROM	cob.DistribucionAsignacion_BaseGestores B
		LEFT JOIN BPE.cob.Base_Inhibiciones_honramientos  H on B.Cod_credito = H.cod_credito 
		WHERE	H.COD_CREDITO is null and  
				ISNULL(Flag_Cima,0) = 0 and 
				Gestor_asignado in (
				 'CARDENAS URQUIZO ERNESTO MARTI',
				 'MENDOZA VARGAS JOSE SALOME',
				 'ASCOY CAPRISTAN EUSEBIO PABLO',
				 'JUAN RAMOS',
				 'JIBAJA HERRERA JOSUE JAVIER',
				 'PICON MATTA JULIAN MACEDONIO',
				 'CASTILLO PAREDES CESAR EMILIO',
				 'ACOSTA GARCIA ANGEL ENRIQUE',
				 'SALDAÑA YARLAQUE MARKO DANILO',
				 --------------------------------
				 'RECUPERA',
				 'SIN_GESTOR_BPE'
				) and 
				B.Cod_credito not in (SELECT Cod_CreditoOrigen FROM BPE..Base_Reactiva WHERE Cod_CreditoOrigen IN (SELECT COD_CREDITO FROM BPE.COB.Base_Recuperaciones WHERE Flag_RegistroActivo = 1)) /*2024.05.16*/
			AND 
			NOT EXISTS (SELECT 1 FROM BPE.cob.Fecha_Primera_Asignacion H 
						WHERE H.Codmes = B.Codmes AND 
							  H.Cod_credito = B.Cod_credito AND 
							  H.Gestor_Campo = B.Gestor_asignado)

		-- Actualización de Fecha_Primera_Asignacion (Campo)
		UPDATE	D 
		SET		D.Fecha_Primera_Asignacion = A.Fecha_Primera_Asignacion
		FROM	cob.DistribucionAsignacion_BaseGestores D
		INNER JOIN  BPE.cob.Fecha_Primera_Asignacion A ON A.Cod_Credito = D.Cod_credito and A.Codmes = D.Codmes and A.Tipo_Gestion = 'Campo' 

		-- =======================================
		-- (D) BASE GESTORES
		-- =======================================
		-- ALTER TABLE BPE.cob.AsignacionGestores_Diario  ADD Prioridad_Gestion varchar(150)
		-- ALTER TABLE BPE.cob.AsignacionGestores_Historico ADD Prioridad_Gestion varchar(150)
		TRUNCATE TABLE BPE.cob.AsignacionGestores_Diario
		
		INSERT INTO BPE.cob.AsignacionGestores_Diario (Codmes, Fecha_envio, Fecha, DM_Actual, Zonal, Departamento_negocio, Provincia_negocio, Centro, Cliente, 
		Codunicocli, Cod_credito, Fecha_vencimiento, Monto_cuotas_vencidas, Saldo_actual, Producto, Fecha_ultimo_pago, Cuenta_cyber, Grupo_cyber, Nr_cobranza, 
		Moneda, Cuotas, Tipo_base, Ejecutivo_asignado, Segmento, Status_Reactiva, Flag_Refinanciamiento, Flag_Reprogramacion, Flag_ClienteBPI, Telefono1, 
		Telefono2, Telefono3, Telefono4, Telefono5, Telefono6, Telefono7, Telefono8, Telefono9, Telefono10, RRLL1, RRLL2, MontoCuota_1, Cuotas_pagadas, 
		Cuotas_atrasadas, Distrito_negocio, Direccion_negocio, AsignMes_Base, AsignMes_Potencial_Recuperaciones, Prox_FechaVen_Pago, Plazo_1, Cuota_flat_1, Plazo_2, 
		Cuota_flat_2, Plazo_3, Cuota_flat_3, Plazo_4, Cuota_flat_4, Flag_Cliente_Reactiva, Cant_Cred_Reactiva, Cant_Cred_Reactiva_Reprogr, Cant_Cred_Reactiva_Recup, 
		Universo, Tramo_asignacion, Proveedor_BaseCall, Gestor_asignado, TipoGestionGestor, Accion_Fin, TEA_reducida, Flag_nuevo_ingreso, RRLL1_TipoDocumento, 
		RRLL1_NumeroDocumento, RRLL2_TipoDocumento, RRLL2_NumeroDocumento, TipoBase_BadBank, Debito_Cuenta_Cargo, Flag_impulsa, Impulso_Tipo, Impulso_Mes_venc_cuota_comp, 
		Impulso_Monto_cuota_compl, Impulso_Tipo_cuota_mes, Fecha_Primera_Asignacion, Arquetipo_IBK, Arquetipo_SIF, Endeudamiento_SIF, Afectacion_FEN, Email, Prioridad_Gestion)
		SELECT	Codmes, Fecha_envio, Fecha, DM_Actual, Zonal, Departamento_negocio, Provincia_negocio, Centro, Cliente, Codunicocli, B.Cod_credito, Fecha_vencimiento, 
		Monto_cuotas_vencidas, Saldo_actual, Producto, Fecha_ultimo_pago, Cuenta_cyber, Grupo_cyber, Nr_cobranza, Moneda, Cuotas, Tipo_base, Ejecutivo_asignado, 
		Segmento, Status_Reactiva, Flag_Refinanciamiento, Flag_Reprogramacion, Flag_ClienteBPI, Telefono1, Telefono2, Telefono3, Telefono4, Telefono5, Telefono6, 
		Telefono7, Telefono8, Telefono9, Telefono10, RRLL1, RRLL2, MontoCuota_1, Cuotas_pagadas, Cuotas_atrasadas, Distrito_negocio, Direccion_negocio, AsignMes_Base, 
		AsignMes_Potencial_Recuperaciones, Prox_FechaVen_Pago, Plazo_1, Cuota_flat_1, Plazo_2, Cuota_flat_2, Plazo_3, Cuota_flat_3, Plazo_4, Cuota_flat_4, 
		Flag_Cliente_Reactiva, Cant_Cred_Reactiva, Cant_Cred_Reactiva_Reprogr, Cant_Cred_Reactiva_Recup, Universo, Tramo_asignacion, Proveedor_BaseCall, 
		Gestor_asignado, TipoGestionGestor, Accion_Fin, TEA_reducida, Flag_nuevo_ingreso, RRLL1_TipoDocumento, RRLL1_NumeroDocumento, RRLL2_TipoDocumento, 
		RRLL2_NumeroDocumento, TipoBase_BadBank, Debito_Cuenta_Cargo, Flag_impulsa, Impulso_Tipo, Impulso_Mes_venc_cuota_comp, Impulso_Monto_cuota_compl, 
		Impulso_Tipo_cuota_mes, Fecha_Primera_Asignacion, Arquetipo_IBK, Arquetipo_SIF, Endeudamiento_SIF	, Afectacion_FEN, Email, Prioridad_Gestion
		FROM	cob.DistribucionAsignacion_BaseGestores B
		LEFT JOIN BPE.cob.[Base_Inhibiciones_honramientos]  H on B.Cod_credito = H.cod_credito 
		WHERE	H.COD_CREDITO is null and 
				ISNULL(Flag_Cima,0) = 0 and 
				Gestor_asignado in (
				 'CARDENAS URQUIZO ERNESTO MARTI',
				 'MENDOZA VARGAS JOSE SALOME',
				 'ASCOY CAPRISTAN EUSEBIO PABLO',
				 'JUAN RAMOS',
				 'JIBAJA HERRERA JOSUE JAVIER',
				 'PICON MATTA JULIAN MACEDONIO',
				 'CASTILLO PAREDES CESAR EMILIO',
				 'ACOSTA GARCIA ANGEL ENRIQUE',
				 'SALDAÑA YARLAQUE MARKO DANILO',
				 --------------------------------
				 'RECUPERA',
				 'SIN_GESTOR_BPE'
				) and 
				B.Cod_credito not in (SELECT Cod_CreditoOrigen FROM BPE..Base_Reactiva WHERE Cod_CreditoOrigen IN (SELECT COD_CREDITO FROM BPE.COB.Base_Recuperaciones WHERE Flag_RegistroActivo = 1)) /*2024.05.16*/
				AND B.Cod_credito NOT IN ('0010203163','0010189101','0010187786') -- Se retira cliente con 1342 DM. 
														-- Ha estado pasando a la base ya que esta como universo "Regular_Reactiva"
														-- Citando a Gaby "la distribucion solo excluye a los que son "solo reactiva" , los q son regular reactiva significa q ademas de su credito reactiva tienen otro crédito, x eso siguen saliendo en la base de asignacion "
														-- 05/05/2026 a pedido de Yovanna Isidro.

		-- =======================================================================================================
		-- Guardamos primera ejecucion de campo para comparar el envio del adicional
		-- =======================================================================================================

		DECLARE @FechaEnvioCampoActual DATE,
				@FechaEnvioCampoGuardada DATE;

		SET @FechaEnvioCampoActual = (
			SELECT MAX(Fecha_envio)
			FROM BPE.cob.AsignacionGestores_Diario
			WHERE Fecha = @FechaSaldos
		);

		IF OBJECT_ID('BPE_Procesamientos.cob.Temp_1er_envioCampo','U') IS NOT NULL
			SET @FechaEnvioCampoGuardada = (
				SELECT MAX(Fecha_envio)
				FROM BPE_Procesamientos.cob.Temp_1er_envioCampo
			);

		IF @FechaEnvioCampoActual IS NOT NULL
		AND (@FechaEnvioCampoGuardada IS NULL OR @FechaEnvioCampoGuardada < @FechaEnvioCampoActual)
		AND EXISTS (
			SELECT 1
			FROM BPE.cob.AsignacionDiaria
			WHERE Fecha = @FechaSaldos
			AND Origen_Base = 'Cyber'
		)
		AND NOT EXISTS (
			SELECT 1
			FROM BPE.cob.AsignacionDiaria
			WHERE Fecha = @FechaSaldos
			AND Origen_Base = 'Saldos Diario'
		)
		BEGIN
			IF OBJECT_ID('BPE_Procesamientos.cob.Temp_1er_envioCampo','U') IS NOT NULL
				DROP TABLE BPE_Procesamientos.cob.Temp_1er_envioCampo;

			SELECT COD_CREDITO, Gestor_asignado, Fecha_envio
			INTO BPE_Procesamientos.cob.Temp_1er_envioCampo
			FROM BPE.cob.AsignacionGestores_Diario
			WHERE Fecha = @FechaSaldos;
		END;			

		-- =======================================
		-- (H) HISTORICO CALL
		-- =======================================
		DELETE FROM BPE.cob.AsignacionCall_Historico WHERE Fecha = @FechaSaldos 

		INSERT INTO	 BPE.cob.AsignacionCall_Historico 
		SELECT	* 
		FROM	BPE.cob.AsignacionCall_Diario 


		-- =======================================
		-- (H) HISTÓRICO GESTORES
		-- =======================================
		DELETE FROM BPE.COB.AsignacionGestores_Historico WHERE FECHA = @FechaSaldos 

		INSERT INTO BPE.COB.AsignacionGestores_Historico 
		SELECT	* 
		FROM	BPE.cob.AsignacionGestores_Diario

		-- =======================================
		-- Registro en Log de Ejecuciones
		-- =======================================
		IF ( SELECT Count(*) FROM BPE.cob.AsignacionCall_Diario WHERE FECHA = @FechaSaldos) > 0
		BEGIN
			EXEC dbo.sp_Sistema_Actualizar_Proceso	86, @FechaProceso			--> Actualiza la Fecha correspondiente al Último Proceso (Fecha Saldos) : SELECT * FROM dbo.Sistema_Procesos WHERE ID_PROCESO = 84
			EXEC dbo.sp_Sistema_Registrar_Log		86, 0, '', @FechaProceso	--> Inserta un registro por cada ejecución en el Log de Ejecuciones: SELECT * FROM dbo.Sistema_Log WHERE ID_PROCESO = 84
		END

		--SELECT * FROM dbo.Sistema_Procesos where id_proceso >= 80
		--INSERT INTO dbo.Sistema_Procesos (PROCESO, TipoProceso, FechaUltimoProceso, Flag_RegistroActivo) VALUES ('COBRANZAS Asignación Diario Distribución Gestores','Diario','2025-02-14',1)


		--=======================================
		-- Limpieza de Temporales
		--=======================================
		/* 1  */ IF OBJECT_ID('BPE_Procesamientos.cob.DistribucionAsignacion_BasePrincipal') Is Not NULL DROP TABLE BPE_Procesamientos.cob.DistribucionAsignacion_BasePrincipal
		/* 2 */  IF OBJECT_ID('BPE_Procesamientos.cob.DistribucionAsignacion_BaseCall') Is Not NULL DROP TABLE BPE_Procesamientos.cob.DistribucionAsignacion_BaseCall
		/* 3 */  IF OBJECT_ID('BPE_Procesamientos.cob.DistribucionAsignacion_BaseGestores') Is Not NULL DROP TABLE BPE_Procesamientos.cob.DistribucionAsignacion_BaseGestores
		/* 4 */  IF OBJECT_ID('BPE_Procesamientos.cob.DistribucionAsignacion_UltimaGestion') Is Not NULL DROP TABLE BPE_Procesamientos.cob.DistribucionAsignacion_UltimaGestion 
			
		

	END 

END