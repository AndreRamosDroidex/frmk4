USE [BPE]
GO

/****** Object:  View [dbo].[vw_PersonasRelacionadas]    Script Date: 25/08/2026 15:20:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



ALTER VIEW [dbo].[vw_PersonasRelacionadas] As
SELECT
	Per.Cod_Solicitud,
	Per.Cod_Credito,
	Per.Cod_Cliente,
	Cl.Cod_Unico,
	Cl.TipoDocumento,
	Cl.NumeroDocumento,
	Cl.ApellidoPaterno,
	Cl.ApellidoMaterno,
	Cl.Nombre1,
	Cl.Nombre2,
	Cl.Cliente,
	Per.Id_Relacion,
	( CASE Per.Id_Relacion
		WHEN 1 THEN 'Titular'
		WHEN 2 THEN 'Conyuge'
		WHEN 3 THEN 'Aval/Fiador'
		WHEN 4 THEN 'Conyuge/Conviviente del Aval o Fiador'
		WHEN 5 THEN 'Representante Legal'
		WHEN 6 THEN 'Miembro Grupo Economico'
		WHEN 7 THEN 'Conviviente'
	END ) As Relacion,
	Per.Item,
	Cl.Direccion,
	Cl.Cod_Ubigeo,
	Cl.Telefono,
	Cl.TelefonoCelular
FROM dbo.PersonasRelacionadas Per
INNER JOIN dbo.vw_Clientes Cl On Per.Cod_Cliente = Cl.Cod_Cliente








GO


