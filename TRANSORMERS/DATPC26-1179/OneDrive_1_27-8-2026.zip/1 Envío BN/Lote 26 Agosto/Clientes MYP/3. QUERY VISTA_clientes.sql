USE [BPE]
GO

/****** Object:  View [dbo].[vw_Clientes]    Script Date: 25/08/2026 15:19:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




ALTER VIEW [dbo].[vw_Clientes] As
SELECT
	Cl.Cod_Cliente,
	Cl.Cod_Unico,
	Cl.ApellidoPaterno,
	Cl.ApellidoMaterno,
	Cl.Nombre1,
	Cl.Nombre2,
	lTrim(rTrim(Cl.ApellidoPaterno+' '+Cl.ApellidoMaterno+' '+Cl.Nombre1+' '+Cl.Nombre2)) As Cliente,
	( CASE Cl.Cod_TipoDocumento
		WHEN 1 THEN 'DNI'
		WHEN 2 THEN 'RUC'
		WHEN 3 THEN 'CEX'
		WHEN 4 THEN 'CID'
		WHEN 5 THEN 'PAS'
		WHEN 6 THEN 'RUC'
	END ) As TipoDocumento,
	Cl.NumeroDocumento,
	Cl.FechaNacimiento,
	Cl.Cod_TipoPersona,
	Cl.Direccion,
	Cl.Cod_Ubigeo,
	Cl.Telefono,
	Cl.TelefonoCelular,
	Cl.Email,
	G.Genero,
	Ec.EstadoCivil,
	Cl.Flag_RegistroActivo
FROM dbo.Clientes Cl
LEFT JOIN dbo.Catalogo_Generos G On Cl.Cod_Genero = G.Cod_Genero
LEFT JOIN dbo.Catalogo_EstadosCiviles Ec On Cl.Cod_EstadoCivil = Ec.Cod_EstadoCivil

GO


