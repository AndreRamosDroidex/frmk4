-- =============================
-- EXTRACCION CLIENTES MYP
-- =============================

SELECT CL.CLIENTE_ID,
    CL.COD_UNICO_VAL,
    CL.COD_TIPO_DOC_VAL,
    CL.NUM_DOC_VAL,
    CL.APELLIDO_PAT_VAL,
    CL.APELLIDO_MAT_VAL,
    CL.NOMBRE1_VAL,
    CL.NOMBRE2_VAL,
    CL.FECHA_NACIMIENTO_DT,
    Cl.Tipo_Persona_val,
    Cl.Direccion_val,
    Cl.Cod_Departamento_val,
    Cl.Cod_Provincia_val,
    Cl.Cod_Distrito_val,
    Cl.Telefono_val,
    Cl.Telefono_Celular_val,
    Cl.Email_val,
    ClN.Genero_val,
    ClN.Estado_Civil_VAL,
    Cl.Cliente_Estado_VAL
    FROM E_DW_VIEWS.V_MST_VPC_MYP_CLIENTE CL
    LEFT JOIN
    E_DW_VIEWS.V_MST_VPC_MYP_CLIENTE_NAT CLN
    ON
    CL.CLIENTE_ID = CLN.CLIENTE_ID



-- =============================
-- PERSONAS RELACIONADAS
-- =============================

SELECT
	CrCl.CodCredito,
	IsNull(CrLs.CodigoLPC,Cr.CodOperacionActiva) As CodOperacionActiva,
	CrCl.CodCliente,
	CrCl.Relacion
FROM dbo.CreditoCliente CrCl
INNER JOIN dbo.Credito Cr On CrCl.CodCredito = Cr.CodCredito
LEFT JOIN dbo.CreditoLeasing CrLs On CrCl.CodCredito = CrLs.CodCredito