ALTER PROCEDURE [cob].[sp_COBRANZAS_EfectividadDiaria_ProcesarDatos](
	@Flag_Reprocesar BIT = 0
)
AS
BEGIN

	DECLARE
		@FechaSaldos DATE,
		@FechaProceso VARCHAR(8),
		@FechaAnterior DATE,
		@MesActual NUMERIC(6),
		@MesAnterior NUMERIC(6),
		@FechaInicio_MesAct DATE,
		@FechaCierre_MesAct DATE,
		@FechaCierre_MesAnt DATE,
		@Tc FLOAT,
		@Query VARCHAR(5000),
		@Flag_Cierre BIT,
		@id_Proceso INT,
		@Flag_DiaHabil BIT
	SET @FechaSaldos = (SELECT DISTINCT AS_OF_DATE FROM BPE.dbo.vw_SaldosDiario)  --( SELECT DISTINCT AS_OF_DATE FROM BPE.dbo.vw_SaldosDiario ) --'2022-08-10' 
	SET @FechaProceso = Convert(VARCHAR(8),@FechaSaldos,112)
	SET @FechaAnterior = ( SELECT Max(FECHA) FROM BPE.cob.vw_EFECTIVIDAD_DIARIA WHERE FECHA < @FechaSaldos )
	SET @MesActual = ( SELECT CODMES_BPE FROM BPE.dbo.vw_CALENDARIO WHERE FECHA = @FechaSaldos ) --( SELECT Convert(VARCHAR(6),@FechaSaldos,112) )
	SET @MesAnterior = BPE.dbo.fn_Fec_Variar_Periodo(@MesActual,-1)
	SET @FechaInicio_MesAct = ( SELECT FECHA FROM BPE.dbo.vw_CALENDARIO WHERE CODMES_BPE = @MesActual And FLAG_INICIO = 1 )
	SET @FechaCierre_MesAct = ( SELECT FECHA FROM BPE.dbo.vw_CALENDARIO WHERE CODMES_BPE = @MesActual And FLAG_CIERRE = 1 )
	SET @FechaCierre_MesAnt = ( SELECT FECHA FROM BPE.dbo.vw_CALENDARIO WHERE CODMES_BPE = @MesAnterior And FLAG_CIERRE = 1 )
	SET @Flag_Cierre = 0
	SET @id_Proceso = 32

	IF @FechaSaldos = @FechaCierre_MesAct
		SET @Flag_Cierre = 1

	IF @Flag_Cierre = 1
		SET @Tc = ( SELECT TipoCambio FROM BPE.dbo.vw_DatosCierre WHERE Mes = @MesActual )
		ELSE
		SET @Tc = ( SELECT TipoCambio FROM BPE.dbo.vw_DatosCierre WHERE Mes = @MesAnterior )

	SET @Flag_DiaHabil = ( SELECT FLAG_DIA_HABIL FROM BPE.dbo.vw_CALENDARIO WHERE FECHA = Convert(DATE,Getdate()) )

	-----------------------
	-- VALIDAMOS PROCESO --
	-----------------------

	IF ( ( SELECT Count(*) FROM BPE.cob.BASE_EFECTIVIDAD_DIARIA WHERE FECHA = @FechaSaldos ) = 0 And @Flag_DiaHabil = 1 ) Or @Flag_Reprocesar = 1
	BEGIN

		------------------------
		-- CREAMOS TEMPORALES --
		------------------------

		IF OBJECT_ID('cob.CobranzaEfectividad_Base') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Base
		IF OBJECT_ID('cob.CobranzaEfectividad_Saldos') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Saldos
		IF OBJECT_ID('cob.CobranzaEfectividad_Consolidado') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Consolidado
		IF OBJECT_ID('cob.CobranzaEfectividad_Pagos') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Pagos
		IF OBJECT_ID('cob.CobranzaEfectividad_Cuotas') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Cuotas
		IF OBJECT_ID('cob.CobranzaEfectividad_Dm_Max') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Dm_Max
		IF OBJECT_ID('cob.CobranzaEfectividad_Prepagos') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Prepagos
		IF OBJECT_ID('cob.CobranzaEfectividad_Provisiones') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Provisiones
		IF OBJECT_ID('cob.CobranzaEfectividad_MarcaAtraso') Is Not NULL DROP TABLE cob.CobranzaEfectividad_MarcaAtraso
		IF OBJECT_ID('cob.CobranzaEfectividad_Moneda') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Moneda
		-------
		IF OBJECT_ID('cob.CobranzaEfectividad_SaldoCierre') Is Not NULL DROP TABLE cob.CobranzaEfectividad_SaldoCierre
		IF OBJECT_ID('cob.CobranzaEfectividad_MarcaCliente') Is Not NULL DROP TABLE cob.CobranzaEfectividad_MarcaCliente
		IF OBJECT_ID('cob.CobranzaEfectividad_CIMA_2') Is Not NULL DROP TABLE cob.CobranzaEfectividad_CIMA_2
		IF OBJECT_ID('cob.CobranzaEfectividad_Reactiva') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Reactiva
		IF OBJECT_ID('cob.CobranzaEfectividad_MarcaCliente_2') Is Not NULL DROP TABLE cob.CobranzaEfectividad_MarcaCliente_2
		IF OBJECT_ID('cob.CobranzaEfectividad_UniversoCIMA') Is Not NULL DROP TABLE cob.CobranzaEfectividad_UniversoCIMA
		IF OBJECT_ID('cob.CobranzaEfectividad_UniversoSoloReactiva') Is Not NULL DROP TABLE cob.CobranzaEfectividad_UniversoSoloReactiva
		IF OBJECT_ID('cob.CobranzaEfectividad_Cli_Reg_Comparte_Reactiva') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Cli_Reg_Comparte_Reactiva
		---------
		CREATE TABLE cob.CobranzaEfectividad_Base (
			CODMES NUMERIC(6), DM_PROYECTADO INT, TRAMO_PROYECTADO VARCHAR(15), TRAMO_ASIGNACION VARCHAR(10), CARTERA VARCHAR(3),
			CENTRO VARCHAR(30), REGEJECUTIVO VARCHAR(8), CODUNICOCLI VARCHAR(10), COD_CREDITO VARCHAR(10),
			DM_INICIAL INT, TIPO_MONEDA VARCHAR(10), SALDO_INICIAL FLOAT, FECHA_VENCIMIENTO_INICIAL DATE,
			DM_ACTUAL INT, SALDO_ACTUAL FLOAT, FECHA_VENCIMIENTO_ACTUAL DATE
		)

		CREATE TABLE cob.CobranzaEfectividad_Saldos ( CODUNICOCLI VARCHAR(10), COD_CREDITO VARCHAR(10), NROPROD_X VARCHAR(10), SECTORISTA VARCHAR(9), TRAMO VARCHAR(5), DM INT, VIG NUMERIC(14,2), VEN NUMERIC(14,2), JUD NUMERIC(14,2), CASTIGO NUMERIC(14,2), SALDO FLOAT, FECHA_PROX_VENCIMIENTO DATE, CO_CALI_FINAL VARCHAR(1), TIP_CRED VARCHAR(1), AS_OF_DATE DATE, APLICATIVO VARCHAR(10) )
		CREATE TABLE cob.CobranzaEfectividad_Consolidado ( CODMES NUMERIC(6), FECHA DATE, CODUNICOCLI VARCHAR(10), COD_CREDITO VARCHAR(10), DM_INICIAL INT, TIPO_MONEDA VARCHAR(10), SALDO_INICIAL FLOAT, FECHA_VENCIMIENTO_INICIAL DATE, DM_ACTUAL SMALLINT, SALDO_ACTUAL FLOAT, FECHA_VENCIMIENTO_ACTUAL DATE, DM_FINAL INT, VIG_FINAL FLOAT, VEN_FINAL FLOAT, JUD_FINAL FLOAT, SALDO_FINAL FLOAT, FECHA_VENCIMIENTO_FINAL DATE, MES_VENCIMIENTO_FINAL VARCHAR(10), DM_MAX INT, RESULTADO VARCHAR(20), MONTO_PREPAGO FLOAT, CUOTAS_PAGADAS INT, SALDO_RECUPERADO FLOAT, SALDO_SOLUCIONADO FLOAT, CREDITO_SOLUCIONADO BIT, FLAG_INGRESO_ATRASO BIT, GASTO_CREDITO FLOAT, GASTO_CLIENTE FLOAT , GRUPO_CYBER SMALLINT, CUENTA_CYBER VARCHAR(14), /*2022.09.08*/ Universo VARCHAR(25), Score smallint, NR_Cobranza VARCHAR(25), Flag_VoiceBot VARCHAR(1), APLICATIVO VARCHAR(10)) -- AGREGUE LA COLUMNA APLICATIVO
		CREATE TABLE cob.CobranzaEfectividad_Pagos ( COD_CREDITO VARCHAR(10), CUOTAS_PAGADAS INT, SALDO_CAPITAL_CUOTA NUMERIC(16,2), DIAS INT, ULT_FECHA_PAGO DATE )
		CREATE TABLE cob.CobranzaEfectividad_Cuotas ( COD_CREDITO VARCHAR(10), CUOTAS_PAGADAS INT, SALDO_CAPITAL_CUOTA NUMERIC(16,2) )
		CREATE TABLE cob.CobranzaEfectividad_Dm_Max ( COD_CREDITO VARCHAR(10), DM_MAX INT ) --, MAX_FECHA_VENCIMIENTO_FINAL DATE )
		CREATE TABLE cob.CobranzaEfectividad_Prepagos ( COD_CREDITO VARCHAR(10), MONTO_PREPAGO FLOAT, ULT_FECHA_PREPAGO DATE )
		CREATE TABLE cob.CobranzaEfectividad_Provisiones ( COD_UNICO VARCHAR(10), COD_CREDITO VARCHAR(10), GASTO_CREDITO FLOAT, GASTO_CLIENTE FLOAT )
		CREATE TABLE cob.CobranzaEfectividad_MarcaAtraso ( COD_CREDITO VARCHAR(10) )
		CREATE TABLE cob.CobranzaEfectividad_Moneda ( COD_CREDITO VARCHAR (10), Cuenta_Cyber VARCHAR(14) )
		----------------------------------------------------------------------------------------------------
		CREATE TABLE cob.CobranzaEfectividad_SaldoCierre ( CODMES_ANTERIOR NUMERIC(6), CODMES NUMERIC(6), CIF_KEY VARCHAR(10), 
																NROPROD_X VARCHAR(10), FLAG_REACTIVA SMALLINT, FLAG_CIMA SMALLINT, 
																PRODUCTO_RECOD VARCHAR(100), CENTRO VARCHAR(50))
		CREATE TABLE cob.CobranzaEfectividad_MarcaCliente (CODMES_ANTERIOR NUMERIC(6), CODMES NUMERIC(6), CODUNICOCLI VARCHAR(10),
																NROPROD_X VARCHAR(10),FLAG_REACTIVA SMALLINT, FLAG_CIMA SMALLINT)
		CREATE TABLE cob.CobranzaEfectividad_CIMA_2 (CODMES NUMERIC(6), CODUNICOCLI VARCHAR(10), CREDITOS INT, FLAG_CIMA INT)
		CREATE TABLE cob.CobranzaEfectividad_Reactiva (CODMES NUMERIC(6), CODUNICOCLI VARCHAR(10), CREDITOS INT, FLAG_REACTIVA INT) 
		CREATE TABLE cob.CobranzaEfectividad_MarcaCliente_2 (CODMES NUMERIC(6), CODUNICOCLI VARCHAR(10), FLAG_REACTIVA INT, FLAG_CIMA INT, FLAG_CLIENTE_CIMA INT, FLAG_CLIENTE_REACTIVA INT, C_REACTIVA SMALLINT, C_CIMA SMALLINT, UNIVERSO VARCHAR(20), UNIVERSO_FINAL VARCHAR(20)) 
		CREATE TABLE cob.CobranzaEfectividad_UniversoCIMA (CODMES NUMERIC(6), CODUNICOCLI VARCHAR(10), FLAG_REACTIVA INT, FLAG_CIMA INT, FLAG_CLIENTE_CIMA INT, FLAG_CLIENTE_REACTIVA INT, UNIVERSO VARCHAR(20)) 
		CREATE TABLE cob.CobranzaEfectividad_UniversoSoloReactiva (CODMES NUMERIC(6), CODUNICOCLI VARCHAR(10), FLAG_REACTIVA INT, FLAG_CIMA INT, FLAG_CLIENTE_CIMA INT, FLAG_CLIENTE_REACTIVA INT, UNIVERSO VARCHAR(20))
		CREATE TABLE cob.CobranzaEfectividad_Cli_Reg_Comparte_Reactiva (CODMES NUMERIC(6),CODUNICOCLI NUMERIC(10),FLAG_REACTIVA INT, UNIVERSO VARCHAR(20))
		----------------------------------------------------------------------------------------------------
		
		----------------------------
		-- BASE COBRANZAS DEL MES --
		----------------------------

		IF @FechaAnterior = @FechaCierre_MesAnt
		BEGIN
			INSERT INTO cob.CobranzaEfectividad_Base (
				CODMES, DM_PROYECTADO, TRAMO_PROYECTADO, TRAMO_ASIGNACION, CARTERA, CENTRO, REGEJECUTIVO, CODUNICOCLI, COD_CREDITO, DM_INICIAL, TIPO_MONEDA, SALDO_INICIAL, FECHA_VENCIMIENTO_INICIAL, DM_ACTUAL, SALDO_ACTUAL, FECHA_VENCIMIENTO_ACTUAL
			)
			SELECT
				CODMES, DM_PROYECTADO, TRAMO_PROYECTADO, TRAMO_ASIGNACION, CARTERA, CENTRO, REGEJECUTIVO, CODUNICOCLI, COD_CREDITO,
				DM_INICIAL, TIPO_MONEDA, SALDO_INICIAL, FECHA_VENCIMIENTO_INICIAL,
				IsNull( ( CASE WHEN DateDiff(Day,FECHA_VENCIMIENTO_INICIAL,@FechaSaldos) <= 0 THEN 0 ELSE DateDiff(Day,FECHA_VENCIMIENTO_INICIAL,@FechaSaldos) END ), 0 ),
				--DM_INICIAL,
				SALDO_INICIAL, FECHA_VENCIMIENTO_INICIAL
			FROM BPE.cob.vw_BASE_COBRANZAS
			WHERE CODMES = @MesActual
		END

		ELSE

		BEGIN
			INSERT INTO cob.CobranzaEfectividad_Base (
				CODMES, DM_PROYECTADO, TRAMO_PROYECTADO, TRAMO_ASIGNACION, CARTERA, CENTRO, REGEJECUTIVO, CODUNICOCLI, COD_CREDITO, DM_INICIAL, TIPO_MONEDA, SALDO_INICIAL, FECHA_VENCIMIENTO_INICIAL, DM_ACTUAL, SALDO_ACTUAL, FECHA_VENCIMIENTO_ACTUAL
			)
			SELECT
				E.CODMES, A.DM_PROYECTADO, A.TRAMO_PROYECTADO, A.TRAMO_ASIGNACION, A.CARTERA, A.CENTRO, A.REGEJECUTIVO, A.CODUNICOCLI, E.COD_CREDITO,
				E.DM_INICIAL, A.TIPO_MONEDA, E.SALDO_INICIAL, E.FECHA_VENCIMIENTO_INICIAL,
				IsNull( ( CASE WHEN DateDiff(Day,E.FECHA_VENCIMIENTO_FINAL,@FechaSaldos) <= 0 THEN 0 ELSE DateDiff(Day,E.FECHA_VENCIMIENTO_FINAL,@FechaSaldos) END ), 0 ),
				E.SALDO_FINAL, E.FECHA_VENCIMIENTO_FINAL
			FROM BPE.cob.vw_EFECTIVIDAD_DIARIA E
			INNER JOIN BPE.cob.vw_BASE_COBRANZAS A On E.CODMES = A.CODMES And E.COD_CREDITO = A.COD_CREDITO
			WHERE E.FECHA = @FechaAnterior

			INSERT INTO cob.CobranzaEfectividad_Base (
				CODMES, DM_PROYECTADO, TRAMO_PROYECTADO, TRAMO_ASIGNACION, CARTERA, CENTRO, REGEJECUTIVO, CODUNICOCLI, COD_CREDITO, DM_INICIAL, TIPO_MONEDA, SALDO_INICIAL, FECHA_VENCIMIENTO_INICIAL, DM_ACTUAL, SALDO_ACTUAL, FECHA_VENCIMIENTO_ACTUAL
			)
			SELECT
				CODMES, DM_PROYECTADO, TRAMO_PROYECTADO, TRAMO_ASIGNACION, CARTERA, CENTRO, REGEJECUTIVO, CODUNICOCLI, COD_CREDITO,
				DM_INICIAL, TIPO_MONEDA, SALDO_INICIAL, FECHA_VENCIMIENTO_INICIAL,
				IsNull( ( CASE WHEN DateDiff(Day,FECHA_VENCIMIENTO_INICIAL,@FechaSaldos) <= 0 THEN 0 ELSE DateDiff(Day,FECHA_VENCIMIENTO_INICIAL,@FechaSaldos) END ), 0 ),
				--DM_INICIAL,
				SALDO_INICIAL, FECHA_VENCIMIENTO_INICIAL
			FROM BPE.cob.vw_BASE_COBRANZAS
			WHERE CODMES = @MesActual And COD_CREDITO Not In (
				SELECT COD_CREDITO FROM cob.CobranzaEfectividad_Base
			)
		END

		--ACTUALIZAR PARA PRIMER DIA

		----------------------------
		-- SALDOS DIARIO (ÚLTIMO) --
		----------------------------

		SET @Query = '
			INSERT INTO cob.CobranzaEfectividad_Saldos ( CODUNICOCLI, COD_CREDITO, NROPROD_X, SECTORISTA, TRAMO, DM, VIG, VEN, JUD, CASTIGO, SALDO, FECHA_PROX_VENCIMIENTO, CO_CALI_FINAL, TIP_CRED, AS_OF_DATE, APLICATIVO )
			SELECT CIF_KEY, NROPROD, NROPROD_X, SECTORISTA, TRAMO, DM, VIG, VEN, JUD, CASTIGO, SALDO, FECHA_PROX_VENCIMIENTO, CO_CALI_FINAL, TIP_CRED, AS_OF_DATE , APLICATIVO
			FROM BPE.dbo.SaldosDiario_'+Convert(VARCHAR(6),@MesActual)+'
			WHERE (VIG + VEN + JUD + CASTIGO) > 0 AND
				AS_OF_DATE = '+CHAR(39)+Convert(VARCHAR(8),@FechaSaldos,112)+CHAR(39)

		EXEC ( @Query )



		-------------------------------------
		-- ACTUALIZAMOS EL TIPO DE CRÉDITO --
		-------------------------------------
		UPDATE A
		SET A.COD_TIPO_CREDITO = Sd.TIP_CRED
		FROM BPE.cob.BASE_COBRANZAS A
		INNER JOIN cob.CobranzaEfectividad_Saldos Sd On A.COD_CREDITO = Sd.NROPROD_X
		WHERE A.CODMES = @MesActual

		-------------------------
		-- CREAMOS CONSOLIDADO --
		-------------------------

		INSERT INTO cob.CobranzaEfectividad_Consolidado (
			CODMES, FECHA, CODUNICOCLI, COD_CREDITO, DM_INICIAL, TIPO_MONEDA, SALDO_INICIAL, FECHA_VENCIMIENTO_INICIAL, DM_ACTUAL, SALDO_ACTUAL, FECHA_VENCIMIENTO_ACTUAL, DM_FINAL, VIG_FINAL, VEN_FINAL, JUD_FINAL, SALDO_FINAL, FECHA_VENCIMIENTO_FINAL, MES_VENCIMIENTO_FINAL, APLICATIVO )
		SELECT
			A.CODMES,
			@FechaSaldos As FECHA,
			A.CODUNICOCLI,
			A.COD_CREDITO,
			A.DM_INICIAL,
			A.TIPO_MONEDA,
			A.SALDO_INICIAL,
			A.FECHA_VENCIMIENTO_INICIAL,
			A.DM_ACTUAL,
			--IsNull( ( CASE WHEN @FechaSaldos > A.FECHA_VENCIMIENTO_ACTUAL And B.FECHA_PROX_VENCIMIENTO = A.FECHA_VENCIMIENTO_ACTUAL THEN DateDiff(Day,A.FECHA_VENCIMIENTO_ACTUAL,@FechaSaldos) ELSE 0 END ), 0 ) As DM_ACTUAL,
			A.SALDO_ACTUAL,
			A.FECHA_VENCIMIENTO_ACTUAL,
			--B.DM,
			IsNull( ( CASE WHEN DateDiff(Day,B.FECHA_PROX_VENCIMIENTO,@FechaSaldos) <= 0 THEN 0 ELSE DateDiff(Day,B.FECHA_PROX_VENCIMIENTO,@FechaSaldos) END ), 0 ) As DM,
			IsNull( B.VIG*@Tc, 0 ),
			IsNull( B.VEN*@Tc, 0 ),
			IsNull( B.JUD*@Tc, 0 ),
			IsNull( B.SALDO*@Tc, 0 ),
			B.FECHA_PROX_VENCIMIENTO,
			( CASE
				WHEN B.FECHA_PROX_VENCIMIENTO Is NULL THEN 'No Aplica'
				WHEN B.FECHA_PROX_VENCIMIENTO <= @FechaCierre_MesAnt THEN 'Anterior'
				WHEN B.FECHA_PROX_VENCIMIENTO > @FechaCierre_MesAnt And B.FECHA_PROX_VENCIMIENTO <= @FechaCierre_MesAct THEN 'Actual'
				ELSE 'Posterior'
			END ) As MES_VENCIMIENTO,
			B.APLICATIVO
		FROM cob.CobranzaEfectividad_Base A
		LEFT JOIN cob.CobranzaEfectividad_Saldos B On A.COD_CREDITO = B.NROPROD_X

		------------------------------------
		-- EXTRAEMOS DATOS DEL CRONOGRAMA --
		------------------------------------
		
		INSERT INTO cob.CobranzaEfectividad_Pagos ( COD_CREDITO, CUOTAS_PAGADAS, SALDO_CAPITAL_CUOTA, DIAS, ULT_FECHA_PAGO )
		SELECT
			COD_CREDITO,
			Count(*) As CUOTAS_PAGADAS,
			Sum(MontoPrincipal) As SALDO_CAPITAL_CUOTA,
			Max(DateDiff(Day,FechaVencimiento,FechaPago)) As DIAS,
			Max(FechaPago) As ULT_FECHA_PAGO
		FROM BPE.dbo.vw_Cronogramas
		WHERE ( FechaPago > @FechaCierre_MesAnt And FechaPago <= @FechaSaldos ) And EstadoCuota Not In ( 'Prepago' )
		GROUP BY Cod_Credito

		UPDATE A
		SET A.CUOTAS_PAGADAS = IsNull(B.CUOTAS_PAGADAS,0)
		FROM cob.CobranzaEfectividad_Consolidado A
		LEFT JOIN cob.CobranzaEfectividad_Pagos B On A.COD_CREDITO = B.COD_CREDITO

		INSERT INTO cob.CobranzaEfectividad_Prepagos ( COD_CREDITO, MONTO_PREPAGO, ULT_FECHA_PREPAGO )
		SELECT
			Cod_Credito,
			Sum(MontoCuota) As MONTO_PREPAGO,
			Max(FechaPago) As ULT_FECHA_PREPAGO
		FROM BPE.dbo.vw_Cronogramas
		WHERE ( FechaPago > @FechaCierre_MesAnt And FechaPago <= @FechaSaldos ) And EstadoCuota = 'Prepago'
		GROUP BY Cod_Credito

		UPDATE A
		SET A.MONTO_PREPAGO = IsNull(B.MONTO_PREPAGO,0)
		FROM cob.CobranzaEfectividad_Consolidado A
		LEFT JOIN cob.CobranzaEfectividad_Prepagos B On A.COD_CREDITO = B.COD_CREDITO

		/*SELECT *
		FROM cob.CobranzaEfectividad_Consolidado A
		INNER JOIN cob.CobranzaEfectividad_Pagos Pag On A.COD_CREDITO = Pag.COD_CREDITO And A.FECHA_VENCIMIENTO_ACTUAL < Pag.ULT_FECHA_PAGO
		--WHERE FECHA_VENCIMIENTO_ACTUAL >= @FechaAnterior And FECHA_VENCIMIENTO_ACTUAL < @FechaSaldos
		WHERE A.FECHA_VENCIMIENTO_ACTUAL > '20190327' And A.FECHA_VENCIMIENTO_ACTUAL < '20190328'*/

		---------------------------
		-- DÍAS DE ATRASO MÁXIMO --
		---------------------------

		INSERT INTO cob.CobranzaEfectividad_Dm_Max ( COD_CREDITO, DM_MAX )
		SELECT COD_CREDITO, Max(DM_ACTUAL) As DM_MAX
		FROM (
			SELECT COD_CREDITO, DM_ACTUAL
			FROM BPE.cob.BASE_EFECTIVIDAD_DIARIA
			WHERE
				CODMES = @MesActual
				And FECHA < @FechaSaldos
			UNION
			SELECT COD_CREDITO, DM_MAX
			FROM BPE.cob.BASE_EFECTIVIDAD_DIARIA
			WHERE
				CODMES = @MesActual
				And FECHA < @FechaSaldos
			UNION
			SELECT COD_CREDITO, DM_ACTUAL
			FROM cob.CobranzaEfectividad_Consolidado
			UNION
			SELECT COD_CREDITO, DM_INICIAL
			FROM BPE.cob.BASE_COBRANZAS
			WHERE
				CODMES = @MesActual
		) Tmp
		GROUP BY COD_CREDITO

		UPDATE A
		SET A.DM_MAX = B.DM_MAX --( CASE WHEN B.DM_MAX Is NULL Or B.DM_MAX < A.DM_INICIAL THEN A.DM_INICIAL ELSE B.DM_MAX END )
		FROM cob.CobranzaEfectividad_Consolidado A
		LEFT JOIN cob.CobranzaEfectividad_Dm_Max B On A.COD_CREDITO = B.COD_CREDITO

		--------------
		-- TEMPORAL --
		--------------

		SET @Query = '
			INSERT INTO cob.CobranzaEfectividad_Cuotas ( COD_CREDITO, CUOTAS_PAGADAS, SALDO_CAPITAL_CUOTA )
			SELECT
				Cod_Credito,
				Count(*) As CUOTAS_PAGADAS,
				Sum(MontoPrincipal) As SALDO_CAPITAL_CUOTA
			FROM BPE.dbo.Cronogramas_'+Convert(VARCHAR(6),@MesAnterior)+'
			WHERE
				( FechaVencimiento > '+CHAR(39)+Convert(VARCHAR(8),@FechaCierre_MesAnt,112)+CHAR(39)+' And FechaVencimiento <= '+CHAR(39)+Convert(VARCHAR(8),@FechaCierre_MesAct,112)+CHAR(39)+' )
				And EstadoCuota Not In ( '+CHAR(39)+'Prepago'+CHAR(39)+' )
			GROUP BY Cod_Credito
		'

		EXEC ( @Query )

		-------------------------
		-- EVALUAMOS RESULTADO --
		-------------------------

		UPDATE cob.CobranzaEfectividad_Consolidado
		SET RESULTADO =
			( CASE
				WHEN FECHA_VENCIMIENTO_FINAL Is NULL THEN 'Canceló'
				WHEN FECHA_VENCIMIENTO_FINAL > @FechaCierre_MesAct THEN 'Pagó' --Era >
				WHEN FECHA_VENCIMIENTO_INICIAL < FECHA_VENCIMIENTO_FINAL And FECHA_VENCIMIENTO_FINAL <= @FechaCierre_MesAct THEN 'Pagó / Por Vencer'
				--WHEN FECHA_VENCIMIENTO_ACTUAL = FECHA_VENCIMIENTO_FINAL And FECHA_VENCIMIENTO_FINAL <= @FechaCierre_MesAct And FECHA_VENCIMIENTO_FINAL > @FechaSaldos THEN 'Por Vencer'
				WHEN FECHA_VENCIMIENTO_FINAL <= @FechaCierre_MesAct And FECHA_VENCIMIENTO_FINAL > @FechaSaldos THEN 'Por Vencer'
				WHEN DateDiff(Day,FECHA_VENCIMIENTO_ACTUAL,FECHA_VENCIMIENTO_FINAL) = -1 And FECHA_VENCIMIENTO_FINAL <= @FechaCierre_MesAct And FECHA_VENCIMIENTO_FINAL > @FechaSaldos THEN 'Por Vencer' --INCONSISTENCIA
				WHEN FECHA_VENCIMIENTO_INICIAL = FECHA_VENCIMIENTO_FINAL THEN 'No Pagó'
				--WHEN FECHA_VENCIMIENTO_INICIAL < FECHA_VENCIMIENTO_ACTUAL And FECHA_VENCIMIENTO_ACTUAL = FECHA_VENCIMIENTO_FINAL THEN 'No Pagó'
				WHEN SALDO_ACTUAL = SALDO_FINAL And FECHA_VENCIMIENTO_FINAL <= @FechaCierre_MesAct And FECHA_VENCIMIENTO_FINAL <= @FechaSaldos THEN 'No Pagó'
				WHEN SALDO_ACTUAL <> SALDO_FINAL And FECHA_VENCIMIENTO_FINAL < FECHA_VENCIMIENTO_INICIAL THEN 'No Pagó'
				ELSE 'A revisar'
			END )

		UPDATE cob.CobranzaEfectividad_Consolidado
		SET RESULTADO = 'Amortizó'
		WHERE
			IsNull(RESULTADO,'') In ( 'No Pagó', 'Por Vencer', '' ) --IsNull(RESULTADO,'') = 'No Pagó'
			And Round(SALDO_INICIAL,0) > Round(SALDO_FINAL,0)
			And FECHA_VENCIMIENTO_INICIAL = FECHA_VENCIMIENTO_FINAL
			And MONTO_PREPAGO = 0
			And TIPO_MONEDA = 'SOLES' --28/01/2019

		--CAMBIOS DE FECHA CON NUEVA FECHA DENTRO DEL MES EN GESTIÓN
		UPDATE cob.CobranzaEfectividad_Consolidado
		SET RESULTADO = 'Por Vencer'
		WHERE
			--FECHA_VENCIMIENTO_ACTUAL = FECHA_VENCIMIENTO_FINAL And
			FECHA_VENCIMIENTO_FINAL <= @FechaCierre_MesAct
			And FECHA_VENCIMIENTO_FINAL > @FechaSaldos
			And RESULTADO = 'Pagó / Por Vencer'
			And COD_CREDITO In (
				SELECT Cod_Credito FROM BPE.dbo.vw_CambiosFecha
				WHERE
					Convert(VARCHAR(6),FechaCambio,112) = @MesActual
					And Id_TipoCF = 2
					And Flag_OperacionAgil = 0
			)

		--INICIO INCONSISTENCIA
		/*UPDATE cob.CobranzaEfectividad_Consolidado
		SET RESULTADO = 'No Pagó'
		WHERE
			MES_VENCIMIENTO_FINAL = 'Actual'
			And Round(SALDO_INICIAL,0) <= Round(SALDO_FINAL,0)
			And DateDiff(Day,FECHA_VENCIMIENTO_INICIAL,FECHA_VENCIMIENTO_FINAL) = -1
			And IsNull(RESULTADO,'') = ''*/

		UPDATE cob.CobranzaEfectividad_Consolidado
		SET RESULTADO = 'No Pagó'
		WHERE
			MES_VENCIMIENTO_FINAL = 'Actual'
			And Round(SALDO_INICIAL,0) > Round(SALDO_FINAL,0)
			And DateDiff(Day,FECHA_VENCIMIENTO_INICIAL,FECHA_VENCIMIENTO_FINAL) = -1
			And IsNull(RESULTADO,'') = ''
			And CODMES = 201812
			And COD_CREDITO = '0010160186'
		--FIN INCONSISTENCIA

		--CAMBIOS DE FECHA ( PRÓXIMO MES )
		UPDATE cob.CobranzaEfectividad_Consolidado
		SET RESULTADO = 'Cambio de Fecha'
		WHERE
			COD_CREDITO In (
				SELECT Cod_Credito FROM BPE.dbo.vw_CambiosFecha
				WHERE
					( FechaCambio Between @FechaInicio_MesAct And @FechaSaldos )
					And Id_TipoCF = 1
					And Flag_OperacionAgil = 0
			)
			And FECHA_VENCIMIENTO_FINAL > @FechaCierre_MesAct
			
		--REFINANCIADOS
		UPDATE cob.CobranzaEfectividad_Consolidado
		SET RESULTADO = 'Refinanciado'
		WHERE COD_CREDITO In ( SELECT Cod_CreditoRefinanciado FROM BPE.dbo.vw_Refinanciados WHERE ( FechaDesembolso Between @FechaInicio_MesAct And @FechaSaldos ) And Producto Like '%REF%' )

		--REPROGRAMADOS
		UPDATE cob.CobranzaEfectividad_Consolidado
		SET RESULTADO = 'Reprogramado'
		WHERE COD_CREDITO In ( SELECT Cod_CreditoRefinanciado FROM BPE.dbo.vw_Refinanciados WHERE ( FechaDesembolso Between @FechaInicio_MesAct And @FechaSaldos ) And Producto Like '%REP%' )


		-- MYP con cuotas pendientes n
		UPDATE C
		SET RESULTADO = 'No Pagó'   
		FROM cob.CobranzaEfectividad_Consolidado C
		WHERE C.RESULTADO = 'Canceló'
		  AND C.APLICATIVO in  ('MYP','CCD') --Agregar CCD
		  AND EXISTS (
				SELECT 1
				FROM BPE.dbo.vw_Cronogramas CR
				WHERE CR.Cod_Credito = C.COD_CREDITO
				  AND CR.FechaVencimiento = C.FECHA_VENCIMIENTO_FINAL
				  AND CR.FechaPago is null
		  );
		--Desaparecidos de SaldoDiario
		UPDATE C
		SET RESULTADO = 'No Pagó'
		FROM cob.CobranzaEfectividad_Consolidado C
		WHERE C.RESULTADO = 'Canceló'
		  AND NOT EXISTS (
				SELECT 1
				FROM BPE.dbo.SaldosDiario SD
				WHERE SD.NROPROD = C.COD_CREDITO
			)
		  AND EXISTS (
				SELECT 1
				FROM BPE.dbo.vw_Cronogramas CR
				WHERE CR.Cod_Credito = C.COD_CREDITO
				  AND CR.FechaPago IS NULL
			);

		/*
		Actual    => Amortizó | No Pagó | Pagó / Por Vencer | Por Vencer
		Anterior  => Amortizó | No Pagó | Pagó / Por Vencer
		Posterior => Cambio de Fecha | Pagó
		No Aplica => Canceló | Refinanciado | Reprogramado
		*/
		
		-------------------------
		-- CREDITO_SOLUCIONADO --
		-------------------------

		UPDATE A
		SET
			A.CREDITO_SOLUCIONADO = (
			CASE
				WHEN ( A.RESULTADO In ( 'Canceló', 'Refinanciado', 'Reprogramado', 'Cambio de Fecha' ) ) THEN 1
				WHEN
					( A.RESULTADO In ( 'Pagó', 'Pagó / Por Vencer' ) And B.TRAMO_ASIGNACION = 'Temprana' )
					Or
					( A.RESULTADO In ( 'Pagó', 'Pagó / Por Vencer' ) And B.TRAMO_ASIGNACION <> 'Temprana' And DateDiff(Day,A.FECHA_VENCIMIENTO_FINAL,@FechaCierre_MesAct) <= 30 )
				THEN 1
				ELSE 0
			END )
		FROM cob.CobranzaEfectividad_Consolidado A
		INNER JOIN cob.CobranzaEfectividad_Base B On A.COD_CREDITO = B.COD_CREDITO

		-----------------------
		-- SALDO_SOLUCIONADO --
		-----------------------

		UPDATE cob.CobranzaEfectividad_Consolidado
		SET SALDO_SOLUCIONADO = ( CASE WHEN CREDITO_SOLUCIONADO = 1 THEN SALDO_INICIAL ELSE 0 END )

		----------------------
		-- SALDO_RECUPERADO --
		----------------------

		UPDATE cob.CobranzaEfectividad_Consolidado
		SET SALDO_RECUPERADO = ( CASE WHEN CREDITO_SOLUCIONADO = 1 THEN SALDO_INICIAL-SALDO_FINAL ELSE 0 END )
		WHERE RESULTADO <> 'Canceló'

		UPDATE A
		SET A.SALDO_RECUPERADO = B.SALDO_CAPITAL_CUOTA
		FROM cob.CobranzaEfectividad_Consolidado A
		INNER JOIN cob.CobranzaEfectividad_Pagos B On A.COD_CREDITO = B.COD_CREDITO
		WHERE
			A.RESULTADO <> 'Canceló' --And A.SALDO_RECUPERADO <= 0
			And A.SALDO_SOLUCIONADO > 0

		--INICIO TEMPORAL
		UPDATE A
		SET A.SALDO_RECUPERADO = B.SALDO_CAPITAL_CUOTA
		--SELECT *
		FROM cob.CobranzaEfectividad_Consolidado A
		INNER JOIN cob.CobranzaEfectividad_Cuotas B On A.COD_CREDITO = B.COD_CREDITO
		WHERE A.RESULTADO Not In ( 'Canceló', 'Cambio de Fecha') And A.SALDO_RECUPERADO <= 0 And A.SALDO_SOLUCIONADO > 0
		--FIN TEMPORAL

		UPDATE cob.CobranzaEfectividad_Consolidado
		SET SALDO_RECUPERADO = SALDO_INICIAL
		WHERE RESULTADO = 'Canceló'

		--INCONSISTENCIAS

		UPDATE cob.CobranzaEfectividad_Consolidado
		SET SALDO_RECUPERADO = -1
		WHERE SALDO_RECUPERADO < 0 And RESULTADO <> 'Cambio de Fecha'

		UPDATE cob.CobranzaEfectividad_Consolidado
		SET SALDO_RECUPERADO = 0
		WHERE SALDO_RECUPERADO < 0 And RESULTADO = 'Cambio de Fecha' And CUOTAS_PAGADAS = 0

		--------------------------------
		-- INGRESÓ A MORA (x CRÉDITO) --
		--------------------------------

		INSERT INTO cob.CobranzaEfectividad_MarcaAtraso ( COD_CREDITO )
		SELECT COD_CREDITO
		FROM BPE.cob.BASE_EFECTIVIDAD_DIARIA
		WHERE
			FECHA = @FechaAnterior
			And FLAG_INGRESO_ATRASO = 1

		UPDATE cob.CobranzaEfectividad_Consolidado
		SET FLAG_INGRESO_ATRASO = 0

		UPDATE cob.CobranzaEfectividad_Consolidado
		SET FLAG_INGRESO_ATRASO = 1
		WHERE
			DM_INICIAL > 0
			Or DM_ACTUAL > 0
			Or DM_FINAL > 0
			Or FECHA_VENCIMIENTO_INICIAL <= @FechaCierre_MesAnt

		UPDATE cob.CobranzaEfectividad_Consolidado
		SET FLAG_INGRESO_ATRASO = 1
		WHERE COD_CREDITO In (
			SELECT COD_CREDITO
			FROM cob.CobranzaEfectividad_MarcaAtraso
		)


		-----------------------------------
		-- Universo,  SCORE, NR_Cobranza, Flag_VoiceBot 
		-----------------------------------
		INSERT	INTO cob.CobranzaEfectividad_SaldoCierre (CODMES_ANTERIOR,CODMES,CIF_KEY,NROPROD_X)
		--SELECT	202208, 202209, CIF_KEY, NROPROD_X
		SELECT	@MesAnterior,@MesActual,CIF_KEY,NROPROD_X 
		FROM	BPE.DBO.VW_SALDOSCIERRE
		WHERE	MES = @MesAnterior -- = 202208
		ORDER BY MES,CIF_KEY
		
		UPDATE cob.CobranzaEfectividad_SaldoCierre SET CODMES_ANTERIOR=202301 WHERE CODMES_ANTERIOR=202213
		UPDATE cob.CobranzaEfectividad_SaldoCierre SET CODMES_ANTERIOR=202401 WHERE CODMES_ANTERIOR=202313
		
		UPDATE  A
		SET		A.FLAG_REACTIVA = CASE WHEN A.NROPROD_X = B.COD_CREDITOORIGEN THEN 1 ELSE 0 END,
				A.FLAG_CIMA = CASE WHEN A.NROPROD_X = C.COD_CREDITO THEN 1 ELSE 0 END,
				A.PRODUCTO_RECOD = D.PRODUCTO_RECOD,
				A.CENTRO = D.CENTRO
		FROM	cob.CobranzaEfectividad_SaldoCierre A
		LEFT JOIN BPE.dbo.vw_Base_Reactiva B ON B.Cod_CreditoOrigen = A.NROPROD_X
		LEFT JOIN BPE.dbo.vw_CREDITOS_CIMA C ON C.Cod_Credito = A.NROPROD_X
		LEFT JOIN BPE.dbo.vw_DESEMBOLSOS D ON D.NROPROD_X = A.NROPROD_X

		--> Marca Cliente 
		INSERT INTO cob.CobranzaEfectividad_MarcaCliente 
		SELECT DISTINCT CODMES_ANTERIOR, CODMES, CIF_KEY CODUNICOCLI, NROPROD_X,FLAG_REACTIVA,FLAG_CIMA 
		FROM cob.CobranzaEfectividad_SaldoCierre

		--> CIMA
		INSERT INTO COB.CobranzaEfectividad_CIMA_2
		SELECT CODMES,CODUNICOCLI,COUNT(*) CREDITOS, SUM(FLAG_CIMA) FLAG_CIMA 
		FROM	cob.CobranzaEfectividad_MarcaCliente
		GROUP BY CODMES,CODUNICOCLI
		
		DELETE FROM COB.CobranzaEfectividad_CIMA_2 WHERE CREDITOS <> FLAG_CIMA
		
		--> Reactiva
		INSERT	INTO cob.CobranzaEfectividad_Reactiva
		SELECT	CODMES,CODUNICOCLI, COUNT(*)CREDITOS,SUM(FLAG_REACTIVA)FLAG_REACTIVA 
		FROM	cob.CobranzaEfectividad_MarcaCliente
		GROUP BY CODMES,CODUNICOCLI

		DELETE FROM COB.CobranzaEfectividad_Reactiva WHERE CREDITOS <> FLAG_REACTIVA
		
		--> Marca Cliente 2
		INSERT	cob.CobranzaEfectividad_MarcaCliente_2 (CODMES,CODUNICOCLI,FLAG_REACTIVA,FLAG_CIMA) 
		SELECT	CODMES,CODUNICOCLI,SUM(FLAG_REACTIVA) FLAG_REACTIVA,SUM(FLAG_CIMA) FLAG_CIMA
		FROM	COB.CobranzaEfectividad_MarcaCliente
		GROUP BY CODMES,CODUNICOCLI

		UPDATE	A
		SET		A.FLAG_CLIENTE_CIMA = CASE WHEN A.CODUNICOCLI=B.CODUNICOCLI THEN 1 ELSE 0 END,
				A.FLAG_CLIENTE_REACTIVA = CASE WHEN A.CODUNICOCLI=C.CODUNICOCLI THEN 1 ELSE 0 END 
		FROM	COB.CobranzaEfectividad_MarcaCliente_2 A
		left join COB.CobranzaEfectividad_CIMA_2 b on A.CODUNICOCLI=B.CODUNICOCLI AND A.CODMES=B.CODMES
		left join COB.CobranzaEfectividad_Reactiva C ON A.CODUNICOCLI=C.CODUNICOCLI AND A.CODMES=C.CODMES

		UPDATE COB.CobranzaEfectividad_MARCACLIENTE_2 SET FLAG_REACTIVA = 1 WHERE FLAG_REACTIVA >=1
		UPDATE COB.CobranzaEfectividad_MARCACLIENTE_2 SET FLAG_CIMA = 1 WHERE FLAG_CIMA >=1
		UPDATE COB.CobranzaEfectividad_MARCACLIENTE_2 SET FLAG_CLIENTE_CIMA =0 WHERE FLAG_CLIENTE_REACTIVA =1 AND FLAG_CLIENTE_CIMA =1

		-- Universo CIMA 
		INSERT INTO cob.CobranzaEfectividad_UniversoCIMA 
		SELECT	CODMES, CODUNICOCLI, FLAG_REACTIVA, FLAG_CIMA, FLAG_CLIENTE_CIMA, FLAG_CLIENTE_REACTIVA,'CIMA' UNIVERSO
		FROM	cob.CobranzaEfectividad_MARCACLIENTE_2
		WHERE	FLAG_CLIENTE_CIMA=1
		
		-- Universo solo Reactiva
		INSERT INTO cob.CobranzaEfectividad_UniversoSoloReactiva 
		SELECT	CODMES, CODUNICOCLI, FLAG_REACTIVA, FLAG_CIMA, FLAG_CLIENTE_CIMA, FLAG_CLIENTE_REACTIVA,'Solo_Reactiva' UNIVERSO
		FROM	cob.CobranzaEfectividad_MARCACLIENTE_2
		WHERE	FLAG_CLIENTE_REACTIVA=1
		
		-- (?) TMP
		UPDATE	A
		SET		A.C_CIMA = case when a.codmes=c.codmes and a.CODUNICOCLI=c.CODUNICOCLI then 1 else 0 end,
				A.C_REACTIVA = case when a.codmes=b.codmes and a.CODUNICOCLI=b.CODUNICOCLI then 1 else 0 end
		FROM	cob.CobranzaEfectividad_MarcaCliente_2 A 
		LEFT JOIN cob.CobranzaEfectividad_UniversoSoloReactiva B on B.codmes = A.codmes and b.CODUNICOCLI = a.CODUNICOCLI
		LEFT JOIN cob.CobranzaEfectividad_UniversoCIMA C on c.codmes = a.codmes and c.CODUNICOCLI = a.CODUNICOCLI
		
		-- (?) Cliente_Fin
		UPDATE	A
		SET		Universo = 'Regular'
		FROM	cob.CobranzaEfectividad_MarcaCliente_2 A 
		WHERE	A.C_REACTIVA = 0 and A.C_CIMA = 0
		
		DELETE FROM cob.CobranzaEfectividad_MarcaCliente_2 WHERE ISNULL(Universo,0) <> 'Regular'

		INSERT INTO cob.CobranzaEfectividad_MarcaCliente_2 (CODMES, CODUNICOCLI, FLAG_REACTIVA, FLAG_CIMA, FLAG_CLIENTE_CIMA, FLAG_CLIENTE_REACTIVA, UNIVERSO)
		SELECT * FROM COB.CobranzaEfectividad_UNIVERSOCIMA
		UNION
		SELECT * FROM COB.CobranzaEfectividad_UNIVERSOSOLOREACTIVA
	
		-- (?) Segunda Variante -- CLIENTES_REGULAR_COMPARTE_REACTIVA
		INSERT INTO cob.CobranzaEfectividad_Cli_Reg_Comparte_Reactiva (CODMES,CODUNICOCLI,FLAG_REACTIVA)
		SELECT	CODMES,CODUNICOCLI,SUM(FLAG_REACTIVA) FLAG_REACTIVA
		FROM	COB.CobranzaEfectividad_MARCACLIENTE_2 
		WHERE	Universo = 'Regular'
		GROUP BY CODMES,CODUNICOCLI
		
		-- Variante Mixtos 		
		UPDATE  cob.CobranzaEfectividad_Cli_Reg_Comparte_Reactiva
		SET		UNIVERSO = case when flag_reactiva=1 then 'Regular_Reactiva' else 'Regular' end 

		-- Tabla Final 
		UPDATE	A 
		SET		A.UNIVERSO_FINAL = ISNULL(B.UNIVERSO,A.UNIVERSO)
		FROM	cob.CobranzaEfectividad_MarcaCliente_2 A --cliente_fin // #UniversoFinal
		LEFT JOIN cob.CobranzaEfectividad_Cli_Reg_Comparte_Reactiva B ON B.CODMES = A.CODMES and B.CODUNICOCLI = A.CODUNICOCLI
		
		
		-- Actualización de la tabla cob.CobranzaEfectividad_Consolidado
		-- UNIVERSO
		UPDATE	A
		SET		A.Universo = B.UNIVERSO_FINAL
		FROM	cob.CobranzaEfectividad_Consolidado A
		LEFT JOIN cob.CobranzaEfectividad_MarcaCliente_2 B ON B.CODMES = A.CODMES AND B.CODUNICOCLI=A.CODUNICOCLI

		-- SCORE || Se desactiva 2026.01.02
		--UPDATE	A
		--SET		A.Score = B.Score
		--FROM	cob.CobranzaEfectividad_Consolidado A
		--LEFT JOIN BPE.dbo.vw_Score Cobranza B ON B.COD_UNICO=A.CODUNICOCLI AND B.MES=A.CODMES
	
		UPDATE	cob.CobranzaEfectividad_Consolidado SET Score=0 where Score IS NULL 

		-- NR_Cobranza
		--UPDATE	A
		--SET		A.NR_Cobranza =	case when a.Universo='Regular' and a.Score<=880 THEN '4.Alto'
		--							 when a.Universo='Regular' and a.Score<=944 THEN '3.Medio'
		--							 when a.Universo='Regular' and a.Score<=972 THEN '2.Bajo'     
		--							 when a.Universo='Regular' and a.Score>=973 THEN '1.Bajo Top' 
		--							 when a.Universo='Cima' THEN '1.Alto'      
		--							 when a.Universo in ('Regular_Reactiva','Solo_Reactiva') and a.Score<=832 THEN '3.Alto'
		--							 when a.Universo in ('Regular_Reactiva','Solo_Reactiva') and a.Score<=970 THEN '2.Medio'  
		--							 when a.Universo in ('Regular_Reactiva','Solo_Reactiva') and a.Score>=971 THEN '1.Bajo' 
		--							 else 'Otro' end     
		--FROM cob.CobranzaEfectividad_Consolidado A

		-- Flag_VoiceBot
		--UPDATE	A
		--SET		A.Flag_VoiceBot = case when a.Universo in ('Regular') then
		--							(case when a.NR_Cobranza = '1.Bajo Top' and a.DM_FINAL in (1,2) then 1
		--								  when a.NR_Cobranza = '2.Bajo'		and a.DM_FINAL in (1) then 1
		--								  when a.NR_Cobranza = '3.Medio'	and a.DM_FINAL in (1) THEN 1
		--								 ELSE 0 END) 
		--								when a.Universo in ('Regular_Reactiva','Solo_Reactiva') then		     
		--							(case when a.NR_Cobranza IN ('1.Bajo') and a.DM_FINAL in (1) then 1 ELSE 0 END) ELSE 0 END
		--from cob.CobranzaEfectividad_Consolidado A


		
		-----------------------------------
		-- CÁLCULO DE CUENTA/GRUPO CYBER --
		-----------------------------------

		INSERT INTO cob.CobranzaEfectividad_Moneda (COD_CREDITO, Cuenta_Cyber)
		SELECT	DISTINCT A.NROPROD_X,
				(RIGHT(A.NROPROD_X,8)+'BPE' + CASE WHEN B.TIPOMONEDA='SOLES' THEN '001' WHEN B.TIPOMONEDA='DOLARES' THEN '010' END) CUENTA_CYBER
		FROM BPE.DBO.VW_SALDOSDIARIO A
		INNER JOIN BPE.DBO.VW_SOLICITUDES B ON A.NROPROD_X=B.Cod_Credito
		WHERE	B.TIPOMONEDA IS NOT NULL
		-- SELECT * FROM cob.CobranzaEfectividad_Moneda 
		
		UPDATE	C
		SET		C.GRUPO_CYBER = 7, 
				C.CUENTA_CYBER = X.CUENTA_CYBER
		FROM	cob.CobranzaEfectividad_Consolidado C
		INNER JOIN	cob.CobranzaEfectividad_Moneda X ON X.COD_CREDITO = C.COD_CREDITO
		
		-----------------
		-- PROVISIONES --
		-----------------

		INSERT INTO cob.CobranzaEfectividad_Provisiones ( Cod_Unico, Cod_Credito, Gasto_Credito )
		SELECT Cod_Unico, Cod_CreditoOrigen, Gasto
		FROM BPE.dbo.vw_Provisiones
		WHERE FechaSaldos = @FechaSaldos

		UPDATE A
		SET A.Gasto_Cliente = B.Gasto_Cliente
		FROM cob.CobranzaEfectividad_Provisiones A
		INNER JOIN (
			SELECT Cod_Unico, Sum(Gasto_Credito) As Gasto_Cliente FROM cob.CobranzaEfectividad_Provisiones GROUP BY Cod_Unico
		) B On A.Cod_Unico = B.Cod_Unico

		UPDATE A
		SET
			A.GASTO_CREDITO = B.Gasto_Credito,
			A.GASTO_CLIENTE = B.Gasto_Cliente
		FROM cob.CobranzaEfectividad_Consolidado A
		INNER JOIN cob.CobranzaEfectividad_Provisiones B On A.COD_CREDITO = B.Cod_Credito

		------------------
		-- CONSOLIDAMOS --
		------------------

		EXEC dbo.sp_General_Eliminar_Indices 'BPE', 'cob', 'BASE_EFECTIVIDAD_DIARIA', 'CODMES-COD_CREDITO'
		EXEC dbo.sp_General_Eliminar_Indices 'BPE', 'cob', 'BASE_EFECTIVIDAD_DIARIA', 'CODMES'
		EXEC dbo.sp_General_Eliminar_Indices 'BPE', 'cob', 'BASE_EFECTIVIDAD_DIARIA', 'COD_CREDITO'
		EXEC dbo.sp_General_Eliminar_Indices 'BPE', 'cob', 'BASE_EFECTIVIDAD_DIARIA', 'RESULTADO'

		DELETE FROM BPE.cob.BASE_EFECTIVIDAD_DIARIA WHERE FECHA = @FechaSaldos

		EXEC dbo.sp_General_Eliminar_Indices 'BPE', 'cob', 'BASE_EFECTIVIDAD_DIARIA', 'FECHA'

		INSERT INTO BPE.cob.BASE_EFECTIVIDAD_DIARIA (
			CODMES, FECHA, COD_CREDITO, DM_ACTUAL, SALDO_ACTUAL, FECHA_VENCIMIENTO_ACTUAL, DM_FINAL, VIG_FINAL, VEN_FINAL, JUD_FINAL, SALDO_FINAL, FECHA_VENCIMIENTO_FINAL, MES_VENCIMIENTO_FINAL, RESULTADO, DM_MAX, MONTO_PREPAGO, CUOTAS_PAGADAS, SALDO_RECUPERADO, SALDO_SOLUCIONADO, CREDITO_SOLUCIONADO, FLAG_INGRESO_ATRASO, GASTO_CREDITO, GASTO_CLIENTE, GRUPO_CYBER, CUENTA_CYBER, /*Cambio: */UNIVERSO, SCORE , NR_COBRANZA , FLAG_VOICEBOT )
		SELECT
			CODMES, FECHA, COD_CREDITO, DM_ACTUAL, SALDO_ACTUAL, FECHA_VENCIMIENTO_ACTUAL, DM_FINAL, VIG_FINAL, VEN_FINAL, JUD_FINAL, SALDO_FINAL, FECHA_VENCIMIENTO_FINAL, MES_VENCIMIENTO_FINAL, RESULTADO, DM_MAX, MONTO_PREPAGO, CUOTAS_PAGADAS, SALDO_RECUPERADO, SALDO_SOLUCIONADO, CREDITO_SOLUCIONADO, FLAG_INGRESO_ATRASO, GASTO_CREDITO, GASTO_CLIENTE, GRUPO_CYBER, CUENTA_CYBER, /*Cambio: */UNIVERSO, SCORE , NR_COBRANZA , FLAG_VOICEBOT
		FROM cob.CobranzaEfectividad_Consolidado

		EXEC dbo.sp_General_Crear_Indices 'BPE', 'cob', 'BASE_EFECTIVIDAD_DIARIA', 'CODMES', 'PRIMARY', '', 'COD_CREDITO'
		EXEC dbo.sp_General_Crear_Indices 'BPE', 'cob', 'BASE_EFECTIVIDAD_DIARIA', 'CODMES'
		EXEC dbo.sp_General_Crear_Indices 'BPE', 'cob', 'BASE_EFECTIVIDAD_DIARIA', 'FECHA'
		EXEC dbo.sp_General_Crear_Indices 'BPE', 'cob', 'BASE_EFECTIVIDAD_DIARIA', 'COD_CREDITO'
		EXEC dbo.sp_General_Crear_Indices 'BPE', 'cob', 'BASE_EFECTIVIDAD_DIARIA', 'RESULTADO'

		---------------------------------------------
		-- EXPORTAMOS PARA Excel_EfectividadDiaria --
		---------------------------------------------
		
		TRUNCATE TABLE BPE.cob.Excel_EfectividadDiaria

		INSERT INTO BPE.cob.Excel_EfectividadDiaria (
			CODMES, FECHA, DIA_BPE, DM_PROYECTADO, TRAMO_PROYECTADO, TRAMO_ASIGNACION, DM_PROYECTADO_SR, TRAMO_PROYECTADO_SR, TRAMO_ASIGNACION_SR, CARTERA, ZONAL, CENTRO, REGEJECUTIVO, EJECUTIVO, CODUNICOCLI, CLIENTE, COD_CREDITO, PRODUCTO, DM_INICIAL, TRAMO_INICIAL, SALDO_INICIAL, FECHA_VENCIMIENTO_INICIAL, DM_ACTUAL, TRAMO_ACTUAL, SALDO_ACTUAL, FECHA_VENCIMIENTO_ACTUAL, TIPO_CREDITO, RESULTADO, MONTO_PREPAGO, CUOTAS_PAGADAS, SALDO_SOLUCIONADO, CREDITO_SOLUCIONADO, INGRESO_ATRASO, DM_FINAL, TRAMO_FINAL, VIG_FINAL, VEN_FINAL, JUD_FINAL, SALDO_FINAL, RMA, FECHA_VENCIMIENTO_FINAL, MES_VENCIMIENTO_FINAL, DM_MAX, FECHA_INGRESO_MC, IMPACTA_MC, SALDO_MC, GASTO_CREDITO, GASTO_CLIENTE, ID_ACCION, ACCION, ESTADO_CREDITO, EstadoReproReactiva, CREDITOS )
		SELECT
			CODMES, FECHA, DIA_BPE, DM_PROYECTADO, TRAMO_PROYECTADO, TRAMO_ASIGNACION, DM_PROYECTADO_SR, TRAMO_PROYECTADO_SR, TRAMO_ASIGNACION_SR, CARTERA, ZONAL, CENTRO, REGEJECUTIVO, EJECUTIVO, CODUNICOCLI, CLIENTE, COD_CREDITO, PRODUCTO, DM_INICIAL, TRAMO_INICIAL, SALDO_INICIAL, FECHA_VENCIMIENTO_INICIAL, DM_ACTUAL, TRAMO_ACTUAL, SALDO_ACTUAL, FECHA_VENCIMIENTO_ACTUAL, TIPO_CREDITO, RESULTADO, MONTO_PREPAGO, CUOTAS_PAGADAS, SALDO_SOLUCIONADO, CREDITO_SOLUCIONADO, INGRESO_ATRASO, DM_FINAL, TRAMO_FINAL, VIG_FINAL, VEN_FINAL, JUD_FINAL, SALDO_FINAL, RMA, FECHA_VENCIMIENTO_FINAL, MES_VENCIMIENTO_FINAL, DM_MAX, FECHA_INGRESO_MC, IMPACTA_MC, SALDO_MC, GASTO_CREDITO, GASTO_CLIENTE, ID_ACCION, ACCION, ESTADO_CREDITO, EstadoReproReactiva, CREDITOS
		FROM BPE.cob.vw_EFECTIVIDAD_DIARIA
		WHERE
			FECHA = @FechaSaldos

		--------------------------------------------------------
		-- ACTUALIZAMOS columna "Impacta_MC" en la Asignación --
		--------------------------------------------------------
		/* -- Deshabilitado 2025.01.30
		UPDATE X
		SET X.Impacta_MC = Ef.IMPACTA_MC
		FROM BPE.cob.Excel_ReporteDiario_Kobsa X
		INNER JOIN BPE.cob.Excel_EfectividadDiaria Ef On X.Cod_Credito = Ef.COD_CREDITO */
			
		-------------------
		-- GUARDAMOS LOG --
		-------------------

		IF ( SELECT Count(*) FROM BPE.cob.BASE_EFECTIVIDAD_DIARIA WHERE FECHA = @FechaSaldos ) > 0
		BEGIN
			EXEC dbo.sp_Sistema_Actualizar_Proceso @id_Proceso, @FechaProceso
			EXEC dbo.sp_Sistema_Registrar_Log @id_Proceso, 0, '', @FechaProceso
		END

		---------------------------
		-- ELIMINAMOS TEMPORALES --
		---------------------------

		IF OBJECT_ID('cob.CobranzaEfectividad_Base') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Base
		IF OBJECT_ID('cob.CobranzaEfectividad_Saldos') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Saldos
		IF OBJECT_ID('cob.CobranzaEfectividad_Consolidado') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Consolidado
		IF OBJECT_ID('cob.CobranzaEfectividad_Pagos') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Pagos
		IF OBJECT_ID('cob.CobranzaEfectividad_Cuotas') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Cuotas
		IF OBJECT_ID('cob.CobranzaEfectividad_Dm_Max') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Dm_Max
		IF OBJECT_ID('cob.CobranzaEfectividad_Prepagos') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Prepagos
		IF OBJECT_ID('cob.CobranzaEfectividad_Provisiones') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Provisiones
		IF OBJECT_ID('cob.CobranzaEfectividad_MarcaAtraso') Is Not NULL DROP TABLE cob.CobranzaEfectividad_MarcaAtraso
		IF OBJECT_ID('cob.CobranzaEfectividad_Moneda') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Moneda
		IF OBJECT_ID('cob.CobranzaEfectividad_SaldoCierre') Is Not NULL DROP TABLE cob.CobranzaEfectividad_SaldoCierre
		IF OBJECT_ID('cob.CobranzaEfectividad_MarcaCliente') Is Not NULL DROP TABLE cob.CobranzaEfectividad_MarcaCliente
		IF OBJECT_ID('cob.CobranzaEfectividad_CIMA_2') Is Not NULL DROP TABLE cob.CobranzaEfectividad_CIMA_2
		IF OBJECT_ID('cob.CobranzaEfectividad_Reactiva') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Reactiva
		IF OBJECT_ID('cob.CobranzaEfectividad_MarcaCliente_2') Is Not NULL DROP TABLE cob.CobranzaEfectividad_MarcaCliente_2
		IF OBJECT_ID('cob.CobranzaEfectividad_UniversoCIMA') Is Not NULL DROP TABLE cob.CobranzaEfectividad_UniversoCIMA
		IF OBJECT_ID('cob.CobranzaEfectividad_UniversoSoloReactiva') Is Not NULL DROP TABLE cob.CobranzaEfectividad_UniversoSoloReactiva
		IF OBJECT_ID('cob.CobranzaEfectividad_Cli_Reg_Comparte_Reactiva') Is Not NULL DROP TABLE cob.CobranzaEfectividad_Cli_Reg_Comparte_Reactiva

	END

END

