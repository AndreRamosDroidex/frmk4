SELECT
    LTRIM(RTRIM(Cob.Cod_Credito)) AS Cod_Credito,
    CAST(LTRIM(RTRIM(Cob.NUM_CUOTA)) AS INT) AS NumCuota,
    Cob.Fecha_Vencimiento AS FechaVencimiento,
    ROUND(Cob.TASA_IGV, 2) AS TasaInteres,
    Cob.Saldo_Principal AS MontoPrincipal,
    ROUND(Cob.Importe_Interes, 2) AS MontoInteres,
    0.00 AS MontoComision, /* Sin fuente en COBIS */
    ROUND(Cob.Importe_Seg_Desgr, 2) AS MontoSeguroDesgravamen,
    Cob.Importe_Seg_Bien AS MontoSeguroBien,
    Cob.Importe_Seg_Multiriesgo AS MontoSeguroIncendio, /* Mapeo confirmado */
    Cob.Deuda_Total_Cuota AS MontoCuota,
    EstCob.EstadoCuota,
    Cob.Fecha_Pago AS FechaPago,
    Da.DiasAtraso
    /* 'COBIS' AS Fuente */
FROM BPE.DBO.Cobis_Cronogramas Cob

CROSS APPLY
(
    SELECT
        CASE
            WHEN DATEDIFF(
                    DAY,
                    Cob.Fecha_Vencimiento,
                    ISNULL(Cob.Fecha_Pago, GETDATE())
                 ) <= 0
                THEN 0
            ELSE DATEDIFF(
                    DAY,
                    Cob.Fecha_Vencimiento,
                    ISNULL(Cob.Fecha_Pago, GETDATE())
                 )
        END
) AS Da (DiasAtraso)

CROSS APPLY
(
    SELECT
        CASE
            WHEN Cob.DESC_ESTADO_CUOTA = 'VIGENTE'
                THEN 'Vigente'

            WHEN Cob.DESC_ESTADO_CUOTA = 'VENCIDO'
                THEN 'Vencido'

            WHEN Cob.DESC_ESTADO_CUOTA = 'CANCELADO'
                THEN 'Cancelado'

            WHEN Cob.DESC_ESTADO_CUOTA = 'PAGO ANTICIPADO'
                THEN 'Cancelado'

            WHEN Cob.DESC_ESTADO_CUOTA = 'NO VIGENTE'
                THEN 'Pendiente' /* Cuotas futuras no vencidas */

            ELSE Cob.DESC_ESTADO_CUOTA /* Pass-through para estados desconocidos */
        END
) AS EstCob (EstadoCuota)

WHERE Cob.COD_MES =
(
    SELECT MAX(c2.COD_MES)
    FROM BPE.DBO.Cobis_Cronogramas c2
);
