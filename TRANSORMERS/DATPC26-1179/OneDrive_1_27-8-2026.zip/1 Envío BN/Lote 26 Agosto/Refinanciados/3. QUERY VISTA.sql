CREATE VIEW [dbo].[vw_Refinanciados] As
SELECT
	Mes,
	Cod_Unico,
	Cod_CreditoRefinanciado,
	ProductoRefinanciado,
	Cod_Credito,
	Producto,
	FechaDesembolso,
	CantidadRef,
	--MesAnterior,
	Saldo_MesAnterior,
	Participacion,
	Cod_CreditoGastos,
	Flag_Vigente,
	Flag_Agil
FROM dbo.Refinanciados
