USE [BPE]
GO

/****** Object:  View [dbo].[vw_Cosechas_Detalle]    Script Date: 23/08/2026 23:08:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ============================
-- VISTA 1 
-- ============================

CREATE VIEW [dbo].[vw_Cosechas_Detalle] As
SELECT
	Dt.MesDesembolso,
	Dt.Flag_Disposicion,
	Dt.Cod_Unico,
	Dt.Cod_Sbs,
	Dt.Cod_Solicitud,
	Dt.Cod_CreditoOrigen,
	Dt.Producto,
	Dt.MontoDesembolso,
	Dt.Flag_Reactiva,
	Dt.Flag_FondoCrecer,
	Dt.Flag_TasaCero,
	
	Det.MesOrden,
	Det.Mes,
	--Det.Cod_Solicitud,
	Det.Cod_CreditoOrigen_Padre,
	Det.Cod_CreditoOrigen As Cod_CreditoOrigen_Hijo,
	Det.Cod_CreditoRastreo,
	Det.Participacion,
	Det.Vig,
	Det.Ven,
	Det.Jud,
	Det.Castigo,
	Det.Gasto,
	Det.Flag_Def30,
	Det.Flag_Def60,
	Det.Flag_Def90,
	Det.Flag_Vencido

FROM dbo.Cosechas_Datos Dt
INNER JOIN dbo.Cosechas_Detalle Det On Dt.Cod_Solicitud = Det.Cod_Solicitud

-- ============================
-- VISTA 2
-- ============================


CREATE VIEW [dbo].[vw_Cosechas_TI_30D] As
SELECT
	Dt.MesDesembolso,
	Dt.Flag_Disposicion,
	Dt.Cod_Unico,
	Dt.Cod_Sbs,
	Dt.Cod_Solicitud,
	Dt.Cod_CreditoOrigen,
	Dt.Producto,
	Dt.MontoDesembolso,
	Dt.Flag_Reactiva,
	Dt.Flag_FondoCrecer,
	Dt.Flag_TasaCero,
	Def_0, Saldo_0, Def_1, Saldo_1, Def_2, Saldo_2, Def_3, Saldo_3, Def_4, Saldo_4, Def_5, Saldo_5, Def_6, Saldo_6, Def_7, Saldo_7, Def_8, Saldo_8, Def_9, Saldo_9,
	Def_10, Saldo_10, Def_11, Saldo_11, Def_12, Saldo_12, Def_13, Saldo_13, Def_14, Saldo_14, Def_15, Saldo_15, Def_16, Saldo_16, Def_17, Saldo_17, Def_18, Saldo_18, Def_19, Saldo_19,
	Def_20, Saldo_20, Def_21, Saldo_21, Def_22, Saldo_22, Def_23, Saldo_23, Def_24, Saldo_24, Def_25, Saldo_25, Def_26, Saldo_26, Def_27, Saldo_27, Def_28, Saldo_28, Def_29, Saldo_29,
	Def_30, Saldo_30, Def_31, Saldo_31, Def_32, Saldo_32, Def_33, Saldo_33, Def_34, Saldo_34, Def_35, Saldo_35, Def_36, Saldo_36, Def_37, Saldo_37, Def_38, Saldo_38, Def_39, Saldo_39,
	Def_40, Saldo_40, Def_41, Saldo_41, Def_42, Saldo_42, Def_43, Saldo_43, Def_44, Saldo_44, Def_45, Saldo_45, Def_46, Saldo_46, Def_47, Saldo_47, Def_48, Saldo_48
FROM dbo.Cosechas_Datos Dt
INNER JOIN dbo.Cosechas_Def30 Df On Dt.Cod_Solicitud = Df.Cod_Solicitud

-- ============================
-- VISTA 3
-- ============================


CREATE VIEW [dbo].[vw_Cosechas_TI_60D] As
SELECT
	Dt.MesDesembolso,
	Dt.Flag_Disposicion,
	Dt.Cod_Unico,
	Dt.Cod_Sbs,
	Dt.Cod_Solicitud,
	Dt.Cod_CreditoOrigen,
	Dt.Producto,
	Dt.MontoDesembolso,
	Dt.Flag_Reactiva,
	Dt.Flag_FondoCrecer,
	Dt.Flag_TasaCero,
	Def_0, Saldo_0, Def_1, Saldo_1, Def_2, Saldo_2, Def_3, Saldo_3, Def_4, Saldo_4, Def_5, Saldo_5, Def_6, Saldo_6, Def_7, Saldo_7, Def_8, Saldo_8, Def_9, Saldo_9,
	Def_10, Saldo_10, Def_11, Saldo_11, Def_12, Saldo_12, Def_13, Saldo_13, Def_14, Saldo_14, Def_15, Saldo_15, Def_16, Saldo_16, Def_17, Saldo_17, Def_18, Saldo_18, Def_19, Saldo_19,
	Def_20, Saldo_20, Def_21, Saldo_21, Def_22, Saldo_22, Def_23, Saldo_23, Def_24, Saldo_24, Def_25, Saldo_25, Def_26, Saldo_26, Def_27, Saldo_27, Def_28, Saldo_28, Def_29, Saldo_29,
	Def_30, Saldo_30, Def_31, Saldo_31, Def_32, Saldo_32, Def_33, Saldo_33, Def_34, Saldo_34, Def_35, Saldo_35, Def_36, Saldo_36, Def_37, Saldo_37, Def_38, Saldo_38, Def_39, Saldo_39,
	Def_40, Saldo_40, Def_41, Saldo_41, Def_42, Saldo_42, Def_43, Saldo_43, Def_44, Saldo_44, Def_45, Saldo_45, Def_46, Saldo_46, Def_47, Saldo_47, Def_48, Saldo_48
FROM dbo.Cosechas_Datos Dt
INNER JOIN dbo.Cosechas_Def60 Df On Dt.Cod_Solicitud = Df.Cod_Solicitud



-- ============================
-- VISTA 4
-- ============================

CREATE VIEW [dbo].[vw_Cosechas_TI_90D] As
SELECT
	Dt.MesDesembolso,
	Dt.Flag_Disposicion,
	Dt.Cod_Unico,
	Dt.Cod_Sbs,
	Dt.Cod_Solicitud,
	Dt.Cod_CreditoOrigen,
	Dt.Producto,
	Dt.MontoDesembolso,
	Dt.Flag_Reactiva,
	Dt.Flag_FondoCrecer,
	Dt.Flag_TasaCero,
	Def_0, Saldo_0, Def_1, Saldo_1, Def_2, Saldo_2, Def_3, Saldo_3, Def_4, Saldo_4, Def_5, Saldo_5, Def_6, Saldo_6, Def_7, Saldo_7, Def_8, Saldo_8, Def_9, Saldo_9,
	Def_10, Saldo_10, Def_11, Saldo_11, Def_12, Saldo_12, Def_13, Saldo_13, Def_14, Saldo_14, Def_15, Saldo_15, Def_16, Saldo_16, Def_17, Saldo_17, Def_18, Saldo_18, Def_19, Saldo_19,
	Def_20, Saldo_20, Def_21, Saldo_21, Def_22, Saldo_22, Def_23, Saldo_23, Def_24, Saldo_24, Def_25, Saldo_25, Def_26, Saldo_26, Def_27, Saldo_27, Def_28, Saldo_28, Def_29, Saldo_29,
	Def_30, Saldo_30, Def_31, Saldo_31, Def_32, Saldo_32, Def_33, Saldo_33, Def_34, Saldo_34, Def_35, Saldo_35, Def_36, Saldo_36, Def_37, Saldo_37, Def_38, Saldo_38, Def_39, Saldo_39,
	Def_40, Saldo_40, Def_41, Saldo_41, Def_42, Saldo_42, Def_43, Saldo_43, Def_44, Saldo_44, Def_45, Saldo_45, Def_46, Saldo_46, Def_47, Saldo_47, Def_48, Saldo_48
FROM dbo.Cosechas_Datos Dt
INNER JOIN dbo.Cosechas_Def90 Df On Dt.Cod_Solicitud = Df.Cod_Solicitud

-- ============================
-- VISTA 5
-- ============================

CREATE VIEW [dbo].[vw_Cosechas_Vencidos] As
SELECT
	Dt.MesDesembolso,
	Dt.Flag_Disposicion,
	Dt.Cod_Unico,
	Dt.Cod_Sbs,
	Dt.Cod_Solicitud,
	Dt.Cod_CreditoOrigen,
	Dt.Producto,
	Dt.MontoDesembolso,
	Dt.Flag_Reactiva,
	Dt.Flag_FondoCrecer,
	Dt.Flag_TasaCero,
	Ven_0, Saldo_0, Ven_1, Saldo_1, Ven_2, Saldo_2, Ven_3, Saldo_3, Ven_4, Saldo_4, Ven_5, Saldo_5, Ven_6, Saldo_6, Ven_7, Saldo_7, Ven_8, Saldo_8, Ven_9, Saldo_9,
	Ven_10, Saldo_10, Ven_11, Saldo_11, Ven_12, Saldo_12, Ven_13, Saldo_13, Ven_14, Saldo_14, Ven_15, Saldo_15, Ven_16, Saldo_16, Ven_17, Saldo_17, Ven_18, Saldo_18, Ven_19, Saldo_19,
	Ven_20, Saldo_20, Ven_21, Saldo_21, Ven_22, Saldo_22, Ven_23, Saldo_23, Ven_24, Saldo_24, Ven_25, Saldo_25, Ven_26, Saldo_26, Ven_27, Saldo_27, Ven_28, Saldo_28, Ven_29, Saldo_29,
	Ven_30, Saldo_30, Ven_31, Saldo_31, Ven_32, Saldo_32, Ven_33, Saldo_33, Ven_34, Saldo_34, Ven_35, Saldo_35, Ven_36, Saldo_36, Ven_37, Saldo_37, Ven_38, Saldo_38, Ven_39, Saldo_39,
	Ven_40, Saldo_40, Ven_41, Saldo_41, Ven_42, Saldo_42, Ven_43, Saldo_43, Ven_44, Saldo_44, Ven_45, Saldo_45, Ven_46, Saldo_46, Ven_47, Saldo_47, Ven_48, Saldo_48,
	Gasto_0, Gasto_1, Gasto_2, Gasto_3, Gasto_4, Gasto_5, Gasto_6, Gasto_7, Gasto_8, Gasto_9,
	Gasto_10, Gasto_11, Gasto_12, Gasto_13, Gasto_14, Gasto_15, Gasto_16, Gasto_17, Gasto_18, Gasto_19,
	Gasto_20, Gasto_21, Gasto_22, Gasto_23, Gasto_24, Gasto_25, Gasto_26, Gasto_27, Gasto_28, Gasto_29,
	Gasto_30, Gasto_31, Gasto_32, Gasto_33, Gasto_34, Gasto_35, Gasto_36, Gasto_37, Gasto_38, Gasto_39,
	Gasto_40, Gasto_41, Gasto_42, Gasto_43, Gasto_44, Gasto_45, Gasto_46, Gasto_47, Gasto_48
	
FROM dbo.Cosechas_Datos Dt
INNER JOIN dbo.Cosechas_Vencidos Df On Dt.Cod_Solicitud = Df.Cod_Solicitud


GO


