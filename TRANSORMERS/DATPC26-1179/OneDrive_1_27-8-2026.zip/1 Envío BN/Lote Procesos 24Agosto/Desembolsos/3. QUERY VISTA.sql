USE [BPE]
GO

/****** Object:  View [dbo].[vw_DESEMBOLSOS]    Script Date: 23/08/2026 22:35:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =====================
-- PARA GOBIERNO AWS:
-- FUENTES DEL PROCESO:

-- BASES ESTATICAS, PODEMOS PROVEER EL CATALOGO
-- dbo.Catalogo_GirosBpe -> T_MST_GIROS_BPE
-- dbo.Catalogo_SectoresEconomicosInternos -> T_MST_SECT_ECON_INT_BPE
-- dbo.Catalogo_SectoresEconomicosInternos -> T_MST_SECT_ECON_INT_BPE


-- =====================



CREATE VIEW [dbo].[vw_DESEMBOLSOS] As
SELECT
	Ds.Codmes,
	Ds.Zonal, 
	Ds.Jefe_Zonal, 
	Ds.Centro, 
	Ds.Cod_Tienda,
	Ds.Codunicocli, Ds.Cliente, Ds.Cod_solicitud, Ds.NROPROD_X, Ds.Producto_Recod, 
	Ds.Segmento, Ds.Grupo_segmento, Ds.Monto_Desembolso,
	Ds.Analistanivel1, Ds.Analistanivelmax, 
	Ds.Cod_Ejecutivo_Inicial,
	Cat.Usuario as Ejecutivo_Inicial,
	Ds.Fecha_Desembolso, Ds.Campana, Ds.Tipo_Cliente, Ds.Fecha_Solicitud,
	Ds.Canal,
	Ds.Cod_Giro,
	G.Giro,
	G.Sector,
	Sei.SectorEconomicoInterno,
	Ds.Tasa, Ds.Plazo
FROM dbo.DESEMBOLSOS Ds
LEFT JOIN dbo.Catalogo_GirosBpe G On Ds.Cod_Giro = G.Cod_Giro
LEFT JOIN dbo.Catalogo_SectoresEconomicosInternos Sei On G.Cod_SectorEconomicoInterno = Sei.Cod_SectorEconomicoInterno
LEFT JOIN dbo.Catalogo_Usuarios Cat on Cat.Cod_Usuario = Ds.Cod_Ejecutivo_Inicial






GO


