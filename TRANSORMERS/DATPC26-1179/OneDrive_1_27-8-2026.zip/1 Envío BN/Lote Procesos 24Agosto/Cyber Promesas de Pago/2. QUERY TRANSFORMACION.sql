USE [BPE_Procesamientos]
GO
/****** Object:  StoredProcedure [dbo].[sp_PromesasDePago_ProcesarDatos]    Script Date: 21/08/2026 11:21:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ========================================================
-- Autor		:	GABRIELA URQUIZO AYALA
-- Creación		:	12/03/2025
-- Modificación	:	12/03/2025
-- Descripción	:	Carga de Promesas de Pago de Cyber 
-- EXEC dbo.sp_PromesasDePago_ProcesarDatos
-- 2025.04.04 Se añade campo de Fecha Fin (Fin Promesa), y Flag Ultima Gestión
-- ========================================================
ALTER PROCEDURE [dbo].[sp_PromesasDePago_ProcesarDatos] 
AS
BEGIN


	DECLARE
		@FechaActual	DATE,
		@FechaProceso	VARCHAR(8),
		@FechaCarga		DATE,
		@id_Proceso		INT,
		@Flag_DiaHabil	BIT,
		@Es_Lunes		SMALLINT,
		@Fecha_D_2		DATE 

	SET @FechaActual	= GETDATE() 
	SET @FechaProceso	= Convert(VARCHAR(8),@FechaActual,112)
	SET @Flag_DiaHabil	= (SELECT Flag_dia_habil FROM BPE.dbo.vw_Calendario WHERE Fecha = Convert(DATE,@FechaActual) ) 
	SET @FechaCarga		= (SELECT MAX(FECHA_CARGA) FROM BPE_Procesamientos.cob.Base_PromesasDePago_Carga)
	SET @id_Proceso		= 99 -- COB Promesas de Pago
	SET @Es_Lunes		= (SELECT CASE WHEN DIA_SEMANA = 1 THEN 1 ELSE 0 END FROM BPE.dbo.vw_Calendario WHERE Fecha = @FechaActual)
	SET @Fecha_D_2		= (SELECT DATEADD(DAY, -2, @FechaActual))
	print @FechaActual

	-- Validación para ejecutar el proceso: 
	IF ( @Flag_DiaHabil = 1 and			 --> El proceso solo se ejecuta en días hábiles
		  @FechaCarga = @FechaActual 
		  OR --> La data es del día
		   ( @Es_Lunes = 1 AND -- Si es Lunes , la FechaCarga del Input debe ser del sábado
		     @FechaCarga = @Fecha_D_2)
		 ) 	
	BEGIN 

	--IF OBJECT_ID('BPE_Procesamientos.cob.PdP_UltimaGestion') Is Not NULL DROP TABLE BPE_Procesamientos.cob.PdP_UltimaGestion
	--CREATE TABLE BPE_Procesamientos.cob.PdP_UltimaGestion (Periodo varchar(6),Fecha_Carga date,Cod_Credito varchar(10),Fecha_Gestion datetime) 

		--=======================================
		-- Periodo
		--=======================================
		UPDATE  BPE_Procesamientos.cob.Base_PromesasDePago_Carga
		SET Periodo = convert(varchar(6),Fecha_Carga,112)

		--=======================================
		-- Cod_Credito
		--=======================================
		UPDATE  BPE_Procesamientos.cob.Base_PromesasDePago_Carga
		SET Cod_Credito = BPE.DBO.fn_cad_FormatoCodigo(SUBSTRING(CUENTA_CYBER,1,8))

		--=======================================
		-- Flag Ultima Gestión 
		--=======================================
		UPDATE C
		SET	C.Flag_UltimaGestion = 1 
		FROM BPE_Procesamientos.cob.Base_PromesasDePago_Carga C 
		INNER JOIN (
			SELECT Cod_Credito, Fecha_Gestion, ROW_NUMBER() OVER (PARTITION BY COD_CREDITO ORDER BY Fecha_Gestion desc )ITEM
			FROM BPE_Procesamientos.cob.Base_PromesasDePago_Carga
			 ) X ON X.Cod_Credito = C.Cod_Credito AND
					X.Fecha_Gestion = C.Fecha_Gestion AND 
					X.ITEM = 1 
		 
		UPDATE BPE_Procesamientos.cob.Base_PromesasDePago_Carga
		SET Flag_UltimaGestion = 0 WHERE Flag_UltimaGestion IS NULL 
		
		--=======================================
		-- Fecha Ultima Gestión 
		--=======================================
		/*
		INSERT INTO BPE_Procesamientos.cob.PdP_UltimaGestion (Periodo, Fecha_Carga, Cod_Credito, Fecha_Gestion)
		SELECT	Periodo,
				Fecha_Carga,
				Cod_Credito,
				MAX(Fecha_Gestion)Fecha_Gestion
		FROM	BPE_Procesamientos.cob.Base_PromesasDePago_Carga
		--WHERE	COD_CREDITO = '0010262833'
		GROUP BY Periodo,
				Fecha_Carga,
				Cod_Credito
		*/

		--=======================================
		-- Inserción a la base Oficial
		--=======================================
		--DELETE FROM BPE.cob.Base_PromesasDePago WHERE Fecha_Carga = @FechaActual
		TRUNCATE TABLE BPE.cob.Base_PromesasDePago 

		INSERT INTO BPE.cob.Base_PromesasDePago (Periodo, Fecha_Carga, Cod_Credito, PdP_Estado, PdP_Fecha_Gestion, PdP_Monto, Pdp_CodigoGestor, PdP_Fecha_Fin, Flag_UltimaGestion)
		SELECT	C.Periodo,
				@FechaActual Fecha_Carga,
				C.Cod_Credito, 
				C.Estado_PdP,
				C.Fecha_Gestion,
				C.Monto_Pdp,
				C.CodigoGestor,
				C.Fecha_Fin, 
				C.Flag_UltimaGestion
		FROM	BPE_Procesamientos.cob.Base_PromesasDePago_Carga C
		------INNER JOIN BPE_Procesamientos.cob.PdP_UltimaGestion U ON U.Cod_Credito = C.Cod_Credito and U.Fecha_Gestion = C.Fecha_Gestion
		
		-- =======================================
		-- Registro en Log de Ejecuciones
		-- =======================================
		IF ( SELECT Count(*) FROM BPE.cob.Base_PromesasDePago WHERE Fecha_Carga = @FechaActual) > 0 
			
		BEGIN
			EXEC dbo.sp_Sistema_Actualizar_Proceso	@id_Proceso, @FechaProceso			--> Actualiza la Fecha correspondiente al Último Proceso (Fecha Saldos) : SELECT * FROM dbo.Sistema_Procesos WHERE ID_PROCESO = 84
			EXEC dbo.sp_Sistema_Registrar_Log		@id_Proceso, 0, '', @FechaProceso	--> Inserta un registro por cada ejecución en el Log de Ejecuciones: SELECT * FROM dbo.Sistema_Log WHERE ID_PROCESO = 84
		END

		--SELECT * FROM dbo.Sistema_Procesos where id_proceso >= 90
		--INSERT INTO dbo.Sistema_Procesos (PROCESO, TipoProceso, FechaUltimoProceso, Flag_RegistroActivo) VALUES ('COB Promesas de Pago','Diario','2025-02-11',1)


		--=======================================
		-- Limpieza de Temporales
		--=======================================
		TRUNCATE TABLE BPE_Procesamientos.cob.Base_PromesasDePago_Carga

		

	END 

END