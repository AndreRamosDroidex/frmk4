USE [BPE_Procesamientos]
GO
/****** Object:  StoredProcedure [cob].[sp_Cobranzas_Carga_GestionesCyber_ProcesarDatos]    Script Date: 21/08/2026 15:28:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [cob].[sp_Cobranzas_Carga_GestionesCyber_ProcesarDatos]
AS
BEGIN


	UPDATE  C
	SET		C.Codigo_Resultado_Label = P.Descripcion_Resultado
	FROM	BPE_Procesamientos.COB.Base_Cyber_Gestion_Mensual C
	INNER JOIN BPE.cob.COB_CYBER_CTG_ACCION_RESULTADO_PESOS P ON P.Codigo_resultado = C.Codigo_resultado

	UPDATE  C
	SET		C.Codigo_Accion_Label = P.Descripcion_Accion
	FROM	BPE_Procesamientos.COB.Base_Cyber_Gestion_Mensual C
	INNER JOIN BPE.cob.COB_CYBER_CTG_ACCION_RESULTADO_PESOS P ON P.CODIGO_ACCION = C.CODIGO_ACCION

	UPDATE  C
	SET		C.Contactabilidad = P.TIPO_RESULTADO
	FROM	BPE_Procesamientos.COB.Base_Cyber_Gestion_Mensual C
	INNER JOIN BPE.cob.COB_CYBER_CTG_ACCION_RESULTADO_PESOS P ON 
		P.CODIGO_RESULTADO = C.CODIGO_RESULTADO AND 
		P.CODIGO_ACCION = C.CODIGO_ACCION


	-- Insertar en Tabla Final
	--INSERT INTO BPE.COB.Base_Cyber_Gestion_Mensual 
	--SELECT * FROM BPE_Procesamientos.COB.Base_Cyber_Gestion_Mensual
	--
	---- Limpieza de tabla Intermedia
	--TRUNCATE TABLE BPE_Procesamientos.COB.Base_Cyber_Gestion_Mensual

	
	/*
	SELECT DISTINCT CODIGO_accion, CODIGO_ACCION_LABEL, Codigo_resultado FROM BPE.cob.Base_Cyber_Gestion_Mensual WHERE CODIGO_accion= 'LM'

	UPDATE  C
	SET		C.Codigo_Accion_Label = P.Descripcion_Accion
	FROM	BPE.cob.Base_Cyber_Gestion_Mensual C
	INNER JOIN BPE.cob.COB_CYBER_CTG_ACCION_RESULTADO_PESOS P ON P.CODIGO_ACCION = C.CODIGO_ACCION
	*/
	
	/*
	SELECT CODIGO_ACCION, COUNT(*)Q
	FROM (SELECT DISTINCT CODIGO_ACCION, Descripcion_Accion FROM BPE.cob.COB_CYBER_CTG_ACCION_RESULTADO_PESOS )X GROUP BY CODIGO_ACCION HAVING COUNT(*)>1

	SELECT DISTINCT CODIGO_ACCION, Descripcion_Accion FROM BPE.cob.COB_CYBER_CTG_ACCION_RESULTADO_PESOS WHERE DESCRIPCION_ACCION LIKE '%DEMAN%'
	SELECT DISTINCT CODIGO_ACCION, Descripcion_Accion, CODIGO_RESULTADO, DESCRIPCION_RESULTADO FROM BPE.cob.COB_CYBER_CTG_ACCION_RESULTADO_PESOS WHERE CODIGO_ACCION = 'IN'

	SELECT * FROM BPE.cob.Base_Cyber_Gestion_Mensual WHERE CODIGO_ACCION = 'IN' 
	*/
END