
--TERADATA
-- ========================================
-- Promesas de Pago
-- ========================================
SELECT  
	PERIODO, 
	fecha_carga, 
	CUENTA_CYBER, 
	ESTADO_PDP, 
	FECHA_GESTION, 
	MONTO_PDP, 
	CODIGO_GESTOR , 
	FECHA_PDP
FROM 	e_dw_views.v_cob_cyber_pdp /* e_perm_aws.t_cob_cyber_pdp */
WHERE 	fecha_carga >= DATE -1 AND
	(cuenta_cyber LIKE '%BPE%' OR  cuenta_cyber LIKE '%CCD%')
