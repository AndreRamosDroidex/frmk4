-- Ambiente: Teradata
SELECT
	Cl.COD_UNICO_VAL CodUnico,
	Ant.COD_OPERACION_ACTIVA_VAL As CodOperacionActivaAnt,
	SPAnt.NOMBRE_SUBPRODUCTO_FINANCIERO_VAL As NombreSubproductoFinancieroAnt,
	Act.COD_OPERACION_ACTIVA_VAL As CodOperacionActivaAct,
	SPAct.NOMBRE_SUBPRODUCTO_FINANCIERO_VAL As NombreSubproductoFinancieroAct,
	Cam.DESCRIPCION_VAL As Campana,
	CrEs.FechaDesembolso
FROM E_DW_VIEWS.V_REL_VPC_MYP_CREDREUTIL Reu /* e_perm_aws.t_rel_vpc_myp_credreutil */
INNER JOIN (
	SELECT  CREDITO_ID,
			CAST(FECHA_DT AS DATE) FechaDesembolso, 
			Row_Number() OVER( PARTITION BY CREDITO_ID ORDER BY FECHA_DT DESC ) As Item
	FROM E_DW_VIEWS.V_REL_VPC_MYP_CREDESTADO /*e_perm_aws.t_rel_vpc_myp_credestado*/
	WHERE ESTADO_VAL = 'V' And COD_USUARIO_VAL <> 'dbo'
) CrEs On Reu.CREDITO_ID = CrEs.CREDITO_ID And CrEs.Item = 1 
INNER JOIN E_DW_VIEWS.V_REL_VPC_MYP_CREDCLIENTE CrCl /*e_perm_aws.t_rel_vpc_myp_credcliente */ On Reu.CREDITO_ID = CrCl.CREDITO_ID And CrCl.RELACION_ID = 1
INNER JOIN E_DW_VIEWS.V_MST_VPC_MYP_CLIENTE Cl /*e_perm_aws.t_mst_vpc_myp_cliente_actual*/ On CrCl.CLIENTE_ID = Cl.CLIENTE_ID
INNER JOIN E_DW_VIEWS.V_REL_VPC_MYP_CRED Ant /*e_perm_aws.t_rel_vpc_myp_cred*/ On Reu.CREDITO_ANTERIOR_ID = Ant.CREDITO_ID
INNER JOIN E_DW_VIEWS.V_REL_VPC_MYP_CRED Act On Reu.CREDITO_ID = Act.CREDITO_ID
INNER JOIN E_DW_VIEWS.V_MST_VPC_MYP_SUBPROD_FINAN SPAnt /* e_perm_aws.t_mst_vpc_myp_subprod_finan */ On Ant.COD_PRODUCTO_VAL = SPAnt.PRODUCTO_FINANCIERO_ACTIVO_ID And Ant.COD_SUBPRODUCTO_VAL = SPAnt.PRODUCTO_FINANCIERO_PASIVO_ID
INNER JOIN E_DW_VIEWS.V_MST_VPC_MYP_SUBPROD_FINAN SPAct On Act.COD_PRODUCTO_VAL = SPAct.PRODUCTO_FINANCIERO_ACTIVO_ID And Act.COD_SUBPRODUCTO_VAL = SPAct.PRODUCTO_FINANCIERO_PASIVO_ID
LEFT JOIN  E_DW_VIEWS.V_MST_VPC_MYP_CAMPANA Cam /*e_perm_aws.t_mst_vpc_myp_campana*/ On Act.COD_CAMPANA_VAL = Cam.CAMPANA_ID
WHERE
	TO_CHAR(CrEs.FechaDesembolso,'YYYYMM') >= TO_CHAR( (current_date - Interval '1' month) ,'YYYYMM')
	And NVL(Act.COD_OPERACION_ACTIVA_VAL,'') <> ''
	And ( SPAct.NOMBRE_SUBPRODUCTO_FINANCIERO_VAL Like '%REFINANCIADO%' Or SPAct.NOMBRE_SUBPRODUCTO_FINANCIERO_VAL Like '%REPRO%' Or Cam.DESCRIPCION_VAL Like '%REPRO%' )
;


-- Ambiente: Sandbox 
-- Procesamiento Operaciones Agiles 
	DECLARE
		@FechaActual DATE,
		@FechaAnterior DATE,
		@MesActual NUMERIC(6),
		@MesAnterior NUMERIC(6),
		@Query VARCHAR(1000)

	SET @FechaActual = ( SELECT DISTINCT AS_OF_DATE FROM BPE.dbo.vw_SaldosDiario ) -- 2026-08-18
	SET @FechaAnterior = ( SELECT TOP (1) FECHA FROM BPE.dbo.vw_CALENDARIO WHERE FECHA < @FechaActual And DIA_BPE <> -1 ORDER BY FECHA DESC ) -- 2026-08-17
	SET @MesActual = ( SELECT Convert(VARCHAR(6),@FechaActual,112) )
	SET @MesAnterior = ( SELECT Convert(VARCHAR(6),@FechaAnterior,112) )

	IF OBJECT_ID('dbo.OperacionesAgiles_Creditos') Is Not NULL DROP TABLE dbo.OperacionesAgiles_Creditos
	IF OBJECT_ID('dbo.OperacionesAgiles_Carga') Is Not NULL DROP TABLE dbo.OperacionesAgiles_Carga

	CREATE TABLE dbo.OperacionesAgiles_Creditos ( FechaCambioProducto DATE, Cod_CreditoOrigen VARCHAR(10), Id_Tipo TINYINT, Prod VARCHAR(35), Subprod VARCHAR(35) )
	CREATE TABLE dbo.OperacionesAgiles_Carga ( FechaCambioProducto DATE, Mes NUMERIC(6), Cod_Unico VARCHAR(10), Cod_CreditoRefinanciado VARCHAR(10), ProductoRefinanciado VARCHAR(50), Cod_Credito VARCHAR(10), Producto VARCHAR(50), FechaDesembolso DATE, CantidadRef SMALLINT, MesAnterior NUMERIC(6), Saldo_MesAnterior FLOAT, Participacion NUMERIC(5,2) )

	SET @Query = '
		INSERT INTO dbo.OperacionesAgiles_Creditos ( FechaCambioProducto, Cod_CreditoOrigen, Id_Tipo, Prod, Subprod )
		SELECT B.AS_OF_DATE As FechaCambioProducto, B.NROPROD_X As Cod_CreditoOrigen, 1 As Id_Tipo, A.PROD, A.SUBPROD
		FROM BPE.dbo.SaldosDiario_'+Convert(VARCHAR(6),@MesAnterior)+' A
		INNER JOIN BPE.dbo.SaldosDiario_'+Convert(VARCHAR(6),@MesActual)+' B
			On A.NROPROD_X = B.NROPROD_X And B.AS_OF_DATE = '+CHAR(39)+Convert(VARCHAR,@FechaActual,112)+CHAR(39)+'
		WHERE
			A.AS_OF_DATE = '+CHAR(39)+Convert(VARCHAR,@FechaAnterior,112)+CHAR(39)+'
			And A.PROD <> '+CHAR(39)+'08 Refinanciados'+CHAR(39)+'
			And B.PROD = '+CHAR(39)+'08 Refinanciados'+CHAR(39)

	EXEC ( @Query )
	
	SET @Query = '
		INSERT INTO dbo.OperacionesAgiles_Creditos ( FechaCambioProducto, Cod_CreditoOrigen, Id_Tipo, Prod, Subprod )
		SELECT B.AS_OF_DATE As FechaCambioProducto, B.NROPROD_X As Cod_CreditoOrigen, 2 As Id_Tipo, A.PROD, A.SUBPROD
		FROM BPE.dbo.SaldosDiario_'+Convert(VARCHAR(6),@MesAnterior)+' A
		INNER JOIN BPE.dbo.SaldosDiario_'+Convert(VARCHAR(6),@MesActual)+' B
			On A.NROPROD_X = B.NROPROD_X And B.AS_OF_DATE = '+CHAR(39)+Convert(VARCHAR,@FechaActual,112)+CHAR(39)+'
		WHERE
			A.AS_OF_DATE = '+CHAR(39)+Convert(VARCHAR,@FechaAnterior,112)+CHAR(39)+'
			And A.SUBPROD <> '+CHAR(39)+'REPROGRAMADO/REPROGRAMADO SBS'+CHAR(39)+'
			And B.SUBPROD = '+CHAR(39)+'REPROGRAMADO/REPROGRAMADO SBS'+CHAR(39)

	EXEC ( @Query )

	INSERT INTO dbo.OperacionesAgiles_Carga ( FechaCambioProducto, Cod_Unico, Cod_CreditoRefinanciado, ProductoRefinanciado, Cod_Credito, Producto, CantidadRef, Participacion )
	SELECT
		Op.FechaCambioProducto,
		ltrim(rTrim(Sol.Cod_Unico)) As Cod_Unico,
		Op.Cod_CreditoOrigen As Cod_CreditoRefinanciado,
		( CASE
			WHEN Op.Subprod = 'REPROGRAMADO/REPROGRAMADO SBS' THEN 'REPROGRAMADO'
			ELSE ltrim(rTrim(Ds.PRODUCTO_Recod))
		END ) As ProductoRefinanciado,
		Op.Cod_CreditoOrigen As Cod_Credito,
		'REFINANCIADO' As Producto,
		1 As CantidadRef,
		1 As Participacion
	FROM dbo.OperacionesAgiles_Creditos Op
	INNER JOIN BPE.dbo.vw_Solicitudes Sol On Op.Cod_CreditoOrigen = Sol.Cod_Credito
	LEFT JOIN BPE.dbo.vw_DESEMBOLSOS Ds On Sol.Cod_Credito = Ds.NROPROD_X
	WHERE
		Op.Id_Tipo = 1

	INSERT INTO dbo.OperacionesAgiles_Carga ( FechaCambioProducto, Cod_Unico, Cod_CreditoRefinanciado, ProductoRefinanciado, Cod_Credito, Producto, CantidadRef, Participacion )
	SELECT
		Op.FechaCambioProducto,
		ltrim(rTrim(Sol.Cod_Unico)) As Cod_Unico,
		Op.Cod_CreditoOrigen As Cod_CreditoRefinanciado,
		ltrim(rTrim(Ds.PRODUCTO_Recod)) As ProductoRefinanciado,
		Op.Cod_CreditoOrigen As Cod_Credito,
		'REPROGRAMADO' As Producto,
		1 As CantidadRef,
		1 As Participacion
	FROM dbo.OperacionesAgiles_Creditos Op
	INNER JOIN BPE.dbo.vw_Solicitudes Sol On Op.Cod_CreditoOrigen = Sol.Cod_Credito
	LEFT JOIN BPE.dbo.vw_DESEMBOLSOS Ds On Sol.Cod_Credito = Ds.NROPROD_X
	WHERE
		Op.Id_Tipo = 2
		And Sol.FechaDesembolso <= DateAdd(Day,-30,Convert(DATE,Getdate())) --Nos aseguramos que no sea un producto Reprogramado regular

	----------------------------------
	-- EXTRAEMOS NUEVAS OPERACIONES --
	----------------------------------
	
	INSERT INTO dbo.OperacionesAgiles ( FechaCambioProducto, Mes, Cod_Unico, Cod_CreditoRefinanciado, ProductoRefinanciado, Cod_Credito, Producto, FechaDesembolso, CantidadRef, MesAnterior, Saldo_MesAnterior, Participacion )
	SELECT
		R.FechaCambioProducto, R.Mes, R.Cod_Unico, R.Cod_CreditoRefinanciado, R.ProductoRefinanciado,
		R.Cod_Credito, R.Producto, R.FechaDesembolso, R.CantidadRef, R.MesAnterior, R.Saldo_MesAnterior, R.Participacion
	FROM dbo.OperacionesAgiles_Carga R
	WHERE Not Exists (
		SELECT 1 FROM dbo.OperacionesAgiles Rf
		WHERE
			R.Cod_CreditoRefinanciado = Rf.Cod_CreditoRefinanciado
	)

	--------------------------------------
	-- ACTUALIZAMOS FECHA DE DESEMBOLSO --
	--------------------------------------
	--Recordar que se actualizaría SOLO los Refinanciados que se les cambió el Producto en t-2 con el Cambio de Fecha realizado t-1
	UPDATE Op
	SET
		Op.Mes = Convert(VARCHAR(6),Cv.FechaCambio,112),
		Op.FechaDesembolso = Cv.FechaCambio
	FROM dbo.OperacionesAgiles Op
	INNER JOIN BPE.dbo.vw_CambiosFecha Cv On Op.Cod_Credito = Cv.Cod_Credito And Cv.FechaCambio = @FechaActual

	/*
	-- Cambios Fecha: Se obtiene de Cronogramas Histórico  
		DECLARE
		@FechaActual DATE,
		@FechaVariacion DATE,
		@MesVariacion NUMERIC(6),
		@FechaInicio_MesVar DATE

	SET @FechaActual = Convert(DATE,Getdate())
	SET @FechaVariacion = ( SELECT TOP (1) Convert(VARCHAR(8),FECHA,112) FROM BPE.dbo.vw_CALENDARIO WHERE FECHA < @FechaActual And FLAG_DIA_HABIL = 1 ORDER BY FECHA DESC )
	SET @MesVariacion = ( SELECT Convert(VARCHAR(6),@FechaVariacion,112) )
	SET @FechaInicio_MesVar = ( SELECT FECHA FROM BPE.dbo.vw_CALENDARIO WHERE CODMES_BPE = @MesVariacion And FLAG_INICIO = 1 )
	
	---------------------------------------------
	-- EXTRAEMOS LAS VARIACIONES DE CRONOGRAMA -- 
	---------------------------------------------
	INSERT INTO dbo.Cronogramas_CuotasPendientes ( Cod_Credito, NumCuota, FechaVencimiento, Cod_EstadoCuota, FechaPago )
	SELECT
		Cod_Credito, NumCuota, FechaVencimiento, Cod_EstadoCuota, FechaPago
	FROM (
		SELECT Cod_Credito, NumCuota, FechaVencimiento, Cod_EstadoCuota, FechaPago, Row_Number() OVER( PARTITION BY Cod_Credito ORDER BY NumCuota ) As ITEM
		FROM dbo.Cronogramas_Carga
		WHERE Cod_EstadoCuota Not In ( 'C', 'G', 'D' ) -- Cancelado o Prepago o Descargado
	) Tmp
	WHERE ITEM = 1


	INSERT INTO dbo.Cronogramas_Variaciones_Carga ( Cod_Credito, NumCuota, FechaVencimiento_Inicial, FechaVencimiento_Final, FechaVariacion, Diferencia )
	SELECT
		Pen.Cod_Credito,
		Pen.NumCuota,
		Cr.FechaVencimiento As FechaInicial,
		Pen.FechaVencimiento As FechaFinal,
		Convert(DATE,@FechaProceso) As FechaVariacion,
		Abs(DateDiff(Day,Pen.FechaVencimiento,Cr.FechaVencimiento)) As Diferencia
	FROM dbo.Cronogramas_CuotasPendientes Pen
	INNER JOIN BPE.dbo.Cronogramas Cr On Pen.Cod_Credito = Cr.Cod_Credito And Pen.NumCuota = Cr.NumCuota
	WHERE
		Pen.FechaVencimiento <> Cr.FechaVencimiento
			
	-- ELIMINAMOS LOS QUE TIENEN 1 DÍA DE DIFERENCIA
	DELETE FROM dbo.Cronogramas_Variaciones_Carga
	WHERE Diferencia = 1

	-- ELIMINAMOS LAS LÍNEAS QUE NO HAN SIDO UTILIZADAS
	DELETE FROM dbo.Cronogramas_Variaciones_Carga
	WHERE Cod_Credito In (
		SELECT Cod_Credito
		FROM dbo.Cronogramas_Carga -- Antes era BPE.dbo.Cronogramas
		WHERE NumCuota = 1 And FechaVencimiento = FechaPago And Cod_EstadoCuota = 'P' -- Vigente
	)

	-- ELIMINAMOS LOS CRÉDITOS QUE SÓLO SE LES AGREGÓ 1 CUOTA PREPAGO Y CORRIÓ EL NÚMERO DE CUOTA
	DELETE
	FROM dbo.Cronogramas_Variaciones_Carga
	WHERE Cod_Credito In (
		SELECT Tmp.Cod_Credito FROM (
			SELECT Cf.Cod_Credito, Cr.NumCuota, Cr.FechaVencimiento
			FROM dbo.Cronogramas_Variaciones_Carga Cf
			INNER JOIN dbo.Cronogramas_Carga Cr On Cf.Cod_Credito = Cr.Cod_Credito And Cf.NumCuota = Cr.NumCuota
			WHERE Cf.Diferencia > 1
		) Tmp
		INNER JOIN BPE.dbo.Cronogramas Cr On Tmp.Cod_Credito = Cr.Cod_Credito And Tmp.NumCuota-1 = Cr.NumCuota And Tmp.FechaVencimiento = Cr.FechaVencimiento
	)

	INSERT INTO dbo.Cronogramas_Variaciones ( Cod_Credito, NumCuota, FechaVencimiento_Inicial, FechaVencimiento_Final, FechaVariacion )
	SELECT Cod_Credito, NumCuota, FechaVencimiento_Inicial, FechaVencimiento_Final, FechaVariacion
	FROM dbo.Cronogramas_Variaciones_Carga

	INSERT INTO dbo.Cronogramas_Variaciones_Bak ( Cod_Credito, NumCuota, FechaVencimiento_Inicial, FechaVencimiento_Final, FechaVariacion )
	SELECT Cod_Credito, NumCuota, FechaVencimiento_Inicial, FechaVencimiento_Final, FechaVariacion
	FROM dbo.Cronogramas_Variaciones_Carga

	TRUNCATE TABLE dbo.Cronogramas_Variaciones_Carga

	---------------------------------------------------------------------------------------------------------------------------------

	TRUNCATE TABLE dbo.CambiosFecha
	INSERT INTO dbo.CambiosFecha ( Cod_Credito, NumCuota, FechaVencimiento_Inicial, FechaVencimiento_Final, FechaCambio, DiasGracia )
	SELECT Cod_Credito, NumCuota, FechaVencimiento_Inicial, FechaVencimiento_Final, FechaVariacion, DateDiff(Day,FechaVencimiento_Inicial, FechaVencimiento_Final) As DiasGracia
	FROM dbo.Cronogramas_Variaciones
	WHERE FechaVariacion = @FechaVariacion
	ORDER BY DateDiff(Day,FechaVencimiento_Inicial, FechaVencimiento_Final)

	UPDATE Cv
	SET Cv.Flag_CF = 1
	FROM dbo.CambiosFecha Cv
	INNER JOIN (
		SELECT Sol.Cod_Credito, Cf.*
		FROM BPE.dbo.CambiosFecha_IBMyp Cf
		INNER JOIN BPE.dbo.vw_Solicitudes Sol On Cf.Cod_Solicitud = Sol.Cod_Solicitud
		WHERE Not Exists ( SELECT 1 FROM BPE.dbo.vw_Base_Reactiva Rea WHERE Cf.Cod_Solicitud = Rea.Cod_Solicitud )
	) Cf On Cv.FechaCambio = Cf.FechaCambio And Cv.Cod_Credito = Cf.Cod_Credito

	UPDATE Cv
	SET Cv.Flag_OG = 1, ComentarioOG = Og.Comentario
	FROM dbo.CambiosFecha Cv
	INNER JOIN (
		SELECT Sol.Cod_Credito, Og.Fecha, Og.Comentario
		FROM BPE.dbo.vw_OtrasGestiones Og
		INNER JOIN BPE.dbo.vw_Solicitudes Sol On Og.Cod_Solicitud = Sol.Cod_Solicitud
		WHERE
			Og.Comentario Like '%LANDIN%'
			Or ( Og.Comentario Like '%CAMBIO%' And Og.Comentario Like '%FECHA%' )
			Or ( Og.Comentario Like '%CAMBIO%' And Og.Comentario Like '%VENCIMIENTO%' )
			Or ( Og.Comentario Like '%CANBIO%' And Og.Comentario Like '%FECHA%' )
			Or ( Og.Comentario Like '%MODIF%' And Og.Comentario Like '%FECHA%' )
			Or ( Og.Comentario Like '%repro%' )
	) Og On Cv.FechaCambio = Og.Fecha And Cv.Cod_Credito = Og.Cod_Credito

	UPDATE Cv
	SET Cv.Flag_OperacionAgil = 1
	FROM dbo.CambiosFecha Cv
	INNER JOIN dbo.OperacionesAgiles Op On Cv.Cod_Credito = Op.Cod_Credito

	INSERT INTO BPE.dbo.CambiosFecha ( FechaCambio, Cod_Solicitud, Cod_Credito, NumCuota, FechaVencimiento_Inicial, FechaVencimiento_Final, Producto, SubProducto, Flag_OperacionAgil, Flag_Reversion, Observaciones, Id_TipoCF )
	SELECT DISTINCT
		Cf.FechaCambio, Sol.Cod_Solicitud, Cf.Cod_Credito, Cf.NumCuota, Cf.FechaVencimiento_Inicial, Cf.FechaVencimiento_Final, Sol.Producto, Sol.SubProducto,
		IsNull(Cf.Flag_OperacionAgil,0) As Flag_OperacionAgil, 0 As Flag_Reversion, '' As Observaciones,
		( CASE
			WHEN Convert(VARCHAR(6),FechaVencimiento_Inicial,112) <= Convert(VARCHAR(6),FechaCambio,112) And Convert(VARCHAR(6),FechaVencimiento_Final,112) > Convert(VARCHAR(6),FechaCambio,112) THEN 1
			WHEN Convert(VARCHAR(6),FechaVencimiento_Final,112) = Convert(VARCHAR(6),FechaCambio,112) THEN 2
			WHEN Convert(VARCHAR(6),FechaVencimiento_Inicial,112) > Convert(VARCHAR(6),FechaCambio,112) And Convert(VARCHAR(6),FechaVencimiento_Final,112) > Convert(VARCHAR(6),FechaCambio,112) THEN 3
			WHEN Convert(VARCHAR(6),FechaVencimiento_Inicial,112) < Convert(VARCHAR(6),FechaCambio,112) And Convert(VARCHAR(6),FechaVencimiento_Final,112) < Convert(VARCHAR(6),FechaCambio,112) THEN 3
		END ) As Id_TipoCF
	FROM dbo.CambiosFecha Cf
	LEFT JOIN BPE.dbo.vw_Solicitudes Sol On Cf.COD_CREDITO = Sol.Cod_Credito
	WHERE
		Cf.FechaCambio >= @FechaInicio_MesVar
		And Cf.Cod_Credito Not In ( SELECT Cod_Credito FROM BPE.dbo.CambiosFecha WHERE Convert(VARCHAR(6),FechaCambio,112) = @MesVariacion )
		And Cf.DiasGracia > 0
	--ORDER BY Cf.FechaCambio, Cf.Cod_Credito

	-------------------------------

	
	*/
	UPDATE dbo.OperacionesAgiles
	SET MesAnterior = BPE.dbo.fn_Fec_Variar_Periodo( Mes ,-1)
	WHERE
		FechaDesembolso Is Not NULL

	UPDATE R
	SET R.Saldo_MesAnterior = A.VIG*Dc.TipoCambio+A.VEN*Dc.TipoCambio+A.JUD*Dc.TipoCambio
	FROM dbo.OperacionesAgiles R
	INNER JOIN BPE.dbo.vw_SaldosCierre A On R.MesAnterior = A.MES And R.Cod_CreditoRefinanciado = A.NROPROD_X
	INNER JOIN BPE.dbo.vw_DatosCierre Dc On A.MES = Dc.Mes
	WHERE
		R.FechaDesembolso Is Not NULL

	----------------------
	-- EXPORTAMOS DATOS --
	----------------------
	INSERT INTO BPE.dbo.Refinanciados ( Mes, Cod_Unico, Cod_CreditoRefinanciado, ProductoRefinanciado, Cod_Credito, Producto, FechaDesembolso, CantidadRef, MesAnterior, Saldo_MesAnterior, Participacion, Flag_Vigente, Flag_Agil )
	SELECT
		R.Mes, R.Cod_Unico, R.Cod_CreditoRefinanciado, R.ProductoRefinanciado,
		R.Cod_Credito, R.Producto, R.FechaDesembolso, R.CantidadRef, R.MesAnterior, R.Saldo_MesAnterior, R.Participacion,
		0 As Flag_Vigente,
		1 As Flag_Agil
	FROM dbo.OperacionesAgiles R
	WHERE
		FechaDesembolso Is Not NULL
		And Not Exists (
			SELECT 1 FROM BPE.dbo.Refinanciados Rf
			WHERE
				R.FechaDesembolso = Rf.FechaDesembolso
				And R.Cod_CreditoRefinanciado = Rf.Cod_CreditoRefinanciado
		)
	-------------------------------
	-- ELIMINAMOS LOS no validos--
	-------------------------------
	DELETE FROM dbo.OperacionesAgiles WHERE FechaDesembolso Is Not NULL



-- Procesamiento Refinanciados
-- Ambiente: Sandbox 
	TRUNCATE TABLE dbo.Refinanciados_Carga
	TRUNCATE TABLE dbo.Refinanciados

	INSERT INTO dbo.Refinanciados_Carga ( Mes, Cod_Unico, Cod_CreditoRefinanciado, ProductoRefinanciado, Cod_Credito, Producto, FechaDesembolso )
	SELECT
		Convert(VARCHAR(6),FechaDesembolso,112) As Mes,
		ltrim(rTrim(CodUnico)) As Cod_Unico,
		BPE.dbo.fn_Cad_FormatoCodigo(ltrim(rTrim(CodOperacionActivaAnt))) As Cod_CreditoRefinanciado,
		ltrim(rTrim(NombreSubproductoFinancieroAnt)) As ProductoRefinanciado,
		BPE.dbo.fn_Cad_FormatoCodigo(ltrim(rTrim(CodOperacionActivaAct))) As Cod_Credito,
		( CASE WHEN Campana Like '%REP%' THEN 'REPROGRAMADO' ELSE ltrim(rTrim(NombreSubproductoFinancieroAct)) END ) As Producto,
		Convert(DATE,FechaDesembolso) As FechaDesembolso
	FROM dbo.Refinanciados_PreCarga

	UPDATE R
	SET R.CantidadRef = Tmp.CantidadRef
	FROM dbo.Refinanciados_Carga R
	INNER JOIN (
		SELECT Cod_Credito, Count(*) As CantidadRef
		FROM dbo.Refinanciados_Carga
		GROUP BY Cod_Credito
	) Tmp On R.Cod_Credito = Tmp.Cod_Credito

	UPDATE dbo.Refinanciados_Carga
	SET MesAnterior = BPE.dbo.fn_Fec_Variar_Periodo( Mes ,-1)

	UPDATE R
	SET R.Saldo_MesAnterior = A.VIG*Dc.TipoCambio+A.VEN*Dc.TipoCambio+A.JUD*Dc.TipoCambio
	FROM dbo.Refinanciados_Carga R
	INNER JOIN BPE.dbo.vw_SaldosCierre A On R.MesAnterior = A.MES And R.Cod_CreditoRefinanciado = A.NROPROD_X
	INNER JOIN BPE.dbo.vw_DatosCierre Dc On A.MES = Dc.Mes

	UPDATE R
	SET R.PARTICIPACION = R.Saldo_MesAnterior/Tmp.Saldo
	FROM dbo.Refinanciados_Carga R
	INNER JOIN (
		SELECT Cod_Credito, Sum(Saldo_MesAnterior) As Saldo
		FROM dbo.Refinanciados_Carga
		GROUP BY Cod_Credito
	) Tmp On R.Cod_Credito = Tmp.Cod_Credito

	---------------------
	-- EXTRAEMOS DATOS --
	---------------------
	
	INSERT INTO dbo.Refinanciados ( Mes, Cod_Unico, Cod_CreditoRefinanciado, ProductoRefinanciado, Cod_Credito, Producto, FechaDesembolso, CantidadRef, MesAnterior, Saldo_MesAnterior, Participacion )
	SELECT
		R.Mes, R.Cod_Unico, R.Cod_CreditoRefinanciado, R.ProductoRefinanciado,
		R.Cod_Credito, R.Producto, R.FechaDesembolso, R.CantidadRef, R.MesAnterior, R.Saldo_MesAnterior, R.Participacion
	FROM dbo.Refinanciados_Carga R
	WHERE Not Exists (
		SELECT 1 FROM BPE.dbo.Refinanciados Rf
		WHERE
			R.Cod_CreditoRefinanciado = Rf.Cod_CreditoRefinanciado
			And Rf.Flag_Agil = 0
	)

	----------------------
	-- EXPORTAMOS DATOS --
	----------------------
	INSERT INTO BPE.dbo.Refinanciados ( Mes, Cod_Unico, Cod_CreditoRefinanciado, ProductoRefinanciado, Cod_Credito, Producto, FechaDesembolso, CantidadRef, MesAnterior, Saldo_MesAnterior, Participacion, Flag_Vigente, Flag_Agil )
	SELECT
		Mes, Cod_Unico, Cod_CreditoRefinanciado, ProductoRefinanciado, Cod_Credito, Producto, FechaDesembolso, CantidadRef, MesAnterior, Saldo_MesAnterior, Participacion,
		0 As Flag_Vigente,
		0 As Flag_Agil
	FROM dbo.Refinanciados
	
	TRUNCATE TABLE dbo.Refinanciados_PreCarga
	TRUNCATE TABLE dbo.Refinanciados_Carga
	TRUNCATE TABLE dbo.Refinanciados
