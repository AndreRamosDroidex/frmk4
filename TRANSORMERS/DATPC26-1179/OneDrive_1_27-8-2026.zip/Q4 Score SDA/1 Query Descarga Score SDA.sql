-- Teradata 
/*dbo.ScoreOrigen_PreCarga*/
SELECT
	Sc.CREDITO_ID CodCredito,
	Sc.FECHA_DT Fecha,
	Sc.CONTADOR_VAL Contador,
	Sc.DICTAMEN_VAL Dictamen,
	Sc.MONTO_LIMITE_MTO MontoLimite,
	Sc.PUNTAJE_SCORE_VAL PuntajeScore,
	Cr.CLIENTE_TER_VAL Cliente_TER,
	Sc.MODELO_VAL Modelo,
	Sc.TIPO_RIESGO_VAL TipoRiesgo,
	Sc.BUCKET_OPERACION_VAL BucketOperacion,
	Cr.COD_SEGMENTO_VAL CodSegmento
FROM E_DW_VIEWS.V_REL_VPC_MYP_CREDSCORING /*Pendiente Réplica */ Sc
LEFT JOIN E_DW_VIEWS.V_REL_VPC_MYP_CRED /* e_perm_aws.t_rel_vpc_myp_cred */ Cr On Sc.CREDITO_ID = Cr.CREDITO_ID
WHERE
	Sc.FECHA_DT >= (current_date - Interval '60' day) 
	And NVL(Sc.MODELO_VAL,'') <> ''
;