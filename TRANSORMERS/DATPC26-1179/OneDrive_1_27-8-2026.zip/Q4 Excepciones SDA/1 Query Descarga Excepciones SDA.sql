-- IBMYP
SELECT CE.CodCredito as CodSolicitud, 
  CE.Estado as CodEstado,
  CE.CodExcepcion , 
  E.Descripcion Descripcion_Excepcion,
  CE.Sustento
FROM CreditoExcepcion CE
INNER JOIN Excepcion E ON E.CodExcepcion = CE.CodExcepcion
