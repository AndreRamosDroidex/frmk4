from utils.others.helper_functions import get_name_function

class LoadS3:
    def __init__(self, spark, config, logger):
        self.spark = spark
        self.config = config
        self.logger = logger

    def run(self, df):

        # Obtener el nombre de esta funcion para usarlo en los logs
        name_function = get_name_function()
        
        # Destino
        self.origen = {
            "local-new-egde": False,
            "local-ec2": False,
            "s3": True
        }        
        
        if self.origen.get("local-new-egde", False):
            # New Edge
            path_output = "/data/desa/IBKProjects/DataHub/frmk4/tmp/outputs/output_s3/"
        elif self.origen.get("local-ec2", False):
            # AWS - EC2
            path_output = "/home/ubuntu/frmk4/tmp/outputs/output_s3/"
        elif self.origen.get("s3", False):
            # AWS - s3
            path_output = f"s3://aw-dev-s3-chapter-01-demo/data/output/"
            
        self.logger.registrar("INFO", f"[{name_function}] - Guardando resultados: {path_output}")
        df.write.mode("overwrite").parquet(path_output)
